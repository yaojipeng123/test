# sst_ebd

1. build command
scons app=unit_test -j32

