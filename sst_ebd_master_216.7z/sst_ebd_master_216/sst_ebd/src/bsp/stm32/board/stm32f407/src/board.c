#include "types.h"
#include "assert.h"
#include "hal_internal.h"

#include "stm32f4xx.h"
#include "stm32f4xx_hal.h"

extern void SystemClock_Config(void);
extern UART_HandleTypeDef *board_uart_get_handle(uint8_t port);
extern SPI_HandleTypeDef *board_spi_get_handle(uint8_t port);
extern TIM_HandleTypeDef *board_timer_get_handle(uint8_t id);
extern uint8_t board_irq_get_priority(uint32_t vector);

UART_HandleTypeDef *uart_get_handle(uint8_t port)
{
    return board_uart_get_handle(port);
}

uint8_t irq_get_priority(uint32_t vector)
{
    return board_irq_get_priority(vector);
}

TIM_HandleTypeDef *timer_get_handle(uint8_t id)
{
    return board_timer_get_handle(id);
}

SPI_HandleTypeDef *spi_get_handle(uint8_t port)
{
    return board_spi_get_handle(port);
}

void hal_bsp_init(void)
{
    /* MCU Configuration--------------------------------------------------------*/

    /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
    HAL_Init();

    /* USER CODE BEGIN Init */

    /* USER CODE END Init */

    /* Configure the system clock */
    SystemClock_Config();

    /* USER CODE BEGIN SysInit */

    /* USER CODE END SysInit */

    /* Initialize all configured peripherals */
    // MX_GPIO_Init();
}
