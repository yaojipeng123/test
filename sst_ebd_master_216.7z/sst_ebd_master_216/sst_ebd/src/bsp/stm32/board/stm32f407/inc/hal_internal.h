#ifndef HAL_INTERNAL_H
#define HAL_INTERNAL_H

#include "stm32f4xx.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    TIM2_INDEX,
    TIM3_INDEX,
    TIM4_INDEX,
} TIM_INDEX;

enum CHIP_IRQ_VECTOR {

    CHIP_UART4_VECTOR,
    CHIP_USART2_VECTOR,

    CHIP_IRQ_VECTOR_MAX = 32,
};

#define TIM_BASE TIM2_BASE

UART_HandleTypeDef *uart_get_handle(uint8_t port);

TIM_HandleTypeDef *timer_get_handle(uint8_t id);

TIM_HandleTypeDef *pwm_get_handle(uint8_t id);

SPI_HandleTypeDef *spi_get_handle(uint8_t port);

uint8_t irq_get_priority(uint32_t vector);

#ifdef __cplusplus
}
#endif

#endif   //HAL_INTERNAL_H