/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file         stm32f4xx_hal_msp.c
  * @brief        This file provides code for the MSP Initialization
  *               and de-Initialization codes.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */

#include "stm32f4xx.h"

#include "stm32f4xx_hal_rcc.h"
#include "stm32f4xx_hal_cortex.h"
#include "stm32f4xx_hal_tim.h"
#include "tim_encode.h"
#define USART1_TX_DMA_CHANNEL DMA_CHANNEL_4
#define USART1_TX_DMA_STREAM  DMA2_Stream7

/* APBx timer clocks frequency doubler state related to APB1CLKDivider value */
static void pclkx_doubler_get(uint32_t *pclk1_doubler, uint32_t *pclk2_doubler)
{
    uint32_t flatency                    = 0;
    RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };

    HAL_RCC_GetClockConfig(&RCC_ClkInitStruct, &flatency);

    *pclk1_doubler = 1;
    *pclk2_doubler = 1;

    if(RCC_ClkInitStruct.APB1CLKDivider != RCC_HCLK_DIV1) {
        *pclk1_doubler = 2;
    }

    if(RCC_ClkInitStruct.APB2CLKDivider != RCC_HCLK_DIV1) {
        *pclk2_doubler = 2;
    }
}

/**
  * @brief TIM MSP Initialization 
  *        This function configures the hardware resources used in this example: 
  *           - Peripheral's clock enable
  *           - Peripheral's GPIO Configuration  
  * @param htim: TIM handle pointer
  * @retval None
  */
uint32_t pclk3;
void HAL_TIM_Base_MspInit(TIM_HandleTypeDef *htim)
{
    /*##-1- Enable peripherals and GPIO Clocks #################################*/
    /* TIMx Peripheral clock enable */
    if(htim->Instance == TIM2) {
        __HAL_RCC_TIM2_CLK_ENABLE();

        uint32_t prescaler_value = 0;
        uint32_t pclk1_doubler, pclk2_doubler;
        pclkx_doubler_get(&pclk1_doubler, &pclk2_doubler);
        uint32_t pclk1 = HAL_RCC_GetPCLK1Freq();

        prescaler_value              = (uint32_t)(pclk1 * pclk1_doubler / 1000000) - 1;
        htim->Init.Period            = 0xffffffff;
        htim->Init.Prescaler         = prescaler_value;
        htim->Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;
        htim->Init.CounterMode       = TIM_COUNTERMODE_UP;
        htim->Init.RepetitionCounter = 1;
    }

    if(htim->Instance == TIM3) {
        __HAL_RCC_TIM3_CLK_ENABLE();

        uint32_t prescaler_value = 0;
        uint32_t pclk1_doubler, pclk2_doubler;
        pclkx_doubler_get(&pclk1_doubler, &pclk2_doubler);
        uint32_t pclk1 = HAL_RCC_GetPCLK1Freq();

        prescaler_value = (uint32_t)(pclk1 * pclk1_doubler / 10000) - 1;
        // htim->Init.Period = 0xffffffff;
        htim->Init.Prescaler         = prescaler_value;
        htim->Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;
        htim->Init.CounterMode       = TIM_COUNTERMODE_UP;
        htim->Init.RepetitionCounter = 0;

        // /*##-2- Configure the NVIC for TIMx ########################################*/
        // /* Set Interrupt Group Priority */
        HAL_NVIC_SetPriority(TIM3_IRQn, 4, 0);

        // /* Enable the TIMx global Interrupt */
        HAL_NVIC_EnableIRQ(TIM3_IRQn);
    }
    if(htim->Instance == TIM5) {
        __HAL_RCC_TIM5_CLK_ENABLE();

        uint32_t prescaler_value = 0;
        uint32_t pclk1_doubler, pclk2_doubler;
        pclkx_doubler_get(&pclk1_doubler, &pclk2_doubler);
        uint32_t pclk1 = HAL_RCC_GetPCLK1Freq();

        prescaler_value = (uint32_t)(pclk1 * pclk1_doubler / 1000) - 1;
        // htim->Init.Period = 0xffffffff;
        htim->Init.Prescaler         = prescaler_value;
        htim->Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;
        htim->Init.CounterMode       = TIM_COUNTERMODE_UP;
        htim->Init.RepetitionCounter = 1;

        // /*##-2- Configure the NVIC for TIMx ########################################*/
        // /* Set Interrupt Group Priority */
        HAL_NVIC_SetPriority(TIM5_IRQn, 4, 0);

        // /* Enable the TIMx global Interrupt */
        HAL_NVIC_EnableIRQ(TIM5_IRQn);
    }
}

/**
  * @brief TIM MSP Initialization for pwm
  *        This function configures the hardware resources used in this example: 
  *           - Peripheral's clock enable
  *           - Peripheral's GPIO Configuration  
  * @param htim: TIM handle pointer
  * @retval None
  */
void HAL_TIM_PWM_MspInit(TIM_HandleTypeDef *htim)
{
    if(htim->Instance == TIM1) {
        GPIO_InitTypeDef GPIO_Initure;
        __HAL_RCC_TIM1_CLK_ENABLE();    //使能定时器1
        __HAL_RCC_GPIOA_CLK_ENABLE();   //开启GPIOA时钟

        GPIO_Initure.Pin       = GPIO_PIN_8 | GPIO_PIN_9;   //PA8 PA9
        GPIO_Initure.Mode      = GPIO_MODE_AF_PP;           //复用推挽输出
        GPIO_Initure.Pull      = GPIO_PULLUP;               //上拉
        GPIO_Initure.Speed     = GPIO_SPEED_HIGH;           //高速
        GPIO_Initure.Alternate = GPIO_AF1_TIM1;
        HAL_GPIO_Init(GPIOA, &GPIO_Initure);
    }
    if(htim->Instance == TIM8) {
        GPIO_InitTypeDef GPIO_Initure;
        __HAL_RCC_TIM8_CLK_ENABLE();    //使能定时器1
        __HAL_RCC_GPIOC_CLK_ENABLE();   //开启GPIOC时钟
        __HAL_RCC_GPIOI_CLK_ENABLE();   //开启GPIOI时钟

        GPIO_Initure.Pin       = GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_8;   //PA8 PA9
        GPIO_Initure.Mode      = GPIO_MODE_AF_PP;                        //复用推挽输出
        GPIO_Initure.Pull      = GPIO_PULLUP;                            //上拉
        GPIO_Initure.Speed     = GPIO_SPEED_HIGH;                        //高速
        GPIO_Initure.Alternate = GPIO_AF3_TIM8;
        HAL_GPIO_Init(GPIOC, &GPIO_Initure);

        GPIO_Initure.Pin       = GPIO_PIN_2;        //PA8 PA9
        GPIO_Initure.Mode      = GPIO_MODE_AF_PP;   //复用推挽输出
        GPIO_Initure.Pull      = GPIO_PULLUP;       //上拉
        GPIO_Initure.Speed     = GPIO_SPEED_HIGH;   //高速
        GPIO_Initure.Alternate = GPIO_AF3_TIM8;
        HAL_GPIO_Init(GPIOI, &GPIO_Initure);
    }
}

/**
  * @brief  DeInitializes TIM Base MSP.
  * @param  htim TIM Base handle
  * @retval None
  */
void HAL_TIM_Base_MspDeInit(TIM_HandleTypeDef *htim)
{
    if(htim->Instance == TIM3) {
        __HAL_RCC_TIM3_CLK_DISABLE();
        // /* Enable the TIMx global Interrupt */
        HAL_NVIC_DisableIRQ(TIM3_IRQn);
    }
}

HAL_TIM_Encoder_MspInit(TIM_HandleTypeDef *htim)
{
    if(htim->Instance == TIM3) {
        GPIO_InitTypeDef GPIO_Initure;
        __HAL_RCC_TIM3_CLK_ENABLE();
        __HAL_RCC_GPIOC_CLK_ENABLE();

        GPIO_Initure.Pin       = GPIO_PIN_6 | GPIO_PIN_7;   //PC6 PC7
        GPIO_Initure.Mode      = GPIO_MODE_AF_OD;           //复用开漏输出
        GPIO_Initure.Pull      = GPIO_PULLUP;               //上拉
        GPIO_Initure.Speed     = GPIO_SPEED_HIGH;           //高速
        GPIO_Initure.Alternate = GPIO_AF2_TIM3;
        HAL_GPIO_Init(GPIOC, &GPIO_Initure);

        htim->Init.Prescaler         = ENCODER_TIM_PRESCALER;   //预分频值 0
        htim->Init.CounterMode       = TIM_COUNTERMODE_UP;
        htim->Init.Period            = ENCODER_TIM_PERIOD;   //定时器溢出值 65535
        htim->Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;
        htim->Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
        /* 清零计数器 */
        __HAL_TIM_SET_COUNTER(htim, 0);

        /* 清零中断标志位 */
        __HAL_TIM_CLEAR_IT(htim, TIM_IT_UPDATE);
        /* 使能定时器的更新事件中断 */
        __HAL_TIM_ENABLE_IT(htim, TIM_IT_UPDATE);
        /* 设置更新事件请求源为：计数器溢出 */
        __HAL_TIM_URS_ENABLE(htim);

        /* 设置中断优先级 */
        HAL_NVIC_SetPriority(TIM3_IRQn, 5, 1);
        /* 使能定时器中断 */
        HAL_NVIC_EnableIRQ(TIM3_IRQn);

        /* 使能编码器接口 */
        HAL_TIM_Encoder_Start(htim, TIM_CHANNEL_ALL);
    }
}

/**
  * @brief UART MSP Initialization 
  *        This function configures the hardware resources used in this example: 
  *           - Peripheral's clock enable
  *           - Peripheral's GPIO Configuration  
  * @param huart: UART handle pointer
  * @retval None
  */
void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
    GPIO_InitTypeDef GPIO_InitStruct = { 0 };
    if(huart->Instance == USART2) {
        /* USART2 clock enable */
        __HAL_RCC_USART2_CLK_ENABLE();

        __HAL_RCC_GPIOA_CLK_ENABLE();
        /**USART2 GPIO Configuration
        PA2     ------> UART2_TX
        PA3     ------> UART3_RX
        */
        GPIO_InitStruct.Pin       = GPIO_PIN_2 | GPIO_PIN_3;
        GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Pull      = GPIO_PULLUP;
        GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
        GPIO_InitStruct.Alternate = GPIO_AF7_USART2;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

        // HAL_NVIC_SetPriority(USART2_IRQn ,3,1);
        // HAL_NVIC_EnableIRQ(USART2_IRQn );

    } else if(huart->Instance == USART1) {
        /* UART4 clock enable */
        __HAL_RCC_USART1_CLK_ENABLE();
        /* Enable DMA1 clock */
        __HAL_RCC_DMA2_CLK_ENABLE();
        /* Enable GPIO TX/RX clock */
        __HAL_RCC_GPIOA_CLK_ENABLE();
        /**UART4 GPIO Configuration
        PA9     ------> USART1_TX
        PA10    ------> USART1_RX
        */
        GPIO_InitStruct.Pin       = GPIO_PIN_9 | GPIO_PIN_10;
        GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Pull      = GPIO_PULLUP;
        GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
        GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

        // static DMA_HandleTypeDef hdma_tx;
        // hdma_tx.Instance = USART1_TX_DMA_STREAM;
        // hdma_tx.Init.Channel = USART1_TX_DMA_CHANNEL;
        // hdma_tx.Init.Direction = DMA_MEMORY_TO_PERIPH;
        // hdma_tx.Init.PeriphInc = DMA_PINC_DISABLE;
        // hdma_tx.Init.MemInc = DMA_MINC_ENABLE;
        // hdma_tx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
        // hdma_tx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
        // hdma_tx.Init.Mode = DMA_NORMAL;
        // hdma_tx.Init.Priority = DMA_PRIORITY_LOW;
        // hdma_tx.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
        // hdma_tx.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_FULL;
        // hdma_tx.Init.MemBurst = DMA_MBURST_INC4;
        // hdma_tx.Init.PeriphBurst = DMA_PBURST_INC4;

        // HAL_DMA_Init(&hdma_tx);

        // /* Associate the initialized DMA handle to the the UART handle */
        // __HAL_LINKDMA(huart, hdmatx, hdma_tx);

        // /*##-4- Configure the NVIC for DMA #########################################*/
        // /* NVIC configuration for DMA transfer complete interrupt (USARTx_TX) */
        // HAL_NVIC_SetPriority(DMA2_Stream7_IRQn, 5, 0);
        // HAL_NVIC_EnableIRQ(DMA2_Stream7_IRQn);

        // /* NVIC configuration for USART TC interrupt */
        // HAL_NVIC_SetPriority(USART1_IRQn, 10, 0);
        // HAL_NVIC_EnableIRQ(USART1_IRQn);
    } else if(huart->Instance == USART3) {
        /* UART4 clock enable */
        __HAL_RCC_USART3_CLK_ENABLE();

        /* Enable GPIO TX/RX clock */
        __HAL_RCC_GPIOB_CLK_ENABLE();
        /**UART4 GPIO Configuration
        PA9     ------> USART1_TX
        PA10    ------> USART1_RX
        */
        GPIO_InitStruct.Pin       = GPIO_PIN_11 | GPIO_PIN_10;
        GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Pull      = GPIO_PULLUP;
        GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
        GPIO_InitStruct.Alternate = GPIO_AF7_USART3;
        HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
        /*##-3- Configure the NVIC for UART ########################################*/
        /* NVIC for USART3 */
        HAL_NVIC_SetPriority(USART3_IRQn, 6, 0);
        HAL_NVIC_EnableIRQ(USART3_IRQn);
    }
}

/**
  * @brief UART MSP De-Initialization 
  *        This function frees the hardware resources used in this example:
  *          - Disable the Peripheral's clock
  *          - Revert GPIO configuration to their default state
  * @param huart: UART handle pointer
  * @retval None
  */
void HAL_UART_MspDeInit(UART_HandleTypeDef *huart)
{
    if(huart->Instance == USART2) {
        /* Peripheral clock disable */
        __HAL_RCC_USART2_CLK_DISABLE();

        /**UART4 GPIO Configuration
        PA2    ------> USART2_TX
        PA3     ------> USRT2RX
        */
        HAL_GPIO_DeInit(GPIOA, GPIO_PIN_2 | GPIO_PIN_3);
    } else if(huart->Instance == USART1) {
        /* Peripheral clock disable */
        __HAL_RCC_USART1_CLK_DISABLE();

        static DMA_HandleTypeDef hdma_tx;
        /**USART1 GPIO Configuration
        PA9     ------> USART1_TX
        PA10    ------> USART1_RX
        */
        HAL_GPIO_DeInit(GPIOA, GPIO_PIN_9 | GPIO_PIN_10);

        /*##-3- Disable the DMA Streams ############################################*/
        /* De-Initialize the DMA Stream associate to transmission process */
        // HAL_DMA_DeInit(&hdma_tx);

        // /*##-4- Disable the NVIC for DMA ###########################################*/
        // HAL_NVIC_DisableIRQ(DMA2_Stream7_IRQn);
    } else if(huart->Instance == USART3) {
        __HAL_RCC_USART3_CLK_DISABLE();
    }
}

/**
  * @brief ADC MSP Initialization 
  *        This function configures the hardware resources used in this example: 
  *           - Peripheral's clock enable
  *           - Peripheral's GPIO Configuration  
  * @param huart: UART handle pointer
  * @retval None
  */

void HAL_ADC_MspInit(ADC_HandleTypeDef *hadc)
{
    GPIO_InitTypeDef GPIO_InitStruct = { 0 };
    static DMA_HandleTypeDef hdma_adc;

    /*##-1- Enable peripherals and GPIO Clocks #################################*/
    /* ADC3 Periph clock enable */
    __HAL_RCC_ADC1_CLK_ENABLE();
    /* Enable GPIO clock ****************************************/
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();

    /*##-2- Configure peripheral GPIO ##########################################*/
    /* ADC Channel GPIO pin configuration */
    // GPIO_InitStruct.Pin = GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3;
    // GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    // GPIO_InitStruct.Pull = GPIO_NOPULL;
    // HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    GPIO_InitStruct.Pin  = GPIO_PIN_4;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    hdma_adc.Instance = DMA2_Stream0;

    hdma_adc.Init.Channel             = DMA_CHANNEL_0;
    hdma_adc.Init.Direction           = DMA_PERIPH_TO_MEMORY;
    hdma_adc.Init.PeriphInc           = DMA_PINC_DISABLE;
    hdma_adc.Init.MemInc              = DMA_MINC_ENABLE;
    hdma_adc.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
    hdma_adc.Init.MemDataAlignment    = DMA_MDATAALIGN_WORD;
    hdma_adc.Init.Mode                = DMA_CIRCULAR;
    hdma_adc.Init.Priority            = DMA_PRIORITY_HIGH;
    hdma_adc.Init.FIFOMode            = DMA_FIFOMODE_DISABLE;
    hdma_adc.Init.FIFOThreshold       = DMA_FIFO_THRESHOLD_HALFFULL;
    hdma_adc.Init.MemBurst            = DMA_MBURST_SINGLE;
    hdma_adc.Init.PeriphBurst         = DMA_PBURST_SINGLE;

    HAL_DMA_Init(&hdma_adc);

    /* Associate the initialized DMA handle to the the ADC handle */
    __HAL_LINKDMA(hadc, DMA_Handle, hdma_adc);

    /*##-4- Configure the NVIC for DMA #########################################*/
    /* NVIC configuration for DMA transfer complete interrupt */
    HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);

    // /*##-3- Configure the NVIC #################################################*/
    // /* NVIC configuration for ADC interrupt */
    // HAL_NVIC_SetPriority(ADC_IRQn, 0, 0);
    // HAL_NVIC_EnableIRQ(ADC_IRQn);
}

/**
  * @brief ADC MSP De-Initialization 
  *        This function frees the hardware resources used in this example:
  *          - Disable the Peripheral's clock
  *          - Revert GPIO to their default state
  * @param hadc: ADC handle pointer
  * @retval None
  */
void HAL_ADC_MspDeInit(ADC_HandleTypeDef *hadc)
{
    /*##-1- Reset peripherals ##################################################*/
    __HAL_RCC_ADC_FORCE_RESET();
    __HAL_RCC_ADC_RELEASE_RESET();

    /*##-2- Disable peripherals and GPIO Clocks ################################*/
    /* De-initialize the ADC Channel GPIO pin */
    HAL_GPIO_DeInit(GPIOC, GPIO_PIN_4);
}

/**
  * @brief DAC MSP De-Initialization 
  *        This function frees the hardware resources used in this example:
  *          - Disable the Peripheral's clock
  *          - Revert GPIO to their default state
  * @param hadc: DAC handle pointer
  * @retval None
  */
void HAL_DAC_MspInit(DAC_HandleTypeDef *hdac)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    /*##-1- Enable peripherals and GPIO Clocks #################################*/
    /* DAC Periph clock enable */
    __HAL_RCC_DAC_CLK_ENABLE();
    /* Enable GPIO clock ****************************************/
    __HAL_RCC_GPIOA_CLK_ENABLE();

    /*##-2- Configure peripheral GPIO ##########################################*/
    /* DAC Channel1 GPIO pin configuration */
    GPIO_InitStruct.Pin  = GPIO_PIN_4;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

/**
  * @brief  DeInitializes the DAC MSP.
  * @param  hdac: pointer to a DAC_HandleTypeDef structure that contains
  *         the configuration information for the specified DAC.  
  * @retval None
  */
void HAL_DAC_MspDeInit(DAC_HandleTypeDef *hdac)
{
    static DMA_HandleTypeDef hdma_dac1;

    /*##-1- Reset peripherals ##################################################*/
    __HAL_RCC_DAC_FORCE_RESET();
    __HAL_RCC_DAC_RELEASE_RESET();

    /*##-2- Disable peripherals and GPIO Clocks ################################*/
    /* De-initialize the DAC Channel1 GPIO pin */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_4);
}

/**
  * @brief SPI MSP Initialization
  *        This function configures the hardware resources used in this example:
  *           - Peripheral's clock enable
  *           - Peripheral's GPIO Configuration
  *           - NVIC configuration for SPI interrupt request enable
  * @param hspi: SPI handle pointer
  * @retval None
  */
void HAL_SPI_MspInit(SPI_HandleTypeDef *hspi)
{
    GPIO_InitTypeDef GPIO_InitStruct = { 0 };
    if(hspi->Instance == SPI5) {
        /*##-1- Enable GPIO Clock ##################################################*/
        /* Enable SPI5 SCK MISO MOSI clock */
        __HAL_RCC_GPIOF_CLK_ENABLE();

        /*##-2- Configure peripheral GPIO ##########################################*/
        /* SPI SCK GPIO pin configuration  */
        GPIO_InitStruct.Pin       = GPIO_PIN_7;
        GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Pull      = GPIO_PULLUP;
        GPIO_InitStruct.Speed     = GPIO_SPEED_FAST;
        GPIO_InitStruct.Alternate = GPIO_AF5_SPI5;
        HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

        /* SPI MISO GPIO pin configuration  */
        GPIO_InitStruct.Pull = GPIO_PULLUP;
        GPIO_InitStruct.Pin  = GPIO_PIN_8;
        HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

        /* SPI MOSI GPIO pin configuration  */
        GPIO_InitStruct.Pin = GPIO_PIN_9;
        HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

        /*##-3- Enable SPI peripheral Clock ########################################*/
        /* Enable SPI clock */
        __HAL_RCC_SPI5_CLK_ENABLE();

        /*##-4- Configure the NVIC for SPI #########################################*/
        /* NVIC for SPI */
        // HAL_NVIC_SetPriority(SPIx_IRQn, 1, 0);
        // HAL_NVIC_EnableIRQ(SPIx_IRQn);
    }
    if(hspi->Instance == SPI2) {
        /*##-1- Enable GPIO Clock ##################################################*/
        /* Enable SPI5 SCK MISO MOSI clock */
        __HAL_RCC_GPIOI_CLK_ENABLE();
        __HAL_RCC_GPIOB_CLK_ENABLE();
        __HAL_RCC_SPI2_CLK_ENABLE();
        /*##-2- Configure peripheral GPIO ##########################################*/
        /* SPI SCK GPIO pin configuration  */
        GPIO_InitStruct.Pin   = GPIO_PIN_8;
        GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
        GPIO_InitStruct.Pull  = GPIO_PULLUP;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;   //GPIO_SPEED_FREQ_HIGH;
        HAL_GPIO_Init(GPIOI, &GPIO_InitStruct);

        /* SPI MISO GPIO pin configuration  */
        GPIO_InitStruct.Pin       = GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15;
        GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Pull      = GPIO_PULLUP;
        GPIO_InitStruct.Alternate = GPIO_AF5_SPI2;
        HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

        /* SPI MOSI GPIO pin configuration  */

        /*##-3- Enable SPI peripheral Clock ########################################*/
        /* Enable SPI clock */

        /*##-4- Configure the NVIC for SPI #########################################*/
        /* NVIC for SPI */
        // HAL_NVIC_SetPriority(SPIx_IRQn, 1, 0);
        // HAL_NVIC_EnableIRQ(SPIx_IRQn);
    }
}

/**
  * @brief SPI MSP De-Initialization
  *        This function frees the hardware resources used in this example:
  *          - Disable the Peripheral's clock
  *          - Revert GPIO configuration to its default state
  *          - Revert NVIC configuration to its default state
  * @param hspi: SPI handle pointer
  * @retval None
  */
void HAL_SPI_MspDeInit(SPI_HandleTypeDef *hspi)
{
    if(hspi->Instance == SPI5) {
        /*##-1- Reset peripherals ##################################################*/
        __HAL_RCC_SPI5_FORCE_RESET();
        __HAL_RCC_SPI5_RELEASE_RESET();

        /*##-2- Disable peripherals and GPIO Clocks ################################*/
        /* Configure SPI SCK as alternate function  */
        HAL_GPIO_DeInit(GPIOF, GPIO_PIN_7);
        /* Configure SPI MISO as alternate function  */
        HAL_GPIO_DeInit(GPIOF, GPIO_PIN_8);
        /* Configure SPI MOSI as alternate function  */
        HAL_GPIO_DeInit(GPIOF, GPIO_PIN_9);
    }
    /*##-3- Disable the NVIC for SPI ###########################################*/
    // HAL_NVIC_DisableIRQ(SPIx_IRQn);
}

/**
  * @brief SRAM MSP Initialization
  *        This function configures the hardware resources used in this example:
  *           - Peripheral's clock enable
  *           - Peripheral's GPIO Configuration
  * @param hsram: SRAM handle pointer
  * @retval None
  */
void HAL_SRAM_MspInit(SRAM_HandleTypeDef *hsram)
{
    GPIO_InitTypeDef GPIO_Init_Structure;

    /* Enable FMC clock */
    __HAL_RCC_FMC_CLK_ENABLE();

    /* Enable GPIOs clock */
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();
    __HAL_RCC_GPIOE_CLK_ENABLE();
    __HAL_RCC_GPIOF_CLK_ENABLE();
    __HAL_RCC_GPIOG_CLK_ENABLE();

    /* Common GPIO configuration */
    GPIO_Init_Structure.Mode      = GPIO_MODE_AF_PP;
    GPIO_Init_Structure.Pull      = GPIO_NOPULL;
    GPIO_Init_Structure.Speed     = GPIO_SPEED_HIGH;
    GPIO_Init_Structure.Alternate = GPIO_AF12_FMC;

    /*## Data Bus #######*/
    GPIO_Init_Structure.Pin = GPIO_PIN_7;
    HAL_GPIO_Init(GPIOB, &GPIO_Init_Structure);

    GPIO_Init_Structure.Pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_8
        | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_14 | GPIO_PIN_15;
    HAL_GPIO_Init(GPIOD, &GPIO_Init_Structure);

    GPIO_Init_Structure.Pin = GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11
        | GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15;
    HAL_GPIO_Init(GPIOE, &GPIO_Init_Structure);

    GPIO_Init_Structure.Pin = GPIO_PIN_10;
    HAL_GPIO_Init(GPIOG, &GPIO_Init_Structure);
    /* GPIOD configuration */
    // GPIO_Init_Structure.Pin =
    //     GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_14 | GPIO_PIN_15;
    // HAL_GPIO_Init(GPIOD, &GPIO_Init_Structure);

    // /* GPIOE configuration */
    // GPIO_Init_Structure.Pin = GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11
    //     | GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15;
    // HAL_GPIO_Init(GPIOE, &GPIO_Init_Structure);

    // /*## Address Bus #######*/
    // /* GPIOF configuration */
    // GPIO_Init_Structure.Pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4
    //     | GPIO_PIN_5 | GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15;
    // HAL_GPIO_Init(GPIOF, &GPIO_Init_Structure);

    // /* GPIOG configuration */
    // GPIO_Init_Structure.Pin =
    //     GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5;
    // HAL_GPIO_Init(GPIOG, &GPIO_Init_Structure);

    // /* GPIOD configuration */
    // GPIO_Init_Structure.Pin = GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13;
    // HAL_GPIO_Init(GPIOD, &GPIO_Init_Structure);

    // /* GPIOE configuration */
    // GPIO_Init_Structure.Pin = GPIO_PIN_3 | GPIO_PIN_4;
    // HAL_GPIO_Init(GPIOE, &GPIO_Init_Structure);

    // /*## NOE and NWE configuration #######*/
    // GPIO_Init_Structure.Pin = GPIO_PIN_4 | GPIO_PIN_5;
    // HAL_GPIO_Init(GPIOD, &GPIO_Init_Structure);

    // /*## Enable Bank pin configuration #######*/
    // GPIO_Init_Structure.Pin = GPIO_PIN_9;
    // HAL_GPIO_Init(GPIOG, &GPIO_Init_Structure);

    // /*## NBL0, NBL1 configuration #######*/
    // GPIO_Init_Structure.Pin = GPIO_PIN_0 | GPIO_PIN_1;
    // HAL_GPIO_Init(GPIOE, &GPIO_Init_Structure);
}

/**
  * @brief SRAM MSP De-Initialization
  *        This function frees the hardware resources used in this example:
  *          - Disable the Peripheral's clock
  *          - Revert GPIO configuration to their default state
  * @param hsram: SRAM handle pointer
  * @retval None
  */
void HAL_SRAM_MspDeInit(SRAM_HandleTypeDef *hsram)
{
    /*## Disable peripherals and GPIO Clocks ###################################*/
    /* Configure FMC as alternate function  */
    HAL_GPIO_DeInit(GPIOD,
                    GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_8
                        | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13
                        | GPIO_PIN_14 | GPIO_PIN_15);

    HAL_GPIO_DeInit(GPIOE,
                    GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_7 | GPIO_PIN_8
                        | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13
                        | GPIO_PIN_14 | GPIO_PIN_15);

    HAL_GPIO_DeInit(GPIOF,
                    GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5
                        | GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15);

    HAL_GPIO_DeInit(GPIOG,
                    GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5
                        | GPIO_PIN_9);
}

void HAL_NOR_MspInit(NOR_HandleTypeDef *hnor)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    __HAL_RCC_FMC_CLK_ENABLE();

    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();
    __HAL_RCC_GPIOE_CLK_ENABLE();
    __HAL_RCC_GPIOG_CLK_ENABLE();
    GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull      = GPIO_NOPULL;
    GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF12_FMC;

    GPIO_InitStruct.Pin = GPIO_PIN_7;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_8
        | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_14 | GPIO_PIN_15;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11
        | GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15;
    HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_10;
    HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);
}

/**
  * Initializes the Global MSP.
  */
void HAL_MspInit(void)
{
    /* USER CODE BEGIN MspInit 0 */

    /* USER CODE END MspInit 0 */

    __HAL_RCC_SYSCFG_CLK_ENABLE();
    __HAL_RCC_PWR_CLK_ENABLE();

    /* System interrupt init*/
    /* PendSV_IRQn interrupt configuration */
    HAL_NVIC_SetPriority(PendSV_IRQn, 15, 0);

    /* USER CODE BEGIN MspInit 1 */
    /* USER CODE END MspInit 1 */
}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
