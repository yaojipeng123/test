#include "types.h"
#include "cpu.h"

#include "hal_internal.h"
#include "hal_gpio.h"
#include "hal_spi.h"

#define __STM32_PORT(port) GPIO##port##_BASE

#define GET_PIN(PORTx, PIN) \
    (uint32_t)((16 * (((uint32_t)__STM32_PORT(PORTx) - (uint32_t)GPIOA_BASE) / (0x0400UL))) + PIN)

#define PIN_NUM(port, no) (((((port)&0xFu) << 4) | ((no)&0xFu)))
#define PIN_PORT(pin)     ((uint8_t)(((pin) >> 4) & 0xFu))
#define PIN_NO(pin)       ((uint8_t)((pin)&0xFu))

#define PIN_STPORT(pin) ((GPIO_TypeDef *)(GPIOA_BASE + (0x400u * PIN_PORT(pin))))
#define PIN_STPIN(pin)  ((uint16_t)(1u << PIN_NO(pin)))

#if defined(GPIOZ)
#define __STM32_PORT_MAX 12u
#elif defined(GPIOK)
#define __STM32_PORT_MAX 11u
#elif defined(GPIOJ)
#define __STM32_PORT_MAX 10u
#elif defined(GPIOI)
#define __STM32_PORT_MAX 9u
#elif defined(GPIOH)
#define __STM32_PORT_MAX 8u
#elif defined(GPIOG)
#define __STM32_PORT_MAX 7u
#elif defined(GPIOF)
#define __STM32_PORT_MAX 6u
#elif defined(GPIOE)
#define __STM32_PORT_MAX 5u
#elif defined(GPIOD)
#define __STM32_PORT_MAX 4u
#elif defined(GPIOC)
#define __STM32_PORT_MAX 3u
#elif defined(GPIOB)
#define __STM32_PORT_MAX 2u
#elif defined(GPIOA)
#define __STM32_PORT_MAX 1u
#else
#define __STM32_PORT_MAX 0u
#error Unsupported STM32 GPIO peripheral.
#endif

#define PIN_STPORT_MAX __STM32_PORT_MAX
extern SPI_HandleTypeDef spi_config[];
struct gpio_irq_map {
    uint16_t pinbit;
    IRQn_Type irqno;
};

struct gpio_irq_handler {
    int16_t gpio;
    HAL_GPIO_INT_MODE mode;
    gpio_irq_handler_t cb;
    void *arg;
};

static const struct gpio_irq_map gpio_irq_map_tbl[] = {
    {GPIO_PIN_0, EXTI0_IRQn},      {GPIO_PIN_1, EXTI1_IRQn},      {GPIO_PIN_2, EXTI2_IRQn},
    {GPIO_PIN_3, EXTI3_IRQn},      {GPIO_PIN_4, EXTI4_IRQn},      {GPIO_PIN_5, EXTI9_5_IRQn},
    {GPIO_PIN_6, EXTI9_5_IRQn},    {GPIO_PIN_7, EXTI9_5_IRQn},    {GPIO_PIN_8, EXTI9_5_IRQn},
    {GPIO_PIN_9, EXTI9_5_IRQn},    {GPIO_PIN_10, EXTI15_10_IRQn}, {GPIO_PIN_11, EXTI15_10_IRQn},
    {GPIO_PIN_12, EXTI15_10_IRQn}, {GPIO_PIN_13, EXTI15_10_IRQn}, {GPIO_PIN_14, EXTI15_10_IRQn},
    {GPIO_PIN_15, EXTI15_10_IRQn},
};

static struct gpio_irq_handler gpio_irq_handler_tbl[] = {
    {-1, 0, NULL, NULL}, {-1, 0, NULL, NULL}, {-1, 0, NULL, NULL}, {-1, 0, NULL, NULL},
    {-1, 0, NULL, NULL}, {-1, 0, NULL, NULL}, {-1, 0, NULL, NULL}, {-1, 0, NULL, NULL},
    {-1, 0, NULL, NULL}, {-1, 0, NULL, NULL}, {-1, 0, NULL, NULL}, {-1, 0, NULL, NULL},
    {-1, 0, NULL, NULL}, {-1, 0, NULL, NULL}, {-1, 0, NULL, NULL}, {-1, 0, NULL, NULL},
};
static uint32_t pin_irq_enable_mask = 0;

inline int32_t bit2bitno(uint32_t bit)
{
    int i;
    for (i = 0; i < 32; i++) {
        if ((0x01 << i) == bit) {
            return i;
        }
    }
    return -1;
}

const struct gpio_irq_map *get_gpio_irq_map(uint32_t pinbit)
{
    int32_t mapindex = bit2bitno(pinbit);
    if (mapindex < 0 || mapindex >= ARRAY_SIZE(gpio_irq_map_tbl)) {
        return NULL;
    }
    return &gpio_irq_map_tbl[mapindex];
}

int32_t hal_gpio_init(void)
{
#if defined(__HAL_RCC_GPIOA_CLK_ENABLE)
    __HAL_RCC_GPIOA_CLK_ENABLE();
#endif

#if defined(__HAL_RCC_GPIOB_CLK_ENABLE)
    __HAL_RCC_GPIOB_CLK_ENABLE();
#endif

#if defined(__HAL_RCC_GPIOC_CLK_ENABLE)
    __HAL_RCC_GPIOC_CLK_ENABLE();
#endif

#if defined(__HAL_RCC_GPIOD_CLK_ENABLE)
    __HAL_RCC_GPIOD_CLK_ENABLE();
#endif

#if defined(__HAL_RCC_GPIOE_CLK_ENABLE)
    __HAL_RCC_GPIOE_CLK_ENABLE();
#endif

#if defined(__HAL_RCC_GPIOF_CLK_ENABLE)
    __HAL_RCC_GPIOF_CLK_ENABLE();
#endif

#if defined(__HAL_RCC_GPIOG_CLK_ENABLE)
#ifdef SOC_SERIES_STM32L4
    HAL_PWREx_EnableVddIO2();
#endif
    __HAL_RCC_GPIOG_CLK_ENABLE();
#endif

#if defined(__HAL_RCC_GPIOH_CLK_ENABLE)
    __HAL_RCC_GPIOH_CLK_ENABLE();
#endif

#if defined(__HAL_RCC_GPIOI_CLK_ENABLE)
    __HAL_RCC_GPIOI_CLK_ENABLE();
#endif

#if defined(__HAL_RCC_GPIOJ_CLK_ENABLE)
    __HAL_RCC_GPIOJ_CLK_ENABLE();
#endif

#if defined(__HAL_RCC_GPIOK_CLK_ENABLE)
    __HAL_RCC_GPIOK_CLK_ENABLE();
#endif
    return ERR_OK;
}

int32_t hal_gpio_deinit(void)
{
    return ERR_OK;
}

int32_t hal_gpio_open(uint8_t gpio, HAL_GPIO_DIRECTION dir)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    if (PIN_PORT(gpio) >= PIN_STPORT_MAX) {
        return ERR_INVAL;
    }
    /* Configure GPIO_InitStructure */
    GPIO_InitStruct.Pin = PIN_STPIN(gpio);
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;

    if (dir == HAL_GPIO_OUTPUT) {
        /* output setting */
        GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
        GPIO_InitStruct.Pull = GPIO_NOPULL;
    } else if (dir == HAL_GPIO_INPUT) {
        /* input setting: not pull. */
        GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
        GPIO_InitStruct.Pull = GPIO_NOPULL;
    } else if (dir == HAL_GPIO_INPUT_PULLUP) {
        /* input setting: pull up. */
        GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
        GPIO_InitStruct.Pull = GPIO_PULLUP;
    } else if (dir == HAL_GPIO_INPUT_PULLDOWN) {
        /* input setting: pull down. */
        GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
        GPIO_InitStruct.Pull = GPIO_PULLDOWN;
    } else if (dir == HAL_GPIO_OUTPUT_OD) {
        /* output setting: od. */
        GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
        GPIO_InitStruct.Pull = GPIO_NOPULL;
    }

    HAL_GPIO_Init(PIN_STPORT(gpio), &GPIO_InitStruct);

    return ERR_OK;
}

int32_t hal_gpio_close(uint8_t gpio)
{
    GPIO_InitTypeDef GPIO_InitStruct;

    if (PIN_PORT(gpio) >= PIN_STPORT_MAX) {
        return ERR_INVAL;
    }

    HAL_GPIO_DeInit(PIN_STPORT(gpio), PIN_STPIN(gpio));

    return ERR_OK;
}

int32_t hal_gpio_output_toggle(uint8_t gpio)
{
    if (PIN_PORT(gpio) >= PIN_STPORT_MAX) {
        return ERR_INVAL;
    }

    HAL_GPIO_TogglePin(PIN_STPORT(gpio), PIN_STPIN(gpio));

    return ERR_OK;
}

int32_t hal_gpio_output_high(uint8_t gpio)
{
    if (PIN_PORT(gpio) >= PIN_STPORT_MAX) {
        return ERR_INVAL;
    }

    HAL_GPIO_WritePin(PIN_STPORT(gpio), PIN_STPIN(gpio), GPIO_PIN_SET);

    return ERR_OK;
}

int32_t hal_gpio_output_low(uint8_t gpio)
{
    if (PIN_PORT(gpio) >= PIN_STPORT_MAX) {
        return ERR_INVAL;
    }

    HAL_GPIO_WritePin(PIN_STPORT(gpio), PIN_STPIN(gpio), GPIO_PIN_RESET);

    return ERR_OK;
}

int32_t hal_gpio_input_get(uint8_t gpio, uint32_t *value)
{
    if (PIN_PORT(gpio) >= PIN_STPORT_MAX) {
        return ERR_INVAL;
    }

    *value = HAL_GPIO_ReadPin(PIN_STPORT(gpio), PIN_STPIN(gpio));

    return ERR_OK;
}

int32_t hal_gpio_attach_irq(uint8_t gpio, HAL_GPIO_INT_MODE trigger, gpio_irq_handler_t handler,
                            void *arg)
{
    uint32_t level;
    int32_t irqindex = -1;

    if (PIN_PORT(gpio) >= PIN_STPORT_MAX) {
        return ERR_INVAL;
    }

    irqindex = bit2bitno(PIN_STPIN(gpio));
    if (irqindex < 0 || irqindex >= ARRAY_SIZE(gpio_irq_map_tbl)) {
        return ERR_NOT_EXIST;
    }

    level = hw_interrupt_disable();
    if (gpio_irq_handler_tbl[irqindex].gpio == gpio && gpio_irq_handler_tbl[irqindex].cb == handler
        && gpio_irq_handler_tbl[irqindex].mode == trigger
        && gpio_irq_handler_tbl[irqindex].arg == arg) {
        hw_interrupt_enable(level);
        return ERR_OK;
    }
    if (gpio_irq_handler_tbl[irqindex].gpio != -1) {
        hw_interrupt_enable(level);
        return ERR_BUSY;
    }
    gpio_irq_handler_tbl[irqindex].gpio = gpio;
    gpio_irq_handler_tbl[irqindex].cb = handler;
    gpio_irq_handler_tbl[irqindex].mode = trigger;
    gpio_irq_handler_tbl[irqindex].arg = arg;
    hw_interrupt_enable(level);

    return ERR_OK;
}

int32_t hal_gpio_dettach_irq(uint8_t gpio)
{
    uint32_t level;
    int32_t irqindex = -1;

    if (PIN_PORT(gpio) >= PIN_STPORT_MAX) {
        return ERR_INVAL;
    }

    irqindex = bit2bitno(PIN_STPIN(gpio));
    if (irqindex < 0 || irqindex >= ARRAY_SIZE(gpio_irq_map_tbl)) {
        return ERR_NOT_EXIST;
    }

    level = hw_interrupt_disable();
    if (gpio_irq_handler_tbl[irqindex].gpio == -1) {
        hw_interrupt_enable(level);
        return ERR_OK;
    }
    gpio_irq_handler_tbl[irqindex].gpio = -1;
    gpio_irq_handler_tbl[irqindex].cb = NULL;
    gpio_irq_handler_tbl[irqindex].mode = 0;
    gpio_irq_handler_tbl[irqindex].arg = NULL;
    hw_interrupt_enable(level);

    return ERR_OK;
}

int32_t hal_gpio_quick_enable_irq(uint8_t gpio, bool_t enable)
{
    const struct gpio_irq_map *irqmap;
    uint32_t level;
    int32_t irqindex = -1;
    irqindex = bit2bitno(PIN_STPIN(gpio));
    irqmap = &gpio_irq_map_tbl[irqindex];
    if(enable)
    {
        HAL_NVIC_EnableIRQ(irqmap->irqno);
    }else{
        HAL_NVIC_DisableIRQ(irqmap->irqno);
    }
}
int32_t hal_gpio_enable_irq(uint8_t gpio, bool_t enable)
{
    const struct gpio_irq_map *irqmap;
    uint32_t level;
    int32_t irqindex = -1;
    GPIO_InitTypeDef GPIO_InitStruct;

    if (PIN_PORT(gpio) >= PIN_STPORT_MAX) {
        return ERR_INVAL;
    }

    if (enable) {
        irqindex = bit2bitno(PIN_STPIN(gpio));
        if (irqindex < 0 || irqindex >= ARRAY_SIZE(gpio_irq_map_tbl)) {
            return ERR_NOT_EXIST;
        }

        level = hw_interrupt_disable();

        if (gpio_irq_handler_tbl[irqindex].gpio == -1) {
            hw_interrupt_enable(level);
            return ERR_NOT_READY;
        }

        irqmap = &gpio_irq_map_tbl[irqindex];

        /* Configure GPIO_InitStructure */
        GPIO_InitStruct.Pin = PIN_STPIN(gpio);
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
        switch (gpio_irq_handler_tbl[irqindex].mode) {
            case HAL_GPIO_INT_EDGE_RISING:
                GPIO_InitStruct.Pull = GPIO_PULLDOWN;
                GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
                break;
            case HAL_GPIO_INT_EDGE_FALLING:
                GPIO_InitStruct.Pull = GPIO_PULLUP;
                GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
                break;
            case HAL_GPIO_INT_EDGE_BOTH:
                GPIO_InitStruct.Pull = GPIO_NOPULL;
                GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
                break;
        }
        HAL_GPIO_Init(PIN_STPORT(gpio), &GPIO_InitStruct);

        HAL_NVIC_SetPriority(irqmap->irqno, 5, 0);
        HAL_NVIC_EnableIRQ(irqmap->irqno);
        pin_irq_enable_mask |= irqmap->pinbit;

        hw_interrupt_enable(level);
    } else {
        irqindex = bit2bitno(PIN_STPIN(gpio));
        if (irqindex < 0 || irqindex >= ARRAY_SIZE(gpio_irq_map_tbl)) {
            return ERR_INVAL;
        }
        irqmap = &gpio_irq_map_tbl[irqindex];

        if (irqmap == NULL) {
            return ERR_NOT_EXIST;
        }

        level = hw_interrupt_disable();

        HAL_GPIO_DeInit(PIN_STPORT(gpio), PIN_STPIN(gpio));

        pin_irq_enable_mask &= ~irqmap->pinbit;

        if ((irqmap->pinbit >= GPIO_PIN_5) && (irqmap->pinbit <= GPIO_PIN_9)) {
            if (!(pin_irq_enable_mask
                  & (GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9))) {
                HAL_NVIC_DisableIRQ(irqmap->irqno);
            }
        } else if ((irqmap->pinbit >= GPIO_PIN_10) && (irqmap->pinbit <= GPIO_PIN_15)) {
            if (!(pin_irq_enable_mask
                  & (GPIO_PIN_10 | GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14
                     | GPIO_PIN_15))) {
                HAL_NVIC_DisableIRQ(irqmap->irqno);
            }
        } else {
            HAL_NVIC_DisableIRQ(irqmap->irqno);
        }
        hw_interrupt_enable(level);
    }

    return ERR_OK;
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    int32_t irqindex = -1;
    irqindex = bit2bitno(GPIO_Pin);

    if (gpio_irq_handler_tbl[irqindex].cb) {
        gpio_irq_handler_tbl[irqindex].cb(gpio_irq_handler_tbl[irqindex].arg);
    }
}

void EXTI0_IRQHandler(void)
{
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_0);
}

void EXTI1_IRQHandler(void)
{
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_1);
}

void EXTI2_IRQHandler(void)
{
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_2);
}

void EXTI3_IRQHandler(void)
{
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_3);
}

void EXTI4_IRQHandler(void)
{
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_4);
}

void EXTI9_5_IRQHandler(void)
{
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_5);
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_6);
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_7);
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_8);
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_9);
}

void EXTI15_10_IRQHandler(void)
{
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_10);
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_11);
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_12);
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_13);
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_14);
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_15);
}