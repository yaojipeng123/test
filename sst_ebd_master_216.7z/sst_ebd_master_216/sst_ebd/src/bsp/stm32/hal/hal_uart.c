#include "types.h"

#include "hal_internal.h"
#include "hal_uart.h"

#define HAL_USER_UART_MAX_VALID_NUM 3

#define UART_SET_TDR(__HANDLE__, __DATA__) ((__HANDLE__)->Instance->DR = (__DATA__))
#define UART_GET_RDR(__HANDLE__)           ((__HANDLE__)->Instance->DR & 0xFF)

#define MAXRXBUFFERSIZE 256
typedef struct hal_uart_t {
    HAL_UART_PORT port;
    hal_uart_receive_callback receive_cb;
    hal_uart_transmit_callback transmit_cb;
    uint8_t rx_buffer[MAXRXBUFFERSIZE];
    uint8_t rx_in;
    uint8_t rx_out;
    void *data;

    UART_HandleTypeDef *uart;
} hal_uart_t;

hal_uart_t hal_uart[HAL_USER_UART_MAX_VALID_NUM] = {0};

static uint32_t hal_uart_get_uart_id(UART_HandleTypeDef *phy_uart)
{
    uint32_t i = 0;
    for (i = 1; i < ARRAY_SIZE(hal_uart); i++) {
        if (hal_uart[i].uart == phy_uart) {
            break;
        }
    }

    return i;
}

int32_t hal_uart_init(void)
{
    return ERR_OK;
}

int32_t hal_uart_deinit(void)
{
    return ERR_OK;
}
int32_t hal_uart_open(HAL_UART_PORT port, uint32_t baud_rate, HAL_UART_DATA_BITS data,
                      HAL_UART_STOP_BITS stop, HAL_UART_PARITY parity)
{
    int32_t result = ERR_OK;

    UART_HandleTypeDef *uart = uart_get_handle((uint8_t)port);
    if (uart->Init.BaudRate == NULL)
        uart->Init.BaudRate = baud_rate;
    if (HAL_UART_Init(uart) != HAL_OK) {
        result = ERR_FAIL;
    }
    hal_uart[port].port = port;
    hal_uart[port].uart = uart;
    hal_uart_register_rx_callback(port, NULL);
    hal_uart_register_tx_callback(port, NULL);
    return result;
}

int32_t hal_uart_close(HAL_UART_PORT port)
{
    int32_t result = ERR_OK;
    UART_HandleTypeDef *uart = uart_get_handle((uint8_t)port);

    if (HAL_UART_DeInit(uart) != HAL_OK) {
        result = ERR_FAIL;
    }
    hal_uart_register_rx_callback(port, NULL);
    hal_uart_register_tx_callback(port, NULL);
    return result;
}

int32_t hal_uart_register_tx_callback(HAL_UART_PORT port, hal_uart_transmit_callback cb)
{
    int32_t result = ERR_OK;
    hal_uart[port].transmit_cb = cb;
    return result;
}

int32_t hal_uart_transmit(HAL_UART_PORT port, const void *buffer, uint32_t count)
{
    int32_t result = ERR_OK;
    UART_HandleTypeDef *uart = uart_get_handle((uint8_t)port);

    if (uart->hdmatx == NULL) {
        if (hal_uart[port].transmit_cb != NULL) {
            if (HAL_UART_Transmit_IT(uart, (uint8_t *)buffer, count) != HAL_OK) {
                result = ERR_TIMEOUT;
            }
        } else {
            if (HAL_UART_Transmit(uart, (uint8_t *)buffer, count, 5000) != HAL_OK) {
                result = ERR_TIMEOUT;
            }
        }

    } else {
        if (HAL_UART_Transmit_DMA(uart, (uint8_t *)buffer, count) != HAL_OK) {
            result = ERR_TIMEOUT;
        }
    }

    return result;
}

int32_t hal_uart_register_rx_callback(HAL_UART_PORT port, hal_uart_receive_callback cb)
{
    int32_t result = ERR_OK;
    hal_uart[port].receive_cb = cb;
    return result;
}

int32_t hal_uart_start_receive_it(HAL_UART_PORT port)
{
    int32_t result = ERR_OK;
    UART_HandleTypeDef *uart = uart_get_handle((uint8_t)port);

    // if (HAL_UART_Receive_IT(uart, (uint8_t *)&hal_uart[port].rx_buffer[0], 1) != HAL_OK) {
    //     result = ERR_FAIL;
    // }
    if (port == HAL_UART_PORT2) {

        __HAL_UART_DISABLE_IT(uart, UART_IT_TXE);
        __HAL_UART_CLEAR_FLAG(uart, UART_FLAG_RXNE);
        __HAL_UART_CLEAR_FLAG(uart, UART_FLAG_TXE);
        __HAL_UART_CLEAR_FLAG(uart, UART_FLAG_TC);
        HAL_NVIC_SetPriority(USART3_IRQn, 3, 0);
        HAL_NVIC_EnableIRQ(USART3_IRQn);
        __HAL_UART_ENABLE_IT(uart, UART_IT_RXNE);
    }
    return result;
}

int32_t hal_uart_receive(HAL_UART_PORT port, uint8_t *buffer, uint32_t count)
{
    int32_t result = ERR_OK;
    UART_HandleTypeDef *uart = uart_get_handle((uint8_t)port);

    if (HAL_UART_Receive(uart, (uint8_t *)buffer, count, 5000) != HAL_OK) {
        result = ERR_TIMEOUT;
    }

    return result;
}

int32_t hal_uart_receive_buffer(HAL_UART_PORT port, uint8_t *buffer, uint32_t expect_count,
                                uint32_t *a_actualsize)
{
    int32_t result = ERR_OK;
    uint32_t rx_count = 0;
    // hal_uart[port].rx_buflen = expect_count;
    while (hal_uart[port].rx_out != hal_uart[port].rx_in) {

        buffer[rx_count++] = hal_uart[port].rx_buffer[hal_uart[port].rx_out++];

        if (hal_uart[port].rx_out == MAXRXBUFFERSIZE) {
            hal_uart[port].rx_out = 0;
        }

        if (rx_count == expect_count) {

            result = 0;
            return result;
        }
    }

    if (a_actualsize != NULL) {
        *a_actualsize = rx_count;
    }

    result = 1;
    return result;
}

int32_t hal_uart_receive_it(HAL_UART_PORT port, uint8_t *buffer, uint32_t count)
{
    int32_t result = ERR_OK;
    uint32_t rx_count = 0;
    UART_HandleTypeDef *uart = uart_get_handle((uint8_t)port);
    // hal_uart[port].rx_buflen = count;
    while (hal_uart[port].rx_out != hal_uart[port].rx_in) {
        buffer[rx_count++] = hal_uart[port].rx_buffer[hal_uart[port].rx_out++];
        if (hal_uart[port].rx_out == MAXRXBUFFERSIZE) {
            hal_uart[port].rx_out = 0;
        }

        if (rx_count == count) {
            break;
        }
    }

    if (rx_count)
        return ERR_OK;
    else
        return ERR_FAIL;
}

int32_t hal_uart_putc(HAL_UART_PORT port, uint8_t c)
{
    UART_HandleTypeDef *uart = uart_get_handle((uint8_t)port);

    __HAL_UART_CLEAR_FLAG(uart, UART_FLAG_TC);

    uart->Instance->DR = c;

    while (__HAL_UART_GET_FLAG(uart, UART_FLAG_TC) == RESET)
        ;

    return ERR_OK;
}

int32_t hal_uart_getc(HAL_UART_PORT port)
{
    int ch;
    UART_HandleTypeDef *uart = uart_get_handle((uint8_t)port);

    ch = -1;
    if (__HAL_UART_GET_FLAG(uart, UART_FLAG_RXNE) != RESET)
        ch = UART_GET_RDR(uart);

    return ch;
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *uart)
{
    uint32_t id = hal_uart_get_uart_id(uart);
    if (id < HAL_USER_UART_MAX_VALID_NUM)
        hal_uart[id].transmit_cb(hal_uart[id].port);
}

static void UART_IT_RxCpltCallback(HAL_UART_PORT port, uint32_t max_buffer_size)
{

    //TODO:
    //should take care to avoid UART_RX_IN get accross UART_RX_OUT, which will loss unread data
    //if receive buffer is too small, or application read data out of receive buffer at very low frequence
    //this situation may happen
    if (++hal_uart[port].rx_in >= max_buffer_size)
        hal_uart[port].rx_in = 0;

    HAL_UART_Receive_IT(hal_uart[port].uart,
                        (uint8_t *)&hal_uart[port].rx_buffer[hal_uart[port].rx_in], 1);
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *uart)
{
    uint32_t id = hal_uart_get_uart_id(uart);

    if (id < HAL_USER_UART_MAX_VALID_NUM) {
        // if(hal_uart[id].rx_buflen!=0)
        // {
        //     UART_IT_RxCpltCallback(id, hal_uart[id].rx_buflen);//MAXRXBUFFERSIZE
        // }else{
        hal_uart[id].receive_cb(hal_uart[id].port);
        // UART_IT_RxCpltCallback(id, MAXRXBUFFERSIZE);
        // }
    }
}

void DMA2_Stream7_IRQHandler(void)
{
    UART_HandleTypeDef *uart = uart_get_handle((uint8_t)HAL_UART_PORT1);
    HAL_DMA_IRQHandler(uart->hdmatx);
}
void USART1_IRQHandler(void)
{
    UART_HandleTypeDef *uart = uart_get_handle((uint8_t)HAL_UART_PORT1);
    HAL_UART_IRQHandler(uart);
}

void USART3_IRQHandler(void)
{
    UART_HandleTypeDef *uart = uart_get_handle((uint8_t)HAL_UART_PORT2);
    // HAL_UART_IRQHandler(uart);
    if ((__HAL_UART_GET_FLAG(uart, UART_FLAG_RXNE) != RESET)
        && (__HAL_UART_GET_IT_SOURCE(uart, UART_IT_RXNE) != RESET)) {

        hal_uart[HAL_UART_PORT2].receive_cb(hal_uart[HAL_UART_PORT2].port);
    }
}
