#include "types.h"
#include "stdio.h"

#include "hal_internal.h"
#include "hal_flash.h"
#include "stm32f4xx_hal_flash.h"

static uint32_t GetSector(uint32_t Address);
static uint32_t GetSectorSize(uint32_t Sector);

int32_t hal_flash_erase(uint32_t start_sector, uint32_t end_sector)
{
    int32_t ret = ERR_OK;
    HAL_FLASH_Unlock();
    uint32_t firstsector = 0, nbofsectors = 0;
    uint32_t address = 0, setctor_error = 0;
    FLASH_EraseInitTypeDef erase_initStruct;
    /* Get the 1st sector to erase */
    firstsector = GetSector(start_sector);
    /* Get the number of sector to erase from 1st sector*/
    nbofsectors                   = GetSector(end_sector) - firstsector + 1;
    erase_initStruct.TypeErase    = FLASH_TYPEERASE_SECTORS;
    erase_initStruct.VoltageRange = FLASH_VOLTAGE_RANGE_3;
    erase_initStruct.Sector       = firstsector;
    erase_initStruct.NbSectors    = nbofsectors;
    if(HAL_FLASHEx_Erase(&erase_initStruct, &setctor_error) != HAL_OK)
        ret = ERR_FAIL;
    HAL_FLASH_Lock();
    return ret;
}

int32_t hal_flash_program_word(uint32_t start_add, uint32_t *data, uint32_t len)
{
    int32_t ret      = ERR_OK;
    uint32_t address = start_add;
    HAL_FLASH_Unlock();

    __HAL_FLASH_DATA_CACHE_DISABLE();
    __HAL_FLASH_INSTRUCTION_CACHE_DISABLE();

    __HAL_FLASH_DATA_CACHE_RESET();
    __HAL_FLASH_INSTRUCTION_CACHE_RESET();

    __HAL_FLASH_INSTRUCTION_CACHE_ENABLE();
    __HAL_FLASH_DATA_CACHE_ENABLE();

    for(int i = 0; i < len; i++) {
        if(HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, address, data[i]) == HAL_OK)
            address = address + 4;
        else {
            ret = ERR_FAIL;
            break;
        }
    }

    HAL_FLASH_Lock();
    return ret;
}

__attribute__((section("RAMCODE"))) int32_t hal_flash_read_word(uint32_t start_add, uint32_t *data,
                                                                uint32_t len)
{
    int32_t ret      = ERR_OK;
    uint32_t address = start_add;
    for(int i = 0; i < len; i++) {
        data[i] = *(__IO uint32_t *)address;
        address = address + 4;
    }

    return ret;
}

/**
  * @brief  Gets the sector of a given address
  * @param  None
  * @retval The sector of a given address
  */

static uint32_t GetSector(uint32_t Address)
{
    uint32_t sector = 0;
    if((Address < ADDR_FLASH_SECTOR_1) && (Address >= ADDR_FLASH_SECTOR_0)) {
        sector = FLASH_SECTOR_0;
    } else if((Address < ADDR_FLASH_SECTOR_2) && (Address >= ADDR_FLASH_SECTOR_1)) {
        sector = FLASH_SECTOR_1;
    } else if((Address < ADDR_FLASH_SECTOR_3) && (Address >= ADDR_FLASH_SECTOR_2)) {
        sector = FLASH_SECTOR_2;
    } else if((Address < ADDR_FLASH_SECTOR_4) && (Address >= ADDR_FLASH_SECTOR_3)) {
        sector = FLASH_SECTOR_3;
    } else if((Address < ADDR_FLASH_SECTOR_5) && (Address >= ADDR_FLASH_SECTOR_4)) {
        sector = FLASH_SECTOR_4;
    } else if((Address < ADDR_FLASH_SECTOR_6) && (Address >= ADDR_FLASH_SECTOR_5)) {
        sector = FLASH_SECTOR_5;
    } else if((Address < ADDR_FLASH_SECTOR_7) && (Address >= ADDR_FLASH_SECTOR_6)) {
        sector = FLASH_SECTOR_6;
    } else if((Address < ADDR_FLASH_SECTOR_8) && (Address >= ADDR_FLASH_SECTOR_7)) {
        sector = FLASH_SECTOR_7;
    } else if((Address < ADDR_FLASH_SECTOR_9) && (Address >= ADDR_FLASH_SECTOR_8)) {
        sector = FLASH_SECTOR_8;
    } else if((Address < ADDR_FLASH_SECTOR_10) && (Address >= ADDR_FLASH_SECTOR_9)) {
        sector = FLASH_SECTOR_9;
    } else if((Address < ADDR_FLASH_SECTOR_11) && (Address >= ADDR_FLASH_SECTOR_10)) {
        sector = FLASH_SECTOR_10;
    } else /* (Address < FLASH_END_ADDR) && (Address >= ADDR_FLASH_SECTOR_11) */
    {
        sector = FLASH_SECTOR_11;
    }

    return sector;
}

// #endif
/**
  * @brief  Gets sector Size
  * @param  None
  * @retval The size of a given sector
  */
static uint32_t GetSectorSize(uint32_t Sector)
{
    uint32_t sectorsize = 0x00;
    if((Sector == FLASH_SECTOR_0) || (Sector == FLASH_SECTOR_1) || (Sector == FLASH_SECTOR_2)
       || (Sector == FLASH_SECTOR_3)) {
        sectorsize = 16 * 1024;
    } else if(Sector == FLASH_SECTOR_4) {
        sectorsize = 64 * 1024;
    } else {
        sectorsize = 128 * 1024;
    }
    return sectorsize;
}