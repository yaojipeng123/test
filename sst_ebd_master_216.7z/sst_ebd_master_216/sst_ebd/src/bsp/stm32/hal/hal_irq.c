#include "types.h"

#include "hal_internal.h"
#include "hal_irq.h"

typedef struct isr_handler {
    hal_isr_t isr;
    uint32_t param;
    uint8_t priority;
    uint8_t vector;
} isr_handler_t;

static isr_handler_t hal_isr_handlers[CHIP_IRQ_VECTOR_MAX];

static uint32_t hal_default_isr(uint32_t vector, uint32_t data)
{
    UNUSED(vector);
    UNUSED(data);
    return 0;
}

hal_irq_t hal_irq_create(uint32_t vector, uint32_t data, hal_isr_t isr)
{
    hal_isr_handlers[vector].isr = isr;
    hal_isr_handlers[vector].param = data;
    hal_isr_handlers[vector].priority = irq_get_priority(vector);
    hal_isr_handlers[vector].vector = vector;

    HAL_NVIC_SetPriority(vector, hal_isr_handlers[vector].priority, 0);

    return (hal_irq_t)&hal_isr_handlers[vector];
}

void hal_irq_set_data(uint32_t vector, uint32_t data)
{
    hal_isr_handlers[vector].param = data;
}

void hal_irq_delete(hal_irq_t interrupt)
{
    isr_handler_t *isr = (isr_handler_t *)interrupt;
    uint32_t vector = isr->vector;

    isr->isr = hal_default_isr;
    isr->param = 0;
    isr->priority = HAL_INTR_PRI_0;

    HAL_NVIC_DisableIRQ(vector);
    HAL_NVIC_SetPriority(vector, HAL_INTR_PRI_0, 0);
}

void hal_irq_mask(hal_irq_t interrupt)
{
    isr_handler_t *isr = (isr_handler_t *)interrupt;
    uint32_t vector = isr->vector;

    HAL_NVIC_DisableIRQ(vector);
}

void hal_irq_unmask(hal_irq_t interrupt)
{
    isr_handler_t *isr = (isr_handler_t *)interrupt;
    uint32_t vector = isr->vector;

    HAL_NVIC_EnableIRQ(vector);
}

void hal_irq_acknowledge(hal_irq_t interrupt)
{
    UNUSED(interrupt);
}

void hal_irq_configure(hal_irq_t interrupt, uint32_t level, uint32_t up)
{
    UNUSED(interrupt);
    UNUSED(level);
    UNUSED(up);
}

void hal_irq_priority(hal_irq_t interrupt, uint32_t priority)
{
    isr_handler_t *isr = (isr_handler_t *)interrupt;
    uint32_t vector = isr->vector;

    HAL_NVIC_SetPriority(vector, priority, 0);
}

int32_t hal_irq_init(void)
{
    for (uint32_t i = 0; i < CHIP_IRQ_VECTOR_MAX; i++) {
        hal_isr_handlers[i].isr = hal_default_isr;
        hal_isr_handlers[i].param = 0;
        hal_isr_handlers[i].priority = HAL_INTR_PRI_0;
        hal_isr_handlers[i].vector = i;
    }

    /* Set Interrupt Group Priority */
    HAL_NVIC_SetPriorityGrouping(NVIC_PRIORITYGROUP_4);

    return ERR_OK;
}

void hal_irq_deliver(uint32_t vector)
{
    hal_isr_t isr = hal_isr_handlers[vector].isr;
    uint32_t param = (uint32_t)hal_isr_handlers[vector].param;

    // Call the ISR
    isr(vector, param);
}

