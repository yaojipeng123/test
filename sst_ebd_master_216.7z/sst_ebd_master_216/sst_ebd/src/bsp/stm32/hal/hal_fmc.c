#include "types.h"

#include "hal_internal.h"
#include "hal_fmc.h"

int32_t hal_fmc_nor_init(void)
{
#if defined(STM32F429xx)
    int32_t result = ERR_OK;
    NOR_HandleTypeDef hnor = {0};
    FMC_NORSRAM_TimingTypeDef NOR_Timing;

    hnor.Instance = FMC_NORSRAM_DEVICE;
    hnor.Extended = FMC_NORSRAM_EXTENDED_DEVICE;

    hnor.Init.NSBank = FMC_NORSRAM_BANK3;
    hnor.Init.DataAddressMux = FMC_DATA_ADDRESS_MUX_ENABLE;
    hnor.Init.MemoryType = FMC_MEMORY_TYPE_NOR;
    hnor.Init.MemoryDataWidth = FMC_NORSRAM_MEM_BUS_WIDTH_16;
    hnor.Init.BurstAccessMode = FMC_BURST_ACCESS_MODE_DISABLE;
    hnor.Init.WaitSignalPolarity = FMC_WAIT_SIGNAL_POLARITY_LOW;
    hnor.Init.WrapMode = FMC_WRAP_MODE_DISABLE;
    hnor.Init.WaitSignalActive = FMC_WAIT_TIMING_BEFORE_WS;
    hnor.Init.WriteOperation = FMC_WRITE_OPERATION_ENABLE;
    hnor.Init.WaitSignal = FMC_WAIT_SIGNAL_DISABLE;
    hnor.Init.ExtendedMode = FMC_EXTENDED_MODE_DISABLE;
    hnor.Init.AsynchronousWait = FMC_ASYNCHRONOUS_WAIT_DISABLE;
    hnor.Init.WriteBurst = FMC_WRITE_BURST_DISABLE;
    hnor.Init.PageSize = FMC_PAGE_SIZE_NONE;

    /* NOR_Timing */
    NOR_Timing.AddressSetupTime = 20;
    NOR_Timing.AddressHoldTime = 20;
    NOR_Timing.DataSetupTime = 120;
    NOR_Timing.BusTurnAroundDuration = 20;
    NOR_Timing.CLKDivision = 0;
    NOR_Timing.DataLatency = 0;   //17;
    NOR_Timing.AccessMode = FMC_ACCESS_MODE_A;

    /* Initialize the NOR controller */
    if (HAL_NOR_Init(&hnor, &NOR_Timing, &NOR_Timing) != HAL_OK) {
        result = ERR_FAIL;
    }
    return result;
#else
    return ERR_OK;
#endif
}

int32_t hal_fmc_sram_init(void)
{
#if defined(STM32F429xx)
    int32_t result = ERR_OK;
    SRAM_HandleTypeDef hsram;
    FMC_NORSRAM_TimingTypeDef SRAM_Timing;

    hsram.Instance = FMC_NORSRAM_DEVICE;
    hsram.Extended = FMC_NORSRAM_EXTENDED_DEVICE;

    /* SRAM device configuration */
    SRAM_Timing.AddressSetupTime = 20;
    SRAM_Timing.AddressHoldTime = 20;
    SRAM_Timing.DataSetupTime = 120;
    SRAM_Timing.BusTurnAroundDuration = 20;
    SRAM_Timing.CLKDivision = 0;
    SRAM_Timing.DataLatency = 0;
    SRAM_Timing.AccessMode = FMC_ACCESS_MODE_A;

    hsram.Init.NSBank = FMC_NORSRAM_BANK3;
    hsram.Init.DataAddressMux = FMC_DATA_ADDRESS_MUX_ENABLE;
    hsram.Init.MemoryType = FMC_MEMORY_TYPE_SRAM;
    hsram.Init.MemoryDataWidth = FMC_NORSRAM_MEM_BUS_WIDTH_16;
    hsram.Init.BurstAccessMode = FMC_BURST_ACCESS_MODE_DISABLE;
    hsram.Init.WaitSignalPolarity = FMC_WAIT_SIGNAL_POLARITY_LOW;
    hsram.Init.WrapMode = FMC_WRAP_MODE_DISABLE;
    hsram.Init.WaitSignalActive = FMC_WAIT_TIMING_BEFORE_WS;
    hsram.Init.WriteOperation = FMC_WRITE_OPERATION_ENABLE;
    hsram.Init.WaitSignal = FMC_WAIT_SIGNAL_DISABLE;
    hsram.Init.ExtendedMode = FMC_EXTENDED_MODE_ENABLE;
    hsram.Init.AsynchronousWait = FMC_ASYNCHRONOUS_WAIT_DISABLE;
    hsram.Init.WriteBurst = FMC_WRITE_BURST_DISABLE;
    hsram.Init.PageSize = FMC_PAGE_SIZE_NONE;
    // hsram.Init.ContinuousClock=FMC_CONTINUOUS_CLOCK_SYNC_ASYNC;
    // HAL_SRAM_DeInit(&hsram);

    /* Initialize the SRAM controller */
    if (HAL_SRAM_Init(&hsram, &SRAM_Timing, &SRAM_Timing) != HAL_OK) {
        result = ERR_FAIL;
    }

    return result;
#else
    return ERR_OK;
#endif
}
