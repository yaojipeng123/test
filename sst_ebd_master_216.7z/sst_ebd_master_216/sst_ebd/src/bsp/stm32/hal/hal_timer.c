#include "types.h"

#include "hal_internal.h"
#include "hal_timer.h"
#include "stm32f4xx_hal_tim.h"

#define HAL_USER_TIMER_MAX_VALID_NUM 3

#define TIM(index) (TIM_BASE + (0x0400UL * index))

#define TIM_INDEX(instance) ((instance - TIM_BASE) / 0x0400UL)

typedef struct hal_timer_t {
    bool_t repeat;
    uint8_t active;
    timer_callback_t *cb;
    uint32_t data;
    uint32_t valid;
    TIM_HandleTypeDef *tim;
} hal_timer_t;

hal_timer_t hal_timer[HAL_USER_TIMER_MAX_VALID_NUM + 1] = {0};

static uint32_t hal_assgin_timer(void)
{
    uint32_t i = 0;
    for (i = 1; i < ARRAY_SIZE(hal_timer); i++) {
        if (hal_timer[i].valid == false) {
            hal_timer[i].valid = true;
            break;
        }
    }

    return i;
}

static uint32_t hal_get_timer_id(TIM_INDEX index)
{
    uint32_t i = 0;
    for (i = 1; i < ARRAY_SIZE(hal_timer); i++) {
        if (hal_timer[i].valid) {
            TIM_HandleTypeDef *tim = hal_timer[i].tim;

            if (tim->Instance == (TIM_TypeDef *)TIM(index)) {
                break;
            }
        }
    }

    return i;
}

static IRQn_Type hal_get_timer_irq(uint8_t id)
{
    TIM_HandleTypeDef *tim = hal_timer[id].tim;
    TIM_INDEX tim_index = TIM_INDEX((uint32_t)tim->Instance);
}

int32_t hal_timer_init(void)
{
    int result = ERR_OK;

    /* init freerun timer*/
    TIM_HandleTypeDef *tim = (TIM_HandleTypeDef *)timer_get_handle(0);

    if (HAL_TIM_Base_Init(tim) != HAL_OK) {
        result = ERR_FAIL;
    }

    if (HAL_TIM_Base_Start(tim) != HAL_OK) {
        result = ERR_FAIL;
    }
    return result;
}

int32_t hal_timer_deinit(void)
{
    return ERR_OK;
}

uint32_t hal_timer_get_time(void)
{
    TIM_HandleTypeDef *tim = (TIM_HandleTypeDef *)timer_get_handle(0);

    return tim->Instance->CNT;
}

uint32_t hal_timer_get_counter_id(uint8_t id)
{
    TIM_HandleTypeDef *tim = (TIM_HandleTypeDef *)timer_get_handle(id);

    return tim->Instance->CNT;
}

int8_t hal_encoder_get_direction(uint8_t id)
{
    TIM_HandleTypeDef *tim = (TIM_HandleTypeDef *)timer_get_handle(id);
    return __HAL_TIM_IS_TIM_COUNTING_DOWN(tim);
}

uint32_t hal_timer_set_counter_id(uint8_t id,uint32_t counter)
{
    TIM_HandleTypeDef *tim = (TIM_HandleTypeDef *)timer_get_handle(id);

    tim->Instance->CNT = counter;

    return ERR_OK;
}
int32_t hal_timer_encode_init(uint8_t *id)
{
    int32_t result = ERR_OK;
    TIM_Encoder_InitTypeDef Encoder_ConfigStructure;
    uint8_t cid = hal_assgin_timer();

    if (cid == (HAL_USER_TIMER_MAX_VALID_NUM + 1)) {
        return ERR_NOT_READY;
    }

    *id = cid;

    TIM_HandleTypeDef *tim = (TIM_HandleTypeDef *)timer_get_handle(cid);

     /* 设置编码器倍频数 */
    Encoder_ConfigStructure.EncoderMode = TIM_ENCODERMODE_TI12;
    /* 编码器接口通道1设置 */
    Encoder_ConfigStructure.IC1Polarity = TIM_ICPOLARITY_RISING;
    Encoder_ConfigStructure.IC1Selection = TIM_ICSELECTION_DIRECTTI;
    Encoder_ConfigStructure.IC1Prescaler = TIM_ICPSC_DIV1;
    Encoder_ConfigStructure.IC1Filter = 0;
    /* 编码器接口通道2设置 */
    Encoder_ConfigStructure.IC2Polarity = TIM_ICPOLARITY_RISING;
    Encoder_ConfigStructure.IC2Selection = TIM_ICSELECTION_DIRECTTI;
    Encoder_ConfigStructure.IC2Prescaler = TIM_ICPSC_DIV1;
    Encoder_ConfigStructure.IC2Filter = 0;
    HAL_TIM_Encoder_Init(tim,&Encoder_ConfigStructure);
    if (HAL_TIM_Base_Init(tim) != HAL_OK) {
        result = ERR_FAIL;
        return result;
    }

    return result;
}
int32_t hal_timer_create(uint8_t *id, uint32_t period, bool_t repeat, timer_callback_t cb,
                         void *data)
{
    int32_t result = ERR_OK;

    uint8_t cid = hal_assgin_timer();

    if (cid == (HAL_USER_TIMER_MAX_VALID_NUM + 1)) {
        return ERR_NOT_READY;
    }

    *id = cid;

    TIM_HandleTypeDef *tim = (TIM_HandleTypeDef *)timer_get_handle(cid);

    tim->Init.Period = period - 1;

    if (HAL_TIM_Base_Init(tim) != HAL_OK) {
        result = ERR_FAIL;
        goto out;
    }

    /* clear update flag */
    __HAL_TIM_CLEAR_FLAG(tim, TIM_FLAG_UPDATE);
    /* enable update request source */
    __HAL_TIM_URS_ENABLE(tim);

    hal_timer[cid].repeat = repeat;
    hal_timer[cid].active = 1;
    hal_timer[cid].cb = cb;
    hal_timer[cid].data = (uint32_t)data;
    hal_timer[cid].tim = tim;

out:
    return result;
}

int32_t hal_timer_start(uint8_t id)
{
    int32_t result = ERR_OK;

    TIM_HandleTypeDef *tim = (TIM_HandleTypeDef *)timer_get_handle(id);

    /* set tim cnt */
    __HAL_TIM_SET_COUNTER(tim, 0);

    /* start timer */
    if (HAL_TIM_Base_Start_IT(tim) != HAL_OK) {
        result = ERR_FAIL;
    }

    return result;
}

int32_t hal_timer_stop(uint8_t id)
{
    TIM_HandleTypeDef *tim = (TIM_HandleTypeDef *)timer_get_handle(id);

    /* stop timer */
    HAL_TIM_Base_Stop_IT(tim);

    /* set tim cnt */
    __HAL_TIM_SET_COUNTER(tim, 0);
}

int32_t hal_timer_delete(uint8_t id)
{
    int32_t result = ERR_OK;

    if (id >= (HAL_USER_TIMER_MAX_VALID_NUM + 1)) {
        return ERR_INVAL;
    }

    hal_timer[id].repeat = 0;
    hal_timer[id].active = 0;
    hal_timer[id].cb = NULL;
    hal_timer[id].data = 0;

    TIM_HandleTypeDef *tim = (TIM_HandleTypeDef *)timer_get_handle(id);

    if (HAL_TIM_Base_DeInit(tim) != HAL_OK) {
        result = ERR_FAIL;
        goto out;
    }
out:
    return result;
}

void hal_timer_delay_us(uint32_t us)
{
    uint32_t start, now;
    uint32_t delay = us;

    if (!us) {
        return;
    }

    start = hal_timer_get_time();
    while (1) {
        now = hal_timer_get_time();
        if (now >= start) {
            if ((now - start) >= delay)
                break;
        } else {
            uint32_t delta = (uint32_t)(0x100000000LL - start);
            if ((delta + now) >= delay)
                break;
        }
    }
}

void hal_timer_delay_ms(uint32_t ms)
{
    hal_timer_delay_us(ms * 1000);
}

void TIM2_IRQHandler(void)
{
    uint8_t id = hal_get_timer_id(TIM2_INDEX);
    TIM_HandleTypeDef *tim = hal_timer[id].tim;
    HAL_TIM_IRQHandler(tim);

    if (!hal_timer[id].repeat) {
        /* stop timer */
        HAL_TIM_Base_Stop_IT(tim);

        /* set tim cnt */
        __HAL_TIM_SET_COUNTER(tim, 0);
    }

    if (hal_timer[id].cb) {
        hal_timer[id].cb((void *)hal_timer[id].data);
    }
}

void TIM3_IRQHandler(void)
{
    uint8_t id = hal_get_timer_id(TIM3_INDEX);
    TIM_HandleTypeDef *tim = hal_timer[id].tim;
    HAL_TIM_IRQHandler(tim);

    if (!hal_timer[id].repeat) {
        /* stop timer */
        HAL_TIM_Base_Stop_IT(tim);

        /* set tim cnt */
        __HAL_TIM_SET_COUNTER(tim, 0);
    }

    if (hal_timer[id].cb) {
        hal_timer[id].cb((void *)hal_timer[id].data);
    }
}

void TIM4_IRQHandler(void)
{
    uint8_t id = hal_get_timer_id(TIM4_INDEX);
    TIM_HandleTypeDef *tim = hal_timer[id].tim;
    HAL_TIM_IRQHandler(tim);

    if (!hal_timer[id].repeat) {
        /* stop timer */
        HAL_TIM_Base_Stop_IT(tim);

        /* set tim cnt */
        __HAL_TIM_SET_COUNTER(tim, 0);
    }

    if (hal_timer[id].cb) {
        hal_timer[id].cb((void *)hal_timer[id].data);
    }
}

