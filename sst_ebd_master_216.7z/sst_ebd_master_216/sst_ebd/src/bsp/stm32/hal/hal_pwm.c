#include "types.h"

#include "hal_internal.h"
#include "hal_pwm.h"

TIM_OC_InitTypeDef TIMX_CHXHandler[PWM_NUM_MAX] = {0};   //定时器3通道4句柄
TIM_HandleTypeDef tim[PWM_NUM_MAX] = {0};


int32_t hal_pwm_init(uint8_t id, uint32_t period,uint32_t psc)   //初始化时钟配置周期
{
    TIM_HandleTypeDef *p_tim = NULL;
    int32_t ret = ERR_OK;


    p_tim = (TIM_HandleTypeDef *)pwm_get_handle(id);
    tim[id].Instance = p_tim->Instance;
    tim[id].Init.Prescaler = psc;   //定时器分频 （90M/(89+1)=1MHz）频率设为1MHz
    tim[id].Init.CounterMode = TIM_COUNTERMODE_UP;   //向上计数模式
    tim[id].Init.Period = period;                    //自动重装载值
    tim[id].Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    ret = HAL_TIM_PWM_Init(&tim[id]);   //初始化PWM

    return ret;
}

int32_t hal_pwm_deinit(uint8_t id)
{
    int32_t ret = ERR_OK;
    ret = HAL_TIM_PWM_DeInit(&tim[id]);
    return ret;
}

int32_t hal_pwm_start(uint8_t id, bool pwm_mode, uint32_t pulse, bool ocpolarity,
                      uint32_t channel)
{
    int32_t ret = ERR_OK;
    uint32_t tim_channel;

    if (!pwm_mode) {
        TIMX_CHXHandler[id].OCMode = TIM_OCMODE_PWM1;   //模式选择PWM1
    } else {
        TIMX_CHXHandler[id].OCMode = TIM_OCMODE_PWM2;   //模式选择PWM2
    }
    TIMX_CHXHandler[id].Pulse = pulse;   //设置比较值,此值用来确定占空比
    if (!ocpolarity) {
        TIMX_CHXHandler[id].OCPolarity = TIM_OCPOLARITY_HIGH;   //输出比较极性为高
    } else {
        TIMX_CHXHandler[id].OCPolarity = TIM_OCPOLARITY_LOW;   //输出比较极性为低
    }
    switch (channel) {
        case 1:
            tim_channel = TIM_CHANNEL_1;
            break;
        case 2:
            tim_channel = TIM_CHANNEL_2;
            break;
        case 3:
            tim_channel = TIM_CHANNEL_3;
            break;
        case 4:
            tim_channel = TIM_CHANNEL_4;
            break;
        default:
            tim_channel = TIM_CHANNEL_ALL;
            break;
    }
    ret = HAL_TIM_PWM_ConfigChannel(&tim[id], &TIMX_CHXHandler[id], tim_channel);   //配置TIM通道

    HAL_TIM_PWM_Start(&tim[id], tim_channel);
    return ret;
}

int32_t hal_pwm_stop(uint8_t id, uint32_t channel)
{
    uint32_t tim_channel;

    switch (channel) {
        case 1:
            tim_channel = TIM_CHANNEL_1;
            break;
        case 2:
            tim_channel = TIM_CHANNEL_2;
            break;
        case 3:
            tim_channel = TIM_CHANNEL_3;
            break;
        case 4:
            tim_channel = TIM_CHANNEL_4;
            break;
        default:
            tim_channel = TIM_CHANNEL_ALL;
            break;
    }
    HAL_TIM_PWM_Stop(&tim[id], tim_channel);
    return ERR_OK;
}

int32_t hal_pwm_cycle_chg(uint8_t id, uint32_t period)   //修改周期
{
    TIM_Base_InitTypeDef psttimhandle;
    psttimhandle = tim[id].Init;
    psttimhandle.Period = period;   //修改周期
    TIM_Base_SetConfig(tim[id].Instance, &psttimhandle);

    return ERR_OK;
}

int32_t hal_pwm_freq_chg(uint8_t id, uint32_t pulse, uint32_t channel)   //修改占空比
{
    int32_t ret = ERR_OK;
    uint32_t tim_channel;

    TIMX_CHXHandler[id].Pulse =pulse;//设置比较值,此值用来确定占空比，默认比较值为自动重装载值的一半,即占空比为50%

    switch (channel) {
        case 1:
            tim_channel = TIM_CHANNEL_1;
            break;
        case 2:
            tim_channel = TIM_CHANNEL_2;
            break;
        case 3:
            tim_channel = TIM_CHANNEL_3;
            break;
        case 4:
            tim_channel = TIM_CHANNEL_4;
            break;
        default:
            tim_channel = TIM_CHANNEL_ALL;
            break;
    }
    ret = HAL_TIM_PWM_ConfigChannel(&tim[id], &TIMX_CHXHandler[id], tim_channel);

    HAL_TIM_PWM_Start(&tim[id], tim_channel);

    return ret;
}