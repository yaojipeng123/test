#include "types.h"
#include "hal_internal.h"
#include "hal_spi.h"

int32_t hal_spi_init(void)
{
    return ERR_OK;
}

int32_t hal_spi_deinit(void)
{
    return ERR_OK;
}

static uint32_t spi_mode_bit_map(HAL_SPI_ROLE role)
{
    uint32_t spi_transfer_role = SPI_MODE_MASTER;
    switch (role) {
        case SPI_ROLE_SLAVE:
            spi_transfer_role = SPI_MODE_SLAVE;
            break;
        case SPI_ROLE_MASTER:
            spi_transfer_role = SPI_MODE_MASTER;
            break;
        default:
            break;
    }

    return spi_transfer_role;
}

static uint32_t spi_prescaler_map(HAL_SPI_PRESCALER arg)
{
    uint32_t freq_prescaler = SPI_BAUDRATEPRESCALER_2;
    switch (arg) {
        case SPI_PRESCALER_2:
            freq_prescaler = SPI_BAUDRATEPRESCALER_2;
            break;
        case SPI_PRESCALER_4:
            freq_prescaler = SPI_BAUDRATEPRESCALER_4;
            break;
        case SPI_PRESCALER_8:
            freq_prescaler = SPI_BAUDRATEPRESCALER_8;
            break;
        case SPI_PRESCALER_16:
            freq_prescaler = SPI_BAUDRATEPRESCALER_16;
            break;
        case SPI_PRESCALER_32:
            freq_prescaler = SPI_BAUDRATEPRESCALER_32;
            break;
        case SPI_PRESCALER_64:
            freq_prescaler = SPI_BAUDRATEPRESCALER_64;
            break;
        case SPI_PRESCALER_128:
            freq_prescaler = SPI_BAUDRATEPRESCALER_128;
            break;
        case SPI_PRESCALER_256:
            freq_prescaler = SPI_BAUDRATEPRESCALER_256;
            break;
        default:
            break;
    }

    return freq_prescaler;
}

static uint32_t spi_firstbit_map(HAL_SPI_FIRST_BIT arg)
{
    uint32_t firstbit = SPI_FIRSTBIT_MSB;
    switch (arg) {
        case SPI_MSB:
            firstbit = SPI_FIRSTBIT_MSB;
            break;
        case SPI_LSB:
            firstbit = SPI_FIRSTBIT_LSB;
            break;
        default:
            break;
    }

    return firstbit;
}

static uint32_t spi_idle_clk_map(HAL_SPI_IDLE_CLK arg)
{
    uint32_t idle_polarity = SPI_POLARITY_HIGH;
    switch (arg) {
        case SPI_IDLE_LOW:
            idle_polarity = SPI_POLARITY_LOW;
            break;
        case SPI_IDLE_HIGH:
            idle_polarity = SPI_POLARITY_HIGH;
            break;
        default:
            break;
    }

    return idle_polarity;
}

static uint32_t spi_phase_delay_bit_map(HAL_SPI_CLK_PHASE arg)
{
    uint32_t phase_delay = SPI_PHASE_1EDGE;
    switch (arg) {
        case SPI_CLK_1EDGE:
            phase_delay = SPI_PHASE_1EDGE;
            break;
        case SPI_CLK_2EDGE:
            phase_delay = SPI_PHASE_2EDGE;
            break;
        default:
            break;
    }

    return phase_delay;
}

static uint32_t spi_datasize_bit_map(HAL_SPI_DATA_SIZE arg)
{
    uint32_t datasize = SPI_DATASIZE_8BIT;
    switch (arg) {
        case SPI_DATA_8BIT:
            datasize = SPI_DATASIZE_8BIT;
            break;
        case SPI_DATA_16BIT:
            datasize = SPI_DATASIZE_16BIT;
            break;
        default:
            break;
    }

    return datasize;
}

int32_t hal_spi_open(HAL_SPI_PORT port, HAL_SPI_PRESCALER prescaler, HAL_SPI_ROLE role,
                     HAL_SPI_FIRST_BIT mode, HAL_SPI_IDLE_CLK polarity, HAL_SPI_CLK_PHASE delay,
                     HAL_SPI_DATA_SIZE length)
{
    int32_t result = ERR_OK;

    SPI_HandleTypeDef *spi = spi_get_handle((uint8_t)port);
    /*##-1- Configure the SPI peripheral #######################################*/
    /* Set the SPI parameters */
    spi->Init.Mode = spi_mode_bit_map(role);
    spi->Init.BaudRatePrescaler = spi_prescaler_map(prescaler);
    spi->Init.CLKPhase = spi_phase_delay_bit_map(delay);
    spi->Init.CLKPolarity = spi_idle_clk_map(polarity);
    spi->Init.DataSize = spi_datasize_bit_map(length);
    spi->Init.FirstBit = spi_firstbit_map(mode);

    if (HAL_SPI_Init(spi) != HAL_OK) {
        result = ERR_FAIL;
    }

    /**/
    //hal_irq_create(CHIP_UART4_VECTOR, NULL, uart_isr);

    return result;
}

int32_t hal_spi_close(HAL_SPI_PORT port)
{
    int32_t result = ERR_OK;
    SPI_HandleTypeDef *spi = spi_get_handle((uint8_t)port);

    if (HAL_SPI_DeInit(spi) != HAL_OK) {
        result = ERR_FAIL;
    }

    return result;
}

int32_t hal_spi_send(HAL_SPI_PORT port, uint8_t *data, uint32_t length)
{
    int32_t result = ERR_OK;
    SPI_HandleTypeDef *spi = spi_get_handle((uint8_t)port);

    if (HAL_SPI_Transmit(spi, data, length, 1000) != HAL_OK) {
        result = ERR_TIMEOUT;
    }

    return result;
}

int32_t hal_spi_receive(HAL_SPI_PORT port, uint8_t *data, uint32_t length)
{
    int32_t result = ERR_OK;
    SPI_HandleTypeDef *spi = spi_get_handle((uint8_t)port);

    if (HAL_SPI_Receive(spi, data, length, 1000) != HAL_OK) {
        result = ERR_TIMEOUT;
    }

    return result;
}

void spi_flush_rxregister(SPI_HandleTypeDef *SPIHandle)
{
    __IO uint32_t tmpreg_ovr = 0;

    if (SPIHandle->Instance->SR & SPI_SR_RXNE) {
        tmpreg_ovr = SPIHandle->Instance->DR;
        tmpreg_ovr = SPIHandle->Instance->SR;
        UNUSED(tmpreg_ovr);
    }
}

int32_t hal_spi_send_recv(HAL_SPI_PORT port, uint8_t *tx_data, uint8_t *rx_data, uint16_t length)
{
    int32_t result = ERR_OK;
    SPI_HandleTypeDef *spi = spi_get_handle((uint8_t)port);
    spi_flush_rxregister(spi);
    if (HAL_SPI_TransmitReceive(spi, tx_data, rx_data, length, 1000) != HAL_OK) {
        result = ERR_TIMEOUT;
    }
    return result;
}