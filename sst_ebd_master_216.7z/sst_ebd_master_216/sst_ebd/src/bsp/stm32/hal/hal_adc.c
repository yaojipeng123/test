#include "types.h"
#include "string.h"

#include "hal_internal.h"
#include "stm32f4xx_hal_adc.h"
#include "hal_adc.h"
#include "stdio.h"

typedef struct hal_adc_t {
    bool_t is_inited;
    // uint8_t channel_cnt;
    adc_callback_t *regular_cb;
    adc_callback_t *inj_cb;
    ADC_HandleTypeDef *adc;
    uint32_t *regular_buffer;
    uint32_t *injection_buffer;
} hal_adc_t;

static hal_adc_t hal_adc[HAL_ADC_PORT_MAX] = {0};


static uint32_t adc_get_channel(uint8_t channel)
{
    uint32_t stm32_channel = 0;

    switch (channel) {
        case 0:
            stm32_channel = ADC_CHANNEL_0;
            break;
        case 1:
            stm32_channel = ADC_CHANNEL_1;
            break;
        case 2:
            stm32_channel = ADC_CHANNEL_2;
            break;
        case 3:
            stm32_channel = ADC_CHANNEL_3;
            break;
        case 4:
            stm32_channel = ADC_CHANNEL_4;
            break;
        case 5:
            stm32_channel = ADC_CHANNEL_5;
            break;
        case 6:
            stm32_channel = ADC_CHANNEL_6;
            break;
        case 7:
            stm32_channel = ADC_CHANNEL_7;
            break;
        case 8:
            stm32_channel = ADC_CHANNEL_8;
            break;
        case 9:
            stm32_channel = ADC_CHANNEL_9;
            break;
        case 10:
            stm32_channel = ADC_CHANNEL_10;
            break;
        case 11:
            stm32_channel = ADC_CHANNEL_11;
            break;
        case 12:
            stm32_channel = ADC_CHANNEL_12;
            break;
        case 13:
            stm32_channel = ADC_CHANNEL_13;
            break;
        case 14:
            stm32_channel = ADC_CHANNEL_14;
            break;
        case 15:
            stm32_channel = ADC_CHANNEL_15;
            break;
#ifdef ADC_CHANNEL_16
        case 16:
            stm32_channel = ADC_CHANNEL_16;
            break;
#endif
        case 17:
            stm32_channel = ADC_CHANNEL_17;
            break;
#ifdef ADC_CHANNEL_18
        case 18:
            stm32_channel = ADC_CHANNEL_18;
            break;
#endif
#ifdef ADC_CHANNEL_19
        case 19:
            stm32_channel = ADC_CHANNEL_19;
            break;
#endif
    }

    return stm32_channel;
}

static uint32_t adc_get_cycles(HAL_ADC_SAMPLE_CYCLES cycles)
{
    uint32_t stm32_cycles = 0;

    switch (cycles) {
        case 0:
            stm32_cycles = ADC_SAMPLETIME_3CYCLES;
            break;
        case 1:
            stm32_cycles = ADC_SAMPLETIME_15CYCLES;
            break;
        case 2:
            stm32_cycles = ADC_SAMPLETIME_28CYCLES;
            break;
        case 3:
            stm32_cycles = ADC_SAMPLETIME_56CYCLES;
            break;
        case 4:
            stm32_cycles = ADC_SAMPLETIME_84CYCLES;
            break;
        case 5:
            stm32_cycles = ADC_SAMPLETIME_112CYCLES;
            break;
        case 6:
            stm32_cycles = ADC_SAMPLETIME_144CYCLES;
            break;
        case 7:
            stm32_cycles = ADC_SAMPLETIME_480CYCLES;
            break;
    }

    return stm32_cycles;
}
static int32_t adc_enabled(HAL_ADC_PORT port, bool_t enabled)
{
    ADC_HandleTypeDef *p_adc = adc_get_handle((uint8_t)port);

    if (enabled) {
        __HAL_ADC_ENABLE(p_adc);
    } else {
        __HAL_ADC_DISABLE(p_adc);
    }
    return ERR_OK;
}

int32_t hal_adc_regular_callback_register(HAL_ADC_PORT port, adc_callback_t cb)
{
    int32_t result = ERR_OK;
    hal_adc[port].regular_cb = cb;
    return result;
}

int32_t hal_adc_injection_callback_register(HAL_ADC_PORT port, adc_callback_t cb)
{
    int32_t result = ERR_OK;
    hal_adc[port].inj_cb = cb;
    return result;
}

int32_t hal_adc_init(HAL_ADC_PORT port)
{
    int result = ERR_OK;
    ADC_HandleTypeDef *p_adc = adc_get_handle((uint8_t)port);
    // if (hal_adc[port].is_inited == true) {
    //     return ERR_EXIST;
    // } else if (HAL_ADC_Init(p_adc) != HAL_OK) {
    //     return ERR_FAIL;
    // }
    if (HAL_ADC_Init(p_adc) != HAL_OK) {
        return ERR_FAIL;
    }
    // hal_adc[port].port = port;
    hal_adc[port].adc = p_adc;
    // hal_adc[port].cb = cb;
    // hal_adc[port].init = inj_cb;
    hal_adc[port].is_inited = true;

    return result;
}

int32_t hal_adc_set_channel(HAL_ADC_PORT port, uint8_t channel, uint8_t rank,
                            HAL_ADC_SAMPLE_CYCLES cycles)
{
    int32_t result = ERR_OK;
    ADC_ChannelConfTypeDef sconfig;
    ADC_HandleTypeDef *p_adc;
    uint32_t s32_channel;
    p_adc = hal_adc[port].adc;
    s32_channel = adc_get_channel(channel);
    sconfig.Channel = s32_channel;
    sconfig.Rank = rank;
    sconfig.SamplingTime = adc_get_cycles(cycles);
    if (HAL_ADC_ConfigChannel(p_adc, &sconfig) != HAL_OK) {

        result = ERR_FAIL;
    }
    return result;
}

int32_t hal_adc_inj_set_channel(HAL_ADC_PORT port, uint8_t channel, uint8_t rank,
                                HAL_ADC_SAMPLE_CYCLES cycles)
{
    int32_t result = ERR_OK;
    ADC_InjectionConfTypeDef *inj_sconfig;
    ADC_HandleTypeDef *p_adc;
    p_adc = hal_adc[port].adc;
    inj_sconfig = adc_inj_get_handle(port);
    inj_sconfig->InjectedChannel = adc_get_channel(channel);
    inj_sconfig->InjectedRank = rank;
    inj_sconfig->InjectedSamplingTime = adc_get_cycles(cycles);
    if (HAL_ADCEx_InjectedConfigChannel(p_adc, inj_sconfig) != HAL_OK) {

        result = ERR_FAIL;
    }
    return result;
}

int32_t hal_adc_get_value(HAL_ADC_PORT port, uint8_t channel, uint32_t *value)
{
    ADC_ChannelConfTypeDef ADC_ChanConf;

    memset(&ADC_ChanConf, 0, sizeof(ADC_ChanConf));

    // /* set stm32 ADC channel */
    // ADC_ChanConf.Channel = adc_get_channel(channel);
    // ADC_ChanConf.Rank = 1;
    // ADC_ChanConf.SamplingTime = ADC_SAMPLETIME_15CYCLES;

    // HAL_ADC_ConfigChannel(hal_adc[port].adc, &ADC_ChanConf);

    /* start ADC */
    HAL_ADC_Start(hal_adc[port].adc);

    /* Wait for the ADC to convert */
    HAL_ADC_PollForConversion(hal_adc[port].adc, 100);

    /* get ADC value */
    *value = (uint32_t)HAL_ADC_GetValue(hal_adc[port].adc);

    return ERR_OK;
}

int32_t hal_adc_deinit(HAL_ADC_PORT port)
{
    int result = ERR_OK;

    if (HAL_ADC_DeInit(hal_adc[port].adc) != HAL_OK) {
        result = ERR_FAIL;
        goto out;
    }

    adc_enabled(port, false);
out:
    return result;
}

int32_t hal_adc_start_it(uint32_t port, bool_t is_inj_channel)
{
    int32_t result = ERR_OK;
    ADC_HandleTypeDef *p_adc;
    p_adc = hal_adc[port].adc;

    if (is_inj_channel) {
    
        if (HAL_ADCEx_InjectedStart_IT(p_adc) != HAL_OK)
            result = ERR_FAIL;
    } else {

        if (HAL_ADC_Start_IT(p_adc) != HAL_OK)
            result = ERR_FAIL;
    }

    return result;
}

int32_t hal_adc_start_dma(uint32_t port, uint32_t *pbuffer, uint8_t length)
{
    int32_t result;
    ADC_HandleTypeDef *p_adc;

    p_adc = hal_adc[port].adc;
    hal_adc[port].regular_buffer = pbuffer;
    HAL_ADC_Start_DMA(p_adc, pbuffer, length);

    return result;
}

int32_t hal_adc_get_inj_value(HAL_ADC_PORT port, uint8_t rank_channel){
    ADC_HandleTypeDef *p_adc;
    p_adc = hal_adc[port].adc;
    return HAL_ADCEx_InjectedGetValue(p_adc, rank_channel);  

}

void ADC_IRQHandler(void)
{
      ADC_HandleTypeDef *adc = adc_get_handle((uint8_t)HAL_PORT_ADC_0);
      HAL_ADC_IRQHandler(adc);
}

void DMA2_Stream0_IRQHandler(void)
{
    /* USER CODE BEGIN DMA2_Stream0_IRQn 0 */
    ADC_HandleTypeDef *adc = adc_get_handle((uint8_t)HAL_PORT_ADC_0);
    HAL_DMA_IRQHandler(adc->DMA_Handle);
    /* USER CODE END DMA2_Stream0_IRQn 0 */
    /* USER CODE BEGIN DMA2_Stream0_IRQn 1 */
    
    /* USER CODE END DMA2_Stream0_IRQn 1 */
}

/**
  * @brief  Conversion complete callback in non blocking mode
  * @param  AdcHandle : AdcHandle handle
  * @note   This example shows a simple way to report end of conversion, and
  *         you can add your own implementation.
  * @retval None
  */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *AdcHandle)
{
    /* Get the converted value of regular channel */
    //   uhADCxConvertedValue = HAL_ADC_GetValue(AdcHandle);
    // uint32_t value = HAL_ADC_GetValue(AdcHandle);

    hal_adc[HAL_PORT_ADC_0].regular_cb(NULL);//even DMA irq handler will run this code
}

/**
  * @brief  Conversion complete callback in non blocking mode 
  * @param  AdcHandle : AdcHandle handle
  * @note   This example shows a simple way to report end of conversion, and 
  *         you can add your own implementation.    
  * @retval None
  */
void HAL_ADCEx_InjectedConvCpltCallback(ADC_HandleTypeDef* AdcHandle)
{
  /* Get the converted value of injected channel */
   hal_adc[HAL_PORT_ADC_0].inj_cb(NULL);//even DMA irq handler will run this code    
}
