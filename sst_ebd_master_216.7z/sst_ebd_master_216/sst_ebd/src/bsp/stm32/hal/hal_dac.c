#include "types.h"
#include "string.h"

#include "hal_internal.h"
#include "hal_dac.h"

static DAC_HandleTypeDef dac_config = {
    .Instance = DAC1,
};

static uint32_t dac_get_channel(uint32_t channel)
{
    uint32_t stm32_channel = 0;

    switch (channel) {
        case 1:
            stm32_channel = DAC_CHANNEL_1;
            break;
        case 2:
            stm32_channel = DAC_CHANNEL_2;
            break;
        default:
            break;
    }

    return stm32_channel;
}

int32_t hal_dac_init(void)
{
    int result = ERR_OK;

    if (HAL_DAC_Init(&dac_config) != HAL_OK) {
        result = ERR_FAIL;
    }

    return result;
}

int32_t hal_dac_set_value(uint32_t channel, uint32_t value)
{
    int32_t result = ERR_OK;
    uint32_t dac_channel;
    DAC_ChannelConfTypeDef DAC_ChanConf;

    memset(&DAC_ChanConf, 0, sizeof(DAC_ChanConf));

    /* set stm32 dac channel */
    dac_channel = dac_get_channel(channel);

    DAC_ChanConf.DAC_Trigger = DAC_TRIGGER_NONE;
    DAC_ChanConf.DAC_OutputBuffer = DAC_OUTPUTBUFFER_DISABLE;
    /* config dac out channel*/
    if (HAL_DAC_ConfigChannel(&dac_config, &DAC_ChanConf, dac_channel) != HAL_OK) {
        result = ERR_FAIL;
        goto out;
    }
    /* set dac channel out value*/
    if (HAL_DAC_SetValue(&dac_config, dac_channel, DAC_ALIGN_12B_R, value) != HAL_OK) {
        result = ERR_FAIL;
        goto out;
    }
    /* start dac */
    if (HAL_DAC_Start(&dac_config, dac_channel) != HAL_OK) {
        result = ERR_FAIL;
        goto out;
    }

out:
    return result;
}

int32_t hal_dac_deinit(void)
{
    int result = ERR_OK;

    if (HAL_DAC_DeInit(&dac_config) != HAL_OK) {
        result = ERR_FAIL;
    }
    return result;
}