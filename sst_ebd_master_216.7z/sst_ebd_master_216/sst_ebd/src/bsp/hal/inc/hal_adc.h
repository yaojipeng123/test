
#ifndef HAL_ADC_H
#define HAL_ADC_H

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    HAL_PORT_ADC_0,
    HAL_PORT_ADC_1,
    HAL_PORT_ADC_2,
    HAL_PORT_ADC_3,
    HAL_ADC_PORT_MAX,
} HAL_ADC_PORT;
typedef enum {
    ADC_SampleTime_3Cycles,
    ADC_SampleTime_15Cycles,
    ADC_SampleTime_28Cycles,
    ADC_SampleTime_56Cycles,
    ADC_SampleTime_84Cycles,
    ADC_SampleTime_112Cycles,
    ADC_SampleTime_144Cycles,
    ADC_SampleTime_480Cycles,
} HAL_ADC_SAMPLE_CYCLES;


/** @defgroup ADC_channels 
  * @{
  */ 
#define ADC_Channel_0                               ((uint8_t)0x00)
#define ADC_Channel_1                               ((uint8_t)0x01)
#define ADC_Channel_2                               ((uint8_t)0x02)
#define ADC_Channel_3                               ((uint8_t)0x03)
#define ADC_Channel_4                               ((uint8_t)0x04)
#define ADC_Channel_5                               ((uint8_t)0x05)
#define ADC_Channel_6                               ((uint8_t)0x06)
#define ADC_Channel_7                               ((uint8_t)0x07)
#define ADC_Channel_8                               ((uint8_t)0x08)
#define ADC_Channel_9                               ((uint8_t)0x09)
#define ADC_Channel_10                              ((uint8_t)0x0A)
#define ADC_Channel_11                              ((uint8_t)0x0B)
#define ADC_Channel_12                              ((uint8_t)0x0C)
#define ADC_Channel_13                              ((uint8_t)0x0D)
#define ADC_Channel_14                              ((uint8_t)0x0E)
#define ADC_Channel_15                              ((uint8_t)0x0F)
#define ADC_Channel_16                              ((uint8_t)0x10)
#define ADC_Channel_17                              ((uint8_t)0x11)
#define ADC_Channel_18                              ((uint8_t)0x12)

typedef void adc_callback_t(void *data);

int32_t hal_adc_init(HAL_ADC_PORT port);

// /**
//  * @brief  adc injection channel callback 
//  *
//  * @return int32_t
//  */

int32_t hal_adc_injection_callback_register(HAL_ADC_PORT port, adc_callback_t cb);
// /**
//  * @brief  regular adc channel callback
//  *
//  * @return int32_t
//  */
int32_t hal_adc_regular_callback_register(HAL_ADC_PORT port, adc_callback_t cb);

/**
 * @brief 
 * 
 * @param channel 
 * @param value 
 * @return int32_t 
 */
int32_t hal_adc_get_value(HAL_ADC_PORT port, uint8_t channel, uint32_t *value);

/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t hal_adc_deinit(HAL_ADC_PORT port);

/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t hal_adc_start_dma(uint32_t port, uint32_t *pbuffer, uint8_t length);

int32_t hal_adc_set_channel(HAL_ADC_PORT port, uint8_t channel, uint8_t rank,
                            HAL_ADC_SAMPLE_CYCLES cycles);

int32_t hal_adc_inj_set_channel(HAL_ADC_PORT port, uint8_t channel, uint8_t rank,
                                HAL_ADC_SAMPLE_CYCLES cycles);

int32_t hal_adc_start_it(uint32_t port, bool is_inj_channel);

int32_t hal_adc_get_inj_value(HAL_ADC_PORT port, uint8_t rank_channel);
#ifdef __cplusplus
}
#endif

#endif /* HAL_ADC_H */
