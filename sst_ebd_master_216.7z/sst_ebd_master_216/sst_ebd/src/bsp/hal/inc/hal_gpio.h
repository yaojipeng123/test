#ifndef HAL_GPIO_H
#define HAL_GPIO_H

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    HAL_GPIO_0 = 0,
    HAL_GPIO_1,
    HAL_GPIO_2,
    HAL_GPIO_3,
    HAL_GPIO_4,
    HAL_GPIO_5,
    HAL_GPIO_6,
    HAL_GPIO_7,
    HAL_GPIO_8,
    HAL_GPIO_9,
    HAL_GPIO_10,
    HAL_GPIO_11,
    HAL_GPIO_12,
    HAL_GPIO_13,
    HAL_GPIO_14,
    HAL_GPIO_15,
    HAL_GPIO_16,
    HAL_GPIO_17,
    HAL_GPIO_18,
    HAL_GPIO_19,
    HAL_GPIO_20,
    HAL_GPIO_21,
    HAL_GPIO_22,
    HAL_GPIO_23,
    HAL_GPIO_24,
    HAL_GPIO_25,
    HAL_GPIO_26,
    HAL_GPIO_27,
    HAL_GPIO_28,
    HAL_GPIO_29,
    HAL_GPIO_30,
    HAL_GPIO_31,
    HAL_GPIO_32,
    HAL_GPIO_33,
    HAL_GPIO_34,
    HAL_GPIO_35,
    HAL_GPIO_36,
    HAL_GPIO_37,
    HAL_GPIO_38,
    HAL_GPIO_39,
    HAL_GPIO_40,
    HAL_GPIO_41,
    HAL_GPIO_42,
    HAL_GPIO_43,
    HAL_GPIO_44,
    HAL_GPIO_45,
    HAL_GPIO_46,
    HAL_GPIO_47,
    HAL_GPIO_48,
    HAL_GPIO_49,
    HAL_GPIO_50,
    HAL_GPIO_51,
    HAL_GPIO_52,
    HAL_GPIO_53,
    HAL_GPIO_54,
    HAL_GPIO_55,
    HAL_GPIO_56,
    HAL_GPIO_57,
    HAL_GPIO_58,
    HAL_GPIO_59,
    HAL_GPIO_60,
    HAL_GPIO_61,
    HAL_GPIO_62,
    HAL_GPIO_63,
    HAL_GPIO_64,
    HAL_GPIO_65,
    HAL_GPIO_66,
    HAL_GPIO_67,
    HAL_GPIO_68,
    HAL_GPIO_69,
    HAL_GPIO_70,
    HAL_GPIO_71,
    HAL_GPIO_72,
    HAL_GPIO_73,
    HAL_GPIO_74,
    HAL_GPIO_75,
    HAL_GPIO_76,
    HAL_GPIO_77,
    HAL_GPIO_78,
    HAL_GPIO_79,
    HAL_GPIO_80,
    HAL_GPIO_81,
    HAL_GPIO_82,
    HAL_GPIO_83,
    HAL_GPIO_84,
    HAL_GPIO_85,
    HAL_GPIO_86,
    HAL_GPIO_87,
    HAL_GPIO_88,
    HAL_GPIO_89,
    HAL_GPIO_90,
    HAL_GPIO_91,
    HAL_GPIO_92,
    HAL_GPIO_93,
    HAL_GPIO_94,
    HAL_GPIO_95,
    HAL_GPIO_96,
    HAL_GPIO_97,
    HAL_GPIO_98,
    HAL_GPIO_99,
    HAL_GPIO_100,
    HAL_GPIO_101,
    HAL_GPIO_102,
    HAL_GPIO_103,
    HAL_GPIO_104,
    HAL_GPIO_105,
    HAL_GPIO_106,
    HAL_GPIO_107,
    HAL_GPIO_108,
    HAL_GPIO_109,
    HAL_GPIO_110,
    HAL_GPIO_111,
    HAL_GPIO_112,
    HAL_GPIO_113,
    HAL_GPIO_114,
    HAL_GPIO_115,
    HAL_GPIO_116,
    HAL_GPIO_117,
    HAL_GPIO_118,
    HAL_GPIO_119,
    HAL_GPIO_120,
    HAL_GPIO_121,
    HAL_GPIO_122,
    HAL_GPIO_123,
    HAL_GPIO_124,
    HAL_GPIO_125,
    HAL_GPIO_126,
    HAL_GPIO_127,
    HAL_GPIO_128,
    HAL_GPIO_129,
    HAL_GPIO_130,
    HAL_GPIO_131,
    HAL_GPIO_132,
    HAL_GPIO_133,
    HAL_GPIO_134,
    HAL_GPIO_135,
    HAL_GPIO_136,
    HAL_GPIO_137,
    HAL_GPIO_138,
    HAL_GPIO_139,
    HAL_GPIO_140,
    HAL_GPIO_141,
    HAL_GPIO_142,
    HAL_GPIO_143,

    HAL_GPIO_MAX,
} HAL_GPIO_ID;

typedef enum {
    HAL_GPIO_INPUT = 0,
    HAL_GPIO_OUTPUT,
    HAL_GPIO_INPUT_PULLUP,
    HAL_GPIO_INPUT_PULLDOWN,
    HAL_GPIO_OUTPUT_OD,
    // HAL_GPIO_IRQ,
} HAL_GPIO_DIRECTION;

/**
  * @brief Modes of interrupt. Only when gpio_mode set as GPIO_INTERRUPT,
  * int_mode is available.
  */
typedef enum {
    /**< Disable the interrupt. */
    HAL_GPIO_INT_DISABLE,
    /**< Interrupt triggered when switchs from LOW to HIGH. */
    HAL_GPIO_INT_EDGE_RISING,
    /**< Interrupt triggered when switchs from HIGH to LOW. */
    HAL_GPIO_INT_EDGE_FALLING,
    /**< Interrupt triggered when switchs to HIGH or LOW . */
    HAL_GPIO_INT_EDGE_BOTH,
    /**< Interrupt triggered when stays in LOW. */
    HAL_GPIO_INT_LEVEL_LOW,
    /**< Interrupt triggered when stays in HIGH. */
    HAL_GPIO_INT_LEVEL_HIGH,
    /**< Invalid value */
    HAL_GPIO_INT_MODE_MAX
} HAL_GPIO_INT_MODE;

/*
 * GPIO interrupt callback handler
 */
typedef void (*gpio_irq_handler_t)(void *arg);

/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t hal_gpio_init(void);

/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t hal_gpio_deinit(void);

/**
 * @brief 
 * 
 * @param gpio 
 * @param dir 
 * @return int32_t 
 */
int32_t hal_gpio_open(uint8_t gpio, HAL_GPIO_DIRECTION dir);

/**
 * @brief 
 * 
 * @param gpio 
 * @return int32_t 
 */
int32_t hal_gpio_close(uint8_t gpio);

/**
 * @brief 
 * 
 * @param gpio 
 * @return int32_t 
 */
int32_t hal_gpio_output_toggle(uint8_t gpio);

/**
 * @brief 
 * 
 * @param gpio 
 * @return int32_t 
 */
int32_t hal_gpio_output_high(uint8_t gpio);

/**
 * @brief 
 * 
 * @param gpio 
 * @return int32_t 
 */
int32_t hal_gpio_output_low(uint8_t gpio);

/**
 * @brief 
 * 
 * @param gpio 
 * @param value 
 * @return int32_t 
 */
int32_t hal_gpio_input_get(uint8_t gpio, uint32_t *value);

/**
 * @brief 
 * 
 * @param gpio 
 * @param trigger 
 * @param handler 
 * @param arg 
 * @return int32_t 
 */
int32_t hal_gpio_attach_irq(uint8_t gpio, HAL_GPIO_INT_MODE trigger, gpio_irq_handler_t handler,
                            void *arg);

/**
 * @brief 
 * 
 * @param gpio 
 * @return int32_t 
 */
int32_t hal_gpio_dettach_irq(uint8_t gpio);

/**
 * @brief 
 * 
 * @param gpio 
 * @param enable 
 * @return int32_t 
 */
int32_t hal_gpio_enable_irq(uint8_t gpio, bool_t enable);

/**
 * @brief 
 * 
 * @param gpio 
 * @param enable 
 * @return int32_t 
 */
int32_t hal_gpio_quick_enable_irq(uint8_t gpio, bool_t enable);

#ifdef __cplusplus
}
#endif

#endif   //HAL_GPIO_H
