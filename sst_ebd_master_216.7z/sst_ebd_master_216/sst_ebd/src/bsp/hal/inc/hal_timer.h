#ifndef HAL_TIMER_H
#define HAL_TIMER_H

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    HAL_TIMER_PORT0 = 0,
    HAL_TIMER_PORT1,
    HAL_TIMER_PORT2,
    HAL_TIMER_PORT3,

    HAL_TIMER_PORT_MAX,
} HAL_TIMER_PORT;

/**
 * @defgroup hal_timer_typedef Typedef
 * @{
 */
typedef void timer_callback_t(void *data);

/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t hal_timer_init(void);

/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t hal_timer_deinit(void);

/**
 * @brief 
 * 
 * @return uint32_t 
 */
uint32_t hal_timer_get_time(void);

/**
 * @brief 
 * @param id
 * @return uint32_t 
 */
uint32_t hal_timer_get_counter_id(uint8_t id);

/**
 * @brief 
 * @param id
 * @param counter
 * @return uint32_t 
 */
uint32_t hal_timer_set_counter_id(uint8_t id,uint32_t counter);

/**
 * @brief 
 * 
 * @param id 
 * @param period 
 * @param repeat 
 * @param handler 
 * @param data 
 * @return int32_t 
 */
int32_t hal_timer_create(uint8_t *id, uint32_t period, bool_t repeat, timer_callback_t handler,
                         void *data);

/**
 * @brief 
 * 
 * @param id 
 * @return int32_t 
 */
int32_t hal_timer_encode_init(uint8_t *id);

/**
 * @brief 
 * 
 * @param id 
 * @return int8_t 
 */
int8_t hal_encoder_get_direction(uint8_t id);
/**
 * @brief 
 * 
 * @param id 
 * @return int32_t 
 */
int32_t hal_timer_start(uint8_t id);

/**
 * @brief 
 * 
 * @param id 
 * @return int32_t 
 */
int32_t hal_timer_stop(uint8_t id);

/**
 * @brief 
 * 
 * @param id 
 * @return int32_t 
 */
int32_t hal_timer_delete(uint8_t id);

/**
 * @brief 
 * 
 * @param us 
 */
void hal_timer_delay_us(uint32_t us);

/**
 * @brief 
 * 
 * @param ms 
 */
void hal_timer_delay_ms(uint32_t ms);

#ifdef __cplusplus
}
#endif

#endif   // HAL_TIMER_H
