#ifndef HAL_SPI_H
#define HAL_SPI_H

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    HAL_SPI_PORT0 = 0,
    HAL_SPI_PORT1,
    HAL_SPI_PORT2,
    HAL_SPI_PORT3,

    HAL_UART_PORT_MAX,
} HAL_SPI_PORT;
typedef enum {
    SPI_ROLE_SLAVE,
    SPI_ROLE_MASTER,
} HAL_SPI_ROLE;

typedef enum {
    SPI_MSB = 0,
    SPI_LSB,
} HAL_SPI_FIRST_BIT;

/*!<CLK IDLE Polarity and Phase delay */

typedef enum {
    SPI_IDLE_LOW = 0,
    SPI_IDLE_HIGH,
} HAL_SPI_IDLE_CLK;

typedef enum {
    SPI_CLK_1EDGE = 0,
    SPI_CLK_2EDGE,
} HAL_SPI_CLK_PHASE;

// typedef enum
// {
//     SPI_TRANSFER_DMA,
//     SPI_TRANSFER_NORMAL,
// } HAL_SPI_TRANS_MODE;

/* size of single spi prescaler data */
typedef enum {
    SPI_PRESCALER_2 = 0,
    SPI_PRESCALER_4,
    SPI_PRESCALER_8,
    SPI_PRESCALER_16,
    SPI_PRESCALER_32,
    SPI_PRESCALER_64,
    SPI_PRESCALER_128,
    SPI_PRESCALER_256,
} HAL_SPI_PRESCALER;

/* size of single spi frame data */
typedef enum {
    SPI_DATA_8BIT = 0,
    SPI_DATA_16BIT,
} HAL_SPI_DATA_SIZE;

// /* cs signal to active for transfer */
// typedef enum
// {
//     SPI_CS_DIS,
//     SPI_CS_EN,
// } HAL_SPI_CS;

/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t hal_spi_init(void);

/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t hal_spi_deinit(void);

/**
 * @brief 
 * 
 * @param port 
 * @param prescaler 
 * @param role 
 * @param mode 
 * @param polarity 
 * @param delay 
 * @param length 
 * @return int32_t 
 */
int32_t hal_spi_open(HAL_SPI_PORT port, HAL_SPI_PRESCALER prescaler, HAL_SPI_ROLE role,
                     HAL_SPI_FIRST_BIT mode, HAL_SPI_IDLE_CLK polarity, HAL_SPI_CLK_PHASE delay,
                     HAL_SPI_DATA_SIZE length);

/**
 * @brief 
 * 
 * @param port 
 * @return int32_t 
 */
int32_t hal_spi_close(HAL_SPI_PORT port);

/**
 * @brief 
 * 
 * @param port 
 * @param data 
 * @param length 
 * @return int32_t 
 */
int32_t hal_spi_send(HAL_SPI_PORT port, uint8_t *data, uint32_t length);

/**
 * @brief 
 * 
 * @param port 
 * @param data 
 * @param length 
 * @return int32_t 
 */
int32_t hal_spi_receive(HAL_SPI_PORT port, uint8_t *data, uint32_t length);

/**
 * @brief 
 * 
 * @param port 
 * @param tx_data 
 * @param rx_data 
 * @param size 
 * @return int32_t 
 */
int32_t hal_spi_send_recv(HAL_SPI_PORT port, uint8_t *tx_data, uint8_t *rx_data, uint16_t size);

#ifdef __cplusplus
}
#endif

#endif   //HAL_SPI_h
