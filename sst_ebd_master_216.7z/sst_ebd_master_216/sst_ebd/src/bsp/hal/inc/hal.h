#ifndef HAL_H
#define HAL_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 
 *  
 */
void hal_bsp_init(void);

#ifdef __cplusplus
}
#endif

#endif   // HAL_H
