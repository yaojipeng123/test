#ifndef HAL_PWM_H
#define HAL_PWM_H

#ifdef __cplusplus
extern "C" {
#endif

#define PWM_NUM_MAX     HAL_PWM_PORT_MAX

typedef enum {
    HAL_PWM_PORT0 = 0,
    HAL_PWM_PORT1,
    HAL_PWM_PORT2,
    HAL_PWM_PORT3,
    HAL_PWM_PORT_MAX,
} HAL_PWM_PORT;

/**
 * @brief 
 * @param id
 * @param period
 * @param psc
 * @return int32_t 
 */
int32_t hal_pwm_init(uint8_t id,uint32_t period,uint32_t psc);
/**
 * @brief 
 * @param id
 * @return int32_t 
 */
int32_t hal_pwm_deinit(uint8_t id);

/**
 * @brief 
 * @param id
 * @param ocmode
 * @param pulse
 * @param ocpolarity
 * @param channel
 * @return int32_t 
 */
int32_t hal_pwm_start(uint8_t id,bool ocmode,uint32_t pulse,bool ocpolarity,uint32_t channel);

/**
 * @brief 
 * @param id
 * @param channel
 * @return int32_t 
 */
int32_t hal_pwm_stop(uint8_t id,uint32_t channel);

/**
 * @brief 
 * @param id
 * @param period
 * @return int32_t 
 */
int32_t hal_pwm_cycle_chg(uint8_t id,uint32_t period);

/**
 * @brief 
 * @param id
 * @param pulse
 * @param channel
 * @return int32_t 
 */
int32_t hal_pwm_freq_chg(uint8_t id,uint32_t pulse,uint32_t channel);

#ifdef __cplusplus
}
#endif

#endif //HAL_PWM_H
