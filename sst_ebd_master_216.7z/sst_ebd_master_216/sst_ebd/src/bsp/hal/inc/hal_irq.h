#ifndef HAL_IRQ_H
#define HAL_IRQ_H

#ifdef __cplusplus
 extern "C" {
#endif

/*
* interrupt priority
*/
typedef enum {
    HAL_INTR_PRI_0 = 0,
    HAL_INTR_PRI_1,
    HAL_INTR_PRI_2,
    HAL_INTR_PRI_3,
    HAL_INTR_PRI_4,
    HAL_INTR_PRI_5,
    HAL_INTR_PRI_6,
    HAL_INTR_PRI_7,

    HAL_INTR_PRI_MAX
} HAL_INTR_PRIORITY;

typedef uint32_t hal_irq_t;

/*
* interrupt service routine prototype.
*/
typedef uint32_t (*hal_isr_t)(uint32_t vector, uint32_t data);

/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t hal_irq_init(void);

/**
 * @brief 
 * 
 * @param vector 
 * @param data 
 * @param isr 
 * @return hal_irq_t 
 */
hal_irq_t hal_irq_create(uint32_t vector, uint32_t data, hal_isr_t isr);

/**
 * @brief 
 * 
 * @param vector 
 * @param data 
 */
void hal_irq_set_data(uint32_t vector, uint32_t data);

/**
 * @brief 
 * 
 * @param interrupt 
 */
void hal_irq_delete(hal_irq_t interrupt);

/**
 * @brief 
 * 
 * @param interrupt 
 */
void hal_irq_mask(hal_irq_t interrupt);

/**
 * @brief 
 * 
 * @param interrupt 
 */
void hal_irq_unmask(hal_irq_t interrupt);

/**
 * @brief 
 * 
 * @param interrupt 
 */
void hal_irq_acknowledge(hal_irq_t interrupt);

/**
 * @brief 
 * 
 * @param interrupt 
 * @param level 
 * @param up 
 */
void hal_irq_configure(hal_irq_t interrupt, uint32_t level, uint32_t up);

/**
 * @brief 
 * 
 * @param interrupt 
 * @param priority 
 */
void hal_irq_priority(hal_irq_t interrupt, uint32_t priority);

/**
 * @brief 
 * 
 * @param vector 
 */
void hal_irq_deliver(uint32_t vector);

#ifdef __cplusplus
}
#endif

#endif //HAL_IRQ_H
