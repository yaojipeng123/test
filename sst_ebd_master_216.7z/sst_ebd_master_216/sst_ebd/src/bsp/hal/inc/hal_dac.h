#ifndef HAL_DAC_H
#define HAL_DAC_H

#ifdef __cplusplus
 extern "C" {
#endif

/**
 * @brief 
 * 
 * @param channel 
 * @param value 
 * @return int32_t 
 */
int32_t hal_dac_set_value(uint32_t channel, uint32_t value);

#ifdef __cplusplus
}
#endif

#endif /* HAL_DAC_H */

