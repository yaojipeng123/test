#ifndef HAL_FMC_H
#define HAL_FMC_H

#ifdef __cplusplus
 extern "C" {
#endif

/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t hal_fmc_nor_init(void);

/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t hal_fmc_sram_init(void);

#ifdef __cplusplus
}
#endif

#endif //HAL_FMC_H
