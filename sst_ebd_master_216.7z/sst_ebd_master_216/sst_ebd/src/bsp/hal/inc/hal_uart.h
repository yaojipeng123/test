#ifndef HAL_UART_H
#define HAL_UART_H

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    HAL_UART_PORT0 = 0,
    HAL_UART_PORT1,
    HAL_UART_PORT2,
    HAL_UART_PORT3,

    HAL_UART_PORT_MAX,
} HAL_UART_PORT;

/** Uart data bits */
typedef enum {
    /*!< Used for checking, the min value it can take */
    HAL_UART_DATA_BITS_MIN_BITS = 0,
    HAL_UART_DATA_BITS_8 = 0, /*!< 8 Data bits */
    /*!< Used for checking, the max value it can take*/
    HAL_UART_DATA_BITS_MAX_BITS,
} HAL_UART_DATA_BITS;

/** Uart parity modes */
typedef enum {
    HAL_UART_PARITY_NONE, /*!< No parity enabled */
    HAL_UART_PARITY_ODD,  /*!< Odd parity        */
    HAL_UART_PARITY_EVEN, /*!< Even parity       */
} HAL_UART_PARITY;

/** Uart stop bits modes */
typedef enum {
    HAL_UART_STOP_BITS_1 = 0, /*!< 1 Stop bit*/
    HAL_UART_STOP_BITS_2 = 1, /*!< 2 Stop bits */
} HAL_UART_STOP_BITS;

typedef enum {
    HAL_UART_FLOWCTRL_RTS,
    HAL_UART_FLOWCTRL_CTS,
    HAL_UART_FLOWCTRL_CTS_RTS,
} HAL_UART_FLOWCTRL;

typedef void (*hal_uart_transmit_callback)(HAL_UART_PORT port);
typedef void (*hal_uart_receive_callback)(HAL_UART_PORT port);
/**
 * @brief 
 * @param port
 * @param cb
 * @return int32_t 
 */
int32_t hal_uart_register_rx_callback(HAL_UART_PORT port, hal_uart_receive_callback cb);
/**
 * @brief 
 * @param port
 * @param cb
 * @return int32_t 
 */
int32_t hal_uart_register_tx_callback(HAL_UART_PORT port, hal_uart_transmit_callback cb);
/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t hal_uart_init(void);

/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t hal_uart_deinit(void);

/**
 * @brief 
 * 
 * @param port 
 * @param baud_rate 
 * @param data 
 * @param stop 
 * @param parity 
 * @return int32_t 
 */
int32_t hal_uart_open(HAL_UART_PORT port, uint32_t baud_rate, HAL_UART_DATA_BITS data,
                      HAL_UART_STOP_BITS stop, HAL_UART_PARITY parity);

/**
 * @brief 
 * 
 * @param port 
 * @return int32_t 
 */
int32_t hal_uart_close(HAL_UART_PORT port);

/**
 * @brief 
 * 
 * @param port 
 * @param buffer 
 * @param count 
 * @return int32_t 
 */
int32_t hal_uart_transmit(HAL_UART_PORT port, const void *buffer, uint32_t count);

/**
 * @brief 
 * 
 * @param port 
 * @param buffer 
 * @param count 
 * @return int32_t 
 */

int32_t hal_uart_receive(HAL_UART_PORT port, uint8_t *buffer, uint32_t count);

/**
 * @brief 
 * 
 * @param port 
 * @param buffer 
 * @param count 
 * @return int32_t 
 */

int32_t hal_uart_receive_it(HAL_UART_PORT port, uint8_t *buffer, uint32_t count);
/**
 * @brief 
 * 
 * @param port 
 * @return int32_t 
 */
int32_t hal_uart_start_receive_it(HAL_UART_PORT port);
/**
 * @brief 
 * 
 * @param port 
 * @param buffer 
 * @param expect_count 
 * @param a_actualsize
 * @return int32_t 
 */
int32_t hal_uart_receive_buffer(HAL_UART_PORT port, uint8_t *buffer, uint32_t expect_count,
                                uint32_t *a_actualsize);
/**
 * @brief 
 * 
 * @param port 
 * @param c 
 * @return int32_t 
 */
int32_t hal_uart_putc(HAL_UART_PORT port, uint8_t c);

/**
 * @brief 
 * 
 * @param port 
 * @return int32_t 
 */
int32_t hal_uart_getc(HAL_UART_PORT port);

#ifdef __cplusplus
}
#endif

#endif   // HAL_UART_H
