#include "types.h"
#include "stdio.h"
#include "test_spi.h"
#include "hal_spi.h"

#include "hal_gpio.h"

#include "unit_test.h"

#define TEST_SPI_CS HAL_GPIO_136   //(GPIOF, 6)

uint8_t spi_rcv_data[6] = { 0, 0, 0, 0, 0, 0 };
bool_t test_spi_init(void)
{
    hal_spi_open(HAL_SPI_PORT0, SPI_PRESCALER_16, SPI_ROLE_MASTER, SPI_MSB, SPI_IDLE_LOW,
                 SPI_CLK_1EDGE, SPI_DATA_8BIT);

    hal_gpio_init();
    hal_gpio_open(TEST_SPI_CS, HAL_GPIO_OUTPUT);
    return true;
}

bool_t test_spi_senddata(uint8_t *data, uint32_t length)
{
    hal_gpio_output_low(TEST_SPI_CS);

    hal_spi_send(HAL_SPI_PORT0, &data, length);

    hal_gpio_output_high(TEST_SPI_CS);
    return true;
}

// int32_t test_spi_send_rcv(uint8_t* send_buf,uint8_t* rcv_buf ,uint32_t length)
// {
//     uint8_t data[6] = {0,0,0,0,0,0};
//     hal_gpio_output_low(TEST_SPI_CS);
//     hal_spi_send_recv(HAL_SPI_PORT0,&send_buf,&rcv_buf,length);
//     hal_gpio_output_high(TEST_SPI_CS);
//     for(int i=0;i<length;i++)
//     {
//         data[i] = *rcv_buf;
//         rcv_buf++;
//     }
//     return data[1];
// }
static void ad7738_set_regester(uint8_t cmd, uint8_t val)
{
    uint8_t send_buf[2] = { 0, 0 };

    send_buf[0] = cmd;
    send_buf[1] = val;
    test_spi_senddata(send_buf, 2);
}

uint8_t ad7738_get_regester(uint8_t cmd)
{
    uint8_t send_buf[2] = { 0, 0 };
    // uint8_t            rcv_buf[2]  = {0, 0};
    send_buf[0] = cmd;
    hal_gpio_output_low(TEST_SPI_CS);
    hal_spi_send_recv(HAL_SPI_PORT0, &send_buf, &spi_rcv_data, 2);
    hal_gpio_output_high(TEST_SPI_CS);
    return spi_rcv_data[1];
}

bool_t test_spi_run(void)
{
    uint8_t reset_msg[] = { 0xff, 0xff, 0xff, 0xff };
    uint8_t send_msg[]  = { 0x48, 0, 0, 0, 0, 0 };
    uint8_t rcv_msg[6]  = { 0, 0, 0, 0, 0, 0 };
    test_spi_senddata(reset_msg, 4);   //复位dac7738芯片

    ad7738_set_regester(0x28, 0x6d);
    ad7738_get_regester(0x68);
    ad7738_set_regester(0x38, 0x22);
    while(!ad7738_get_regester(0x44)) {
    }
    ad7738_get_regester(0x48);
    //test_spi_send_rcv(send_msg,rcv_msg,6);
    return true;
}

bool_t test_spi_clean(void)
{
    hal_spi_close(HAL_SPI_PORT0);
    hal_gpio_close(TEST_SPI_CS);

    return true;
}

TEST_MODULE(spi_test, test_spi_init, test_spi_run, test_spi_clean, 1);
