#ifndef _TEST_SPI_H
#define _TEST_SPI_H

bool_t test_spi_init(void);
bool_t test_spi_run(void);
bool_t test_spi_clean(void);

#endif /* TEST_SPI_H */