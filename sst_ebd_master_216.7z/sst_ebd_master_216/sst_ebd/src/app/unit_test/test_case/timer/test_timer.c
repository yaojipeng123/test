#include "types.h"
#include "stdio.h"
#include "test_timer.h"
#include "hal_timer.h"

#include "unit_test.h"

uint8_t test_timer_id;

static int32_t test_timer_cb(void *data)
{
    printf("timer fired.\n");

    return 0;
}

bool_t test_timer_init(void)
{
    int32_t ret = hal_timer_create(&test_timer_id, 1000, false, test_timer_cb, NULL);

    if (ret){
        printf("timer create failed\n");
        return false;
    }

    return true;
}

bool_t test_timer_run(void)
{
    uint32_t count = 0;

    hal_timer_start(test_timer_id);

    while (count < 10) {
        printf("hello world\n");
        hal_timer_delay_us(50000);
        count++;
    }

    return true;
}

bool_t test_timer_clean(void)
{
    hal_timer_stop(test_timer_id);

    hal_timer_delete(test_timer_id);
}

// TEST_MODULE(timer_test, test_timer_init, test_timer_run, test_timer_clean, 1);
