#ifndef TEST_TIMER_H
#define TEST_TIMER_H

bool_t test_timer_init(void);
bool_t test_timer(void);
bool_t test_timer_clean(void);

#endif /* TEST_TIMER_H */
