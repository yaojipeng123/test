#include "types.h"
#include "stdio.h"
#include "unit_test.h"

#include "hal_gpio.h"
#include "hal_timer.h"
#include "test_gpio.h"
#include "gpio_dev.h"
#define TEST_GPIO_INPUT  HAL_GPIO_115   //(GPIOH, 3)
#define TEST_GPIO_OUTPUT HAL_GPIO_17    //(GPIOB, 1)
#define INT_ESC_PIN      HAL_GPIO_8

// void test_callback();

uint32_t test_gpio_int_count = 0;

static void test_gpio_callback(void *arg)
{
    UNUSED(arg);

    printf("[GPIO%d] int done\n", TEST_GPIO_INPUT);
    test_gpio_int_count++;
}

bool_t test_gpio_run(void)
{
    int i;
    uint32_t val;

    for (i = 0; i < 3; i++) {
        hal_gpio_output_toggle(TEST_GPIO_OUTPUT);
        hal_gpio_input_get(TEST_GPIO_INPUT, &val);
        printf("gpio%d val: %d\n", TEST_GPIO_INPUT, val);
        hal_timer_delay_ms(1000);
    }

    return true;
}

bool_t test_gpio_init(void)
{
    hal_gpio_init();
    hal_gpio_open(TEST_GPIO_OUTPUT, HAL_GPIO_OUTPUT);   //正常IO输出配置

    hal_gpio_open(TEST_GPIO_INPUT, HAL_GPIO_INPUT);   //正常IO输入配置
    hal_gpio_attach_irq(TEST_GPIO_INPUT, HAL_GPIO_INT_EDGE_BOTH, test_gpio_callback,
                        NULL);                    //配置中断
    hal_gpio_enable_irq(TEST_GPIO_INPUT, true);   //使能中断
    return true;
}

bool_t test_gpio_clean(void)
{
    hal_gpio_enable_irq(TEST_GPIO_INPUT, false);
    hal_gpio_dettach_irq(TEST_GPIO_INPUT);

    hal_gpio_close(TEST_GPIO_INPUT);
    hal_gpio_close(TEST_GPIO_OUTPUT);

    return true;
}

// void test_callback()
// {
//     printf("enter irq\n");
// }

// TEST_MODULE(gpio_test, test_gpio_init, test_gpio_run, NULL, 1);
