#ifndef _TEST_IOMAP_H
#define _TEST_IOMAP_H

bool_t test_iomap_init(void);
bool_t test_iomap_run(void);

#endif /* _TEST_IOMAP_H */
