#include "types.h"
#include "stdio.h"
#include "unit_test.h"

#include "hal_gpio.h"
#include "hal_timer.h"

bool_t test_iomap_init(void)
{
    return true;
}

bool_t test_iomap_run(void)
{
    printf("hello world\n");

    return true;
}

// TEST_MODULE(iomap_test, test_iomap_init, test_iomap_run, NULL, 1);
