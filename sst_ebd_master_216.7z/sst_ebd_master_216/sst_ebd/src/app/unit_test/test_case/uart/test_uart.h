#ifndef _TEST_UART_H
#define _TEST_UART_H

bool_t test_uart_init(void);
bool_t test_uart_run(void);
bool_t test_uart_clean(void);

#endif /* _TEST_UART_H */
