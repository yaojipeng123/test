
#include "types.h"
#include "stdio.h"
#include "string.h"
#include "unit_test.h"

#include "test_uart.h"

#include "hal_uart.h"

#define TEST_UART_RECV_LENGTH   1024

uint8_t test_uart1_ring_buffer[TEST_UART_RECV_LENGTH];

bool_t uartready=false;

static void test_uart1_rx_handler(uint8_t *buffer, uint32_t length)
{
    for (uint32_t i = 0; i < length; i ++) {
        hal_uart_putc(HAL_UART_PORT1, buffer[i]);
    }
}

static void test_uart_put_string(HAL_UART_PORT port, char *buf)
{
    char ch;

    while (0 != (ch = *buf++)) {
        hal_uart_putc(port, ch);
    }
}

bool_t test_uart_init(void)
{
    hal_uart_open(HAL_UART_PORT1, 115200, HAL_UART_DATA_BITS_8, HAL_UART_STOP_BITS_1, HAL_UART_PARITY_NONE);

    // hal_uart_register_rx_callback(HAL_UART_PORT1, test_uart1_ring_buffer,
    //                               TEST_UART_RECV_LENGTH,
    //                               (hal_uart_rx_callback)test_uart1_rx_handler);

    return true;
}

bool_t test_uart_run(void)
{
    // test_uart_put_string(HAL_UART_PORT1, "uart1 test massage \n");
    uint8_t aTxBuffer[] = " ****UART_TwoBoards communication based on DMA****  ****UART_TwoBoards communication based on DMA****  ****UART_TwoBoards communication based on DMA**** ";
    uint8_t arxbuffer[1024]={0};
    uint8_t size = sizeof(aTxBuffer)-1;

    hal_uart_transmit(HAL_UART_PORT1,aTxBuffer,size);

    hal_uart_receive(HAL_UART_PORT1,arxbuffer,10);
    return true;
}

bool_t test_uart_clean(void)
{
    hal_uart_close(HAL_UART_PORT1);

    return true;
}



TEST_MODULE(uart_test, test_uart_init, test_uart_run, test_uart_clean, 1);
