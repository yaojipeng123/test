#include "types.h"
#include "string.h"
#include "unit_test.h"
#include "hal_timer.h"

#include "hal.h"

int main(void)
{
    hal_bsp_init();

    hal_timer_init();

    while (1) {
        run_test();

        // run test only once
        stop_test();
        while(1);
    }

    return 0;
}
