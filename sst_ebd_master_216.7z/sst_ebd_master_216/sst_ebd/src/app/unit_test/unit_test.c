#include "types.h"
#include "stdio.h"
#include "unit_test.h"

#include "hal_uart.h"

extern uint32_t _test_module_start;
extern uint32_t _test_module_end;
extern uint32_t _single_module_start;
extern uint32_t _single_module_end;

uint32_t test_succ_count;
uint32_t test_fail_count;

int putchar(int c)
{
    hal_uart_putc(HAL_UART_PORT0, c);

    return c;
}

static void test_log_uart_init(void)
{
    hal_uart_open(HAL_UART_PORT0, 115200, HAL_UART_DATA_BITS_8, HAL_UART_STOP_BITS_1,
                  HAL_UART_PARITY_NONE);
}

static void test_module_pre_init(void)
{
    test_log_uart_init();
}

static void test_run_test_module(test_module_t *test_module)
{
    bool_t result = true;

    if (!test_module) {
        return;
    }

    for (volatile uint32_t i = 0; i < test_module->loop_time; i++) {
        result = true;
        if (test_module->init_func) {
            test_module->init_func();
        }
        if (result && test_module->run_func) {
            result = test_module->run_func();
            if (result) {
                printf("[MAIN] run %s ... OK\n", test_module->name_str);
            } else {
                printf("[MAIN] run %s ... FAIL\n", test_module->name_str);
            }
        }
        if (test_module->clean_func) {
            test_module->clean_func();
        }
    }

    if (result) {
        test_succ_count++;
    } else {
        test_fail_count++;
    }
}

void run_test(void)
{
    test_module_t *module = NULL;
    test_module_pre_init();

    test_succ_count = 0;
    test_fail_count = 0;

    if ((&_single_module_start) != (&_single_module_end)) {
        for (module = (test_module_t *)(&_single_module_start);
             (uint32_t)module < (uint32_t)(&_single_module_end); module++) {
            test_run_test_module(module);
        }
    } else {
        for (module = (test_module_t *)(&_test_module_start);
             (uint32_t)module < (uint32_t)(&_test_module_end); module++) {
            test_run_test_module(module);
        }
    }

    printf("[MAIN] All test done, succ:%d, fail:%d\n", test_succ_count, test_fail_count);
}

void stop_test(void)
{
}
