#include "types.h"
#include "stdio.h"

#include "hal.h"
#include "hal_uart.h"
#include "hal_flash.h"

#include "os_utils.h"
#include "os_task.h"

#include "ecat_def.h"
#include "share_task.h"
#include "sm_module.h"
#include "key_check.h"
#include "led.h"
#include "adc.h"
#include "ecat_task.h"
#include "io_output.h"
#include "log.h"
#include "timer_dev.h"
#include "uart_dev.h"
#include "gpio_dev.h"
#include "spi_dev.h"
#include "pwm_dev.h"
#include "acoustooptic_ctl.h"
#include "light_ctl.h"
#include "key.h"
#include "iomap.h"

#define WATCHDOG_PIN_ID HAL_GPIO_50
const char SOFTWARE_VER[] = "\r\nsoftware version is : 1.0.0\r\n";
static const char *TAG    = "sustao main";
uint8_t test_buf[]        = "hello";
uint8_t test_value_printf = 6;
void feed_dog(void *arg);
#if SUSTAO_LOG_PRINTF
int putchar(int c);
int putchar(int c)
{
    hal_uart_putc(HAL_UART_PORT1, c);
    return c;
}
static void debug_uart_init(void)
{
    hal_uart_open(HAL_UART_PORT1, 115200, HAL_UART_DATA_BITS_8, HAL_UART_STOP_BITS_1, HAL_UART_PARITY_NONE);
}
#endif
void all_device_init()
{
    gpio_device_init();
    timer_device_init();
    uart_device_init();
    spi_device_init();
    pwm_device_init();
}
int main(void)
{
    int32_t ret = ERR_OK;
    hal_bsp_init();
    hal_timer_init();
    // iomap_init();
#if SUSTAO_LOG_PRINTF
    debug_uart_init();
#else
    log_init();
#endif
    SUS_LOGI(TAG, "=============== sustao safboard hair transplant ================\n");
    SUS_LOGI(TAG, "suatao safboard software version is  %s\n", DEVICE_SW_VERSION);
    SUS_LOGI(TAG, "suatao safboard XML version is  %s\n", DEVICE_XML_VERSION);
    // SUS_LOGI(TAG, "fmt, aerg... is %d\n", test_value_printf);
    // SUS_LOGI(TAG, "fmt, aerg... is %d\n", test_value_printf);
    // SUS_LOGE(TAG, "HELLO_WORLD\n");

    // SUS_LOGI(TAG, "fmt, aerg... is %d\n", test_buf[0]);
    // uint32_t data[] = { 0x01030300, 0x00010801, 0x00060402, 0x000c0103, 0x000d0304, 0x00020805, 0x00030806, 0x000a0707, 0x000b0708,
    //                     0x000c0709, 0x000d070a, 0x000e070b, 0x000f070c, 0x0004080d, 0x0005080e, 0x0006080f, 0x00070810, 0x000b0811,
    //                     0x00020412, 0x000c0213, 0x000d0214, 0x00030415, 0x00040416, 0x00020717, 0x00030718, 0x00070719, 0x000d061a };
    // hal_flash_erase(0x81ffc00, 0x81ffc00 + sizeof(data));
    // hal_flash_program_word(0x81ffc00, data, sizeof(data));
    // share_task_init();
    iomap_init();
    all_device_init();
    ret = run_led_init();
    if(!ret) {
        run_led_run();
    }
    ret = adc_init();
    if(!ret) {
        adc_run();
    }
    ret = output_gpio_init();
    if(!ret) {
        output_gpio_run();
    }
    ret = alarm_init();
    if(!ret) {
        alarm_run();
    }
    ret = light_init();
    if(!ret) {
        light_run();
    }
    ret = key_gpio_init();
    if(!ret) {
        key_gpio_run();
    }
    ret = ethercat_init();
    if(!ret) {
        ethercat_run();
        sm_module_init();   //状态机
    }

    os_create_task_ext(feed_dog, NULL, 8, 512, "feed_dog");

    os_start_kernel();
    return 0;
}

void feed_dog(void *arg)
{
    dev_t *watch_dog_dev;
    gpio_config_t watch_dog = { WATCHDOG_PIN_ID, GPIO_IO_OUTPUT_PP, NULL, NULL, 0 };

    watch_dog_dev = dev_find("gpio");
    if(watch_dog_dev) {
        dev_init(watch_dog_dev);
        while(1) {
            watch_dog.data = 1;
            dev_control(watch_dog_dev, IOC_GPIO_SET, (unsigned long)&watch_dog);
            os_delay(10);
            watch_dog.data = 0;
            dev_control(watch_dog_dev, IOC_GPIO_SET, (unsigned long)&watch_dog);
            os_delay(10);
        }
    }
}