#ifndef _ADC7738_H_
#define _ADC7738_H_

/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t adc_init();

/**
 * @brief 
 * 
 * @return true 
 * @return false 
 */
bool adc_run();

#endif  //_ADC7738_H_