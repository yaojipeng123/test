#include "types.h"
#include "cpu.h"
#include "stdio.h"
#include "adc7738.h"

#include "errno.h"
#include "hal_adc.h"
#include "hal_spi.h"
#include "spi_dev.h"
#include "dev.h"
#include "io_output.h"
#include "os_queue.h"
#include "log.h"
#define SPI_MASTER      1
#define SPI_SLAVER      0
#define NOT_MOVE        0
#define UP_MOVE         1
#define DOWN_MOVE       2
#define DIFFER_MOVE_VAL 100
uint32_t adc_conv_value = 0;
uint32_t target_adc_val = 1000;
uint32_t adc_aver_value = 0;
extern os_queue_h gpio_output_h;
static const char *TAG = "adc";
/*
    立柱高度ad值   ADC_IN0     PC4 
*/
// dev_t *spi_7738_handler;
uint32_t voltage_value = 0;
extern int8_t adc7738_value_flag;
void dac7738_task(void *arg)
{
    uint8_t val = 0;
    uint8_t reg_val;

    uint32_t voltage_value_h  = 0;
    uint32_t voltage_value_l  = 0;
    uint32_t voltage_value_l2 = 0;
    uint32_t voltage_value_l3 = 0;
    float temp;
    SUS_LOGI(TAG, "DAC7738 task run\n");
    while(1) {
        reg_val = get_regvalue(REG_AD_CONVERSION_END);

        if(reg_val) {
            voltage_value = dac7738_get_adc_val();
            temp          = (float)(voltage_value) / 16777215.0;
            temp          = 2.5 * temp;
            voltage_value = temp * 10000;
            // if(temp != 0) {
            //     printf("hear\n");
            // }
            voltage_value_h  = voltage_value / 1000;
            voltage_value_l  = voltage_value % 1000;
            voltage_value_l  = voltage_value_l / 100;
            voltage_value_l2 = voltage_value % 100;
            voltage_value_l2 = voltage_value_l2 / 10;
            voltage_value_l3 = voltage_value % 10;
            // if(adc7738_value_flag == 1)
            //     LOG_INFO("voltage is %d.%d%d%d\n", voltage_value_h, voltage_value_l, voltage_value_l2, voltage_value_l3);
            // if(adc7738_value_flag == -1)
            //     LOG_INFO("voltage is -%d.%d%d%d\n", voltage_value_h, voltage_value_l, voltage_value_l2, voltage_value_l3);
            // printf("voltage is %d.%d%d%d\n", voltage_value_h, voltage_value_l, voltage_value_l2, voltage_value_l3);
            // LOG_INFO("get value is %f mV\n", temp);
            //printf("get value is %f mV\n",temp);
        }
        os_delay(500);
    }
}

uint32_t get_adc_average(uint8_t times)
{
    uint32_t temp_val = 0;
    uint32_t adc_val  = 0;
    for(int i = 0; i < times; i++) {
        hal_adc_get_value(HAL_PORT_ADC_0, 14, &adc_val);
        temp_val = temp_val + adc_val;
    }
    temp_val = temp_val / times;
    return temp_val;
}
uint16_t adc_value = 0;
void adc_task(void *arg)
{   //ADC dma
    uint16_t new_adc_value = 0;
    /*一阶滤波算法*/
    // float a = 0.0;
    // float b = 0.0;
    // float c = 0.0;
    /*一阶滤波算法*/
    float filtervalue = 0.0;   //滤波后的值
    float kalmangain  = 0.0;   //卡尔曼增益
    float A           = 1.0;   //状态矩阵
    float H           = 1.0;   //观测矩阵
    float Q           = 0.05;
    float R           = 0.1;
    float P           = 0.1;
    float B           = 0.1;
    float u           = 0.0;
    float perdicvalue = 0.0;
    while(1) {
        // hal_adc_get_value(HAL_PORT_ADC_0,14,&adc_val);
        /*一阶滤波算法*/
        // new_adc_value = get_adc_average(20);
        // // a = (float)new_adc_value*0.15;
        // // b = (float)adc_value*0.85;
        // // c = a+b;
        // // adc_value = c;
        // /*一阶滤波算法*/
        // /*卡尔曼滤波*/
        // perdicvalue = A*filtervalue+B*u;
        // P = A*A*P+Q;
        // kalmangain = P*H/(P*H*H+R);
        // filtervalue = perdicvalue+(new_adc_value-perdicvalue)*kalmangain;
        // P = (1-kalmangain*H)*P;
        // adc_value = filtervalue;
        hal_adc_start_dma(HAL_PORT_ADC_0, &adc_conv_value, 1);
        /*卡尔曼滤波*/
        os_delay(10);
    }
}

void adc_cb()
{
    static uint8_t move_dir     = NOT_MOVE;
    static uint8_t old_move_dir = NOT_MOVE;
    static uint32_t temp_val    = 0;
    static uint8_t count        = 0;
    uint32_t differ             = 0;
    temp_val                    = temp_val + adc_conv_value;
    struct io_out_ctl move_ctl_gpio;
    count++;
    if(count == 20) {
        count          = 0;
        adc_aver_value = temp_val / 20;
        temp_val       = 0;
    }
    // if(adc_conv_value >= target_adc_val) {
    //     differ = adc_conv_value - target_adc_val;
    //     if(differ >= DIFFER_MOVE_VAL) {
    //         move_dir = UP_MOVE;
    //     } else {
    //         move_dir = NOT_MOVE;
    //     }
    // } else {
    //     differ = target_adc_val - adc_conv_value;
    //     if(differ >= DIFFER_MOVE_VAL) {
    //         move_dir = DOWN_MOVE;
    //     } else {
    //         move_dir = NOT_MOVE;
    //     }
    // }
    // if(old_move_dir != move_dir) {
    //     old_move_dir = move_dir;
    //     switch(move_dir) {
    //         case NOT_MOVE:
    //             move_ctl_gpio.id  = UP_MOVE_PIN;
    //             move_ctl_gpio.ctl = RELAY_OPEN;
    //             if(gpio_output_h)
    //                 os_queue_send(gpio_output_h, &move_ctl_gpio);
    //             move_ctl_gpio.id  = DOWN_MOVE_PIN;
    //             move_ctl_gpio.ctl = RELAY_OPEN;
    //             if(gpio_output_h)
    //                 os_queue_send(gpio_output_h, &move_ctl_gpio);
    //             break;
    //         case UP_MOVE:
    //     move_ctl_gpio.id  = UP_MOVE_PIN;
    //     move_ctl_gpio.ctl = RELAY_CLOSE;
    //     if(gpio_output_h)
    //         os_queue_send(gpio_output_h, &move_ctl_gpio);
    //     move_ctl_gpio.id  = DOWN_MOVE_PIN;
    //     move_ctl_gpio.ctl = RELAY_OPEN;
    //     if(gpio_output_h)
    //         os_queue_send(gpio_output_h, &move_ctl_gpio);
    //     break;
    // case DOWN_MOVE:
    // move_ctl_gpio.id  = UP_MOVE_PIN;
    // move_ctl_gpio.ctl = RELAY_OPEN;
    // if(gpio_output_h)
    //     os_queue_send(gpio_output_h, &move_ctl_gpio);
    // move_ctl_gpio.id  = DOWN_MOVE_PIN;
    // move_ctl_gpio.ctl = RELAY_CLOSE;
    // if(gpio_output_h)
    // os_queue_send(gpio_output_h, &move_ctl_gpio);
    // break;
    // default:
    //     move_ctl_gpio.id  = UP_MOVE_PIN;
    //     move_ctl_gpio.ctl = RELAY_OPEN;
    //     if(gpio_output_h)
    //         os_queue_send(gpio_output_h, &move_ctl_gpio);
    //     move_ctl_gpio.id  = DOWN_MOVE_PIN;
    //     move_ctl_gpio.ctl = RELAY_OPEN;
    //     if(gpio_output_h)
    //         os_queue_send(gpio_output_h, &move_ctl_gpio);
    // break;
    // }
    // }
}
int32_t adc_init(void)
{
    int32_t ret             = ERR_OK;
    spi_config_t spi_config = { HAL_SPI_PORT0, SPI_PRESCALER_256, SPI_ROLE_MASTER, SPI_MSB, SPI_IDLE_LOW, SPI_CLK_1EDGE, SPI_DATA_8BIT };

    ret = spi_dac7738_init("spi0", (unsigned long)&spi_config);
    SUS_LOGI(TAG, "DAC7738 inited\n");
    return ret;

    // ret = hal_adc_init(HAL_PORT_ADC_0);   //初始化adc
    // if(ret) {
    //     printf("adc init failed\n");
    //     return false;
    // }
    // ret = hal_adc_set_channel(HAL_PORT_ADC_0, 14, 1, ADC_SampleTime_15Cycles);   //通道配置
    // if(ret) {
    //     printf("adc channel set failed\n");
    //     return false;
    // }
    // hal_adc_regular_callback_register(HAL_PORT_ADC_0, adc_cb);
    // ret = hal_adc_start_dma(HAL_PORT_ADC_0, &adc_conv_value, 1);
    // return ret;
}

bool_t adc_run(void)
{
    os_create_task_ext(dac7738_task, NULL, 7, 1024, "dac7738_task");
    // os_create_task_ext(adc_task, NULL, 7, 1024, "adc_task");
}
