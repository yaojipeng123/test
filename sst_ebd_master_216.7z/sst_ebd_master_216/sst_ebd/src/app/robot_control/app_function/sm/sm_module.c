#include <stdio.h>
#include "types.h"
#include "os_task.h"
#include "os_timer.h"
#include "os_utils.h"
#include "os_queue.h"
#include "sm.h"
#include "el9800appl.h"
#include "sm_module.h"
#include "log.h"
#include "key_check.h"
#include "io_output.h"
#include "ecatslv.h"
#include "acoustooptic_ctl.h"
static const char *TAG = "sm_module";
os_queue_h state_input_h;
extern os_queue_h gpio_output_h;
extern os_queue_h queue_rgb_clt;
extern key_stat_t key[3];
static timer_id_t t_to_running;        //进入startup状态后触发该定时器，实现100ms开一个外设设备电源& 10s后判断通信状况
static timer_id_t t_back_to_standby;   //进入shutdown状态后触发 15s间隔关闭外设设备电源到最终跳转到standby状态
static timer_id_t t_to_poweroff;       //进入poweroff状态后触发的延时断电
bool running_flag = false;             //running状态标志

extern bool loop1_status;
extern bool loop2_status;
extern bool loop3_status;
extern bool loop4_status;
extern bool_t onoff_status_flag;
extern uint8_t safe_dry_con_flag;
extern uint8_t rgb_ctl_value;
// extern bool switch_master_station_status;
// extern bool switch_mechanical_arm;

static void print_err_msg(void *state_data, struct event *event);
static void print_enter_msg(void *state_data, struct event *event);
static void print_exit_msg(void *state_data, struct event *event);

static void standby_enter_msg(void *state_data, struct event *event);
static void standby_exit_msg(void *state_data, struct event *event);
static void startup_enter_msg(void *state_data, struct event *event);
static void startup_exit_msg(void *state_data, struct event *event);
static void running_enter_msg(void *state_data, struct event *event);
static void running_exit_msg(void *state_data, struct event *event);
static void net_power_off_enter_msg(void *state_data, struct event *event);
static void net_power_off_exit_msg(void *state_data, struct event *event);
static void shutdown_enter_msg(void *state_data, struct event *event);
static void shutdown_exit_msg(void *state_data, struct event *event);
static void estop_enter_msg(void *state_data, struct event *event);
static void estop_exit_msg(void *state_data, struct event *event);

static void action_start_up(void *oldstate_data, struct event *event, void *state_new_data);
static void action_standby(void *oldstate_data, struct event *event, void *state_new_data);
static void action_running(void *oldstate_data, struct event *event, void *state_new_data);
static void action_net_power_off(void *oldstate_data, struct event *event, void *state_new_data);
static void action_shut_down(void *oldstate_data, struct event *event, void *state_new_data);
static void action_estop_in(void *oldstate_data, struct event *event, void *state_new_data);
static void action_estop_out(void *oldstate_data, struct event *event, void *state_new_data);
static void action_back2run(void *oldstate_data, struct event *event, void *state_new_data);
static void action_back2prev(void *oldstate_data, struct event *event, void *state_new_data);
static bool guard_not_run2estop_change(void *condition, struct event *event);
static bool guard_run2estop_change(void *condition, struct event *event);

static struct state state_root, state_standby, state_startup, state_running, state_poweroff,
    state_shutdown, state_estop;
static struct state back_to_prev_state;
static struct state state_root = {
    .parent_state = NULL,
    .entry_state  = &state_standby,
    .transitions =
        (struct transition[]){
            /* event_type, condition, guard, action, next, state  */
            { EVENT_ESTOP_IN, NULL, NULL, &action_estop_in, &state_estop },
        },
    .num_transitions = 1,
    .data            = "root",
    .entry_action    = &print_enter_msg,
    .exit_action     = &print_exit_msg,
};

static struct state state_standby = {
    .parent_state = &state_root,
    .entry_state  = NULL,
    .transitions =
        (struct transition[]){
            /* event_type, condition, guard, action, next, state  */
            { EVENT_START_UP, NULL, NULL, &action_start_up, &state_startup },
            //{ EVENT_NET_POWER_OFF, NULL, NULL, &action_net_power_off , &state_shutdown },
            //{EVENT_SHUT_DOWN,NULL,NULL,&action_shut_down,&state_shutdown},
            { EVENT_NET_POWER_OFF, NULL, NULL, &action_net_power_off, &state_poweroff },
        },
    .num_transitions = 2,
    .data            = "standby",
    .entry_action    = &standby_enter_msg,
    .exit_action     = &standby_exit_msg,
};

static struct state state_startup = {
    .parent_state = &state_root,
    .entry_state  = NULL,
    .transitions =
        (struct transition[]){
            /* event_type, condition, guard, action, next, state  */
            { EVENT_RUNNING, NULL, NULL, &action_running, &state_running },
            //{ EVENT_NET_POWER_OFF, NULL, NULL, &action_net_power_off , &state_shutdown },
            //{EVENT_ESTOP_IN,NULL,NULL,&action_estop_in,&state_estop},
        },
    .num_transitions = 1,
    .data            = "startup",
    .entry_action    = &startup_enter_msg,
    .exit_action     = &startup_exit_msg,
};

static struct state state_running = {
    .parent_state = &state_root,
    .entry_state  = NULL,
    .transitions =
        (struct transition[]){
            /* event_type, condition, guard, action, next, state  */
            //{ EVENT_NET_POWER_OFF, NULL, NULL, &action_net_power_off , &state_poweroff },
            { EVENT_SHUT_DOWN, NULL, NULL, &action_shut_down, &state_shutdown },
        },
    .num_transitions = 1,
    .data            = "running",
    .entry_action    = &running_enter_msg,
    .exit_action     = &running_exit_msg,
};

static struct state state_poweroff = {
    .parent_state = NULL,
    .entry_state  = NULL,
    // .transitions = (struct transition[]){
    //     //{EVENT_SHUT_DOWN,NULL,NULL,&action_shut_down,&state_shutdown},
    // },
    // .num_transitions = 1,
    .data         = "net_power_off",
    .entry_action = &net_power_off_enter_msg,
    .exit_action  = &net_power_off_exit_msg,
};
static struct state state_shutdown = {
    .parent_state = NULL,   //&state_root,
    .entry_state  = NULL,
    .transitions =
        (struct transition[]){
            /* event_type, condition, guard, action, next, state  */
            { EVENT_STANDBY, NULL, NULL, &action_standby, &state_standby },
        },
    .num_transitions = 1,
    .data            = "shutdown",
    .entry_action    = &shutdown_enter_msg,
    .exit_action     = &shutdown_exit_msg,
};

static struct state state_estop = {
    .parent_state = NULL,
    .entry_state  = NULL,
    .transitions =
        (struct transition[]){
            /* event_type, condition, guard, action, next, state  */
            // { EVENT_ESTOP_OUT, (void *)1, &guard_not_run2estop_change, &action_estop_out , &state_root },// if not in run state value is payload data value is 1;
            // { EVENT_ESTOP_OUT, (void *)2, &guard_run2estop_change, &action_back2run , &state_running },// if run state ,after clear the code, payload data value is 2;
            { EVENT_ESTOP_OUT, NULL, NULL, &action_back2prev, &back_to_prev_state },
            //{ EVENT_SHUT_DOWN, NULL, NULL, &action_shut_down , &state_shutdown },
            //{ EVENT_NET_POWER_OFF,NULL,NULL,&action_net_power_off , &state_poweroff},
            { EVENT_SHUT_DOWN, NULL, NULL, &action_shut_down, &state_shutdown },
        },
    .num_transitions = 2,
    .data            = "estop",
    .entry_action    = &estop_enter_msg,
    .exit_action     = &estop_exit_msg,
};

static struct state state_error = {
    .entry_action = &print_err_msg,
};

static void print_err_msg(void *state_data, struct event *event)
{
    // LOG_INFO("entered error state!\r\n");
}

static void print_enter_msg(void *state_data, struct event *event)
{
    // LOG_INFO("entering %s state\r\n", (char *)state_data);
}

static void print_exit_msg(void *state_data, struct event *event)
{
    // LOG_INFO("exiting %s state\r\n", (char *)state_data);
}

static void standby_enter_msg(void *state_data, struct event *event)
{
    running_flag = false;
    struct event e_post;
    SUS_LOGI(TAG, "enter standby\n");
    // if(ethcat_task != NULL)
    // {
    //     //os_delete_task(ethcat_task);
    // }
    onoff_status_flag = 0;
    rgb_ctl_value     = 0;   //close rgb
    // uint8_t rgb_ctl   = 5;
    // // rgb_set_color(BLANK, TURN_OFF);   //关闭RGB灯
    // if(queue_rgb_clt) {
    //     os_queue_send(queue_rgb_clt, &rgb_ctl);
    // }
    if(key[ESTOP_STATUS_PIN].key_logic == KEY_LOGIC_PUSHDOWN) {
        e_post.type = EVENT_ESTOP_IN;
        e_post.data = CODE_KEY_ESTOP;
        if(state_input_h)
            os_queue_send(state_input_h, &e_post);
    } else {
        sBoardTxPDO.board_status = STATUS_STANDBY;
        //dac5679_set_color(RGB_WRITE);//测试用RGB颜色设定
    }

    // LOG_INFO("entering %s state\r\n", (char *)state_data);
}

static void standby_exit_msg(void *state_data, struct event *event)
{
    SUS_LOGI(TAG, "exiting standby\n");
    // LOG_INFO("exiting %s state\r\n", (char *)state_data);
}

void change_2_poweroff(timer_id_t tid, void *arg)
{
    struct io_out_ctl output_gpio;
    sBoardTxPDO.board_status         = STATUS_POWEROFF;
    sBoardTxPDO.power_off_from_board = true;
    //关闭供电
    output_gpio.id  = UPS_CTL_PIN;
    output_gpio.ctl = RELAY_CLOSE;
    if(gpio_output_h)
        os_queue_send(gpio_output_h, &output_gpio);
}
void change_2_running(timer_id_t tid, void *arg)   //10s后根据ethercat通信状态进行状态机切换 由状态startup 10s后自动切换
{
    struct io_out_ctl output_gpio;
    struct event e_post;
    static uint8_t open_count = 0;

    rgb_ctl_value = 5;   //blue short shine
    if(0 == loop1_status) {
        output_gpio.id  = LOOP1_CTL_PIN;
        output_gpio.ctl = RELAY_OPEN;
        loop1_status    = 1;
    } else if(0 == loop2_status) {
        output_gpio.id  = LOOP2_CTL_PIN;
        output_gpio.ctl = RELAY_OPEN;
        loop2_status    = 1;
    } else if(0 == loop3_status) {
        output_gpio.id  = LOOP3_CTL_PIN;
        output_gpio.ctl = RELAY_OPEN;
        loop3_status    = 1;
    } else if(0 == loop4_status) {
        output_gpio.id  = LOOP4_CTL_PIN;
        output_gpio.ctl = RELAY_OPEN;
        loop4_status    = 1;
    }
    // else if (0 == switch_master_station_status) {
    //     output_gpio.id = LOOP4_CTL_PIN;
    //     output_gpio.ctl = RELAY_OPEN;
    //     switch_master_station_status = 1;
    // } else if (0 == switch_mechanical_arm) {
    //     output_gpio.id = LOOP5_CTL_PIN;
    //     output_gpio.ctl = RELAY_OPEN;
    //     switch_mechanical_arm = 1;
    // }
    if(gpio_output_h)
        os_queue_send(gpio_output_h, &output_gpio);
    if(bEcatOutputUpdateRunning) {   //进入OP状态
        SUS_LOGI(TAG, "change to running open_count is %d\n", open_count);
        os_stop_timer(t_to_running);
        e_post.type = EVENT_RUNNING;
        e_post.data = 2;
        if(state_input_h)
            os_queue_send(state_input_h, &e_post);
    }
    if(open_count >= 500) {
        open_count = 0;
        os_stop_timer(t_to_running);
        if(bEcatOutputUpdateRunning) {   //进入OP状态
            SUS_LOGI(TAG, "startup change to running \n");
            e_post.type = EVENT_RUNNING;
            e_post.data = 2;
        } else {   //非OP状态
            SUS_LOGI(TAG, "startup change to estop \n");
            // drv_gpio_write(drycon_id[ESTOP_CTR],DRY_CON_OPEN);
            // safe_dry_con_flag = 1;//急停继电器干接点断开
            e_post.type = EVENT_ESTOP_IN;
            e_post.data = CODE_ECAT_ERROR;
        }
        // e_post.type = EVENT_RUNNING;//临时追加 仅测试用
        // e_post.data = 2;//临时追加 仅测试用
        if(state_input_h)
            os_queue_send(state_input_h, &e_post);
    }

    open_count++;
}
static void startup_enter_msg(void *state_data, struct event *event)
{
    running_flag              = false;
    static bool once_executed = false;
    struct event e_post;
    onoff_status_flag = 1;
    SUS_LOGI(TAG, "enter start up\n");
    rgb_ctl_value = 5;                                          //rgb blue short shine
    if(key[ESTOP_STATUS_PIN].key_logic == KEY_LOGIC_PUSHDOWN)   //急停按键是按下状态
    {
        // LOG_INFO("key logic is %d ", key[ESTOP_STATUS_PIN].key_logic);
        e_post.type = EVENT_ESTOP_IN;
        e_post.data = CODE_KEY_ESTOP;
        if(state_input_h)
            os_queue_send(state_input_h, &e_post);
    } else {
        if(once_executed == false) {
            once_executed = true;
            os_create_task_ext(ethcat_task, NULL, 8, 512, "ethcat_task");   //开始ecat通信task
        }
        sBoardTxPDO.board_status = STATUS_STARTUP;
        os_start_timer(t_to_running, 100);
    }

    // LOG_INFO("entering %s state\r\n", (char *)state_data);
}

static void startup_exit_msg(void *state_data, struct event *event)
{
    sBoardTxPDO.board_status = STATUS_ROOT;
    SUS_LOGI(TAG, "exit start up\n");
    // LOG_INFO("exiting %s state\r\n", (char *)state_data);
}

static void running_enter_msg(void *state_data, struct event *event)
{
    running_flag = true;
    struct event e_post;
    SUS_LOGI(TAG, "enter running\n");
    if(key[ESTOP_STATUS_PIN].key_logic == KEY_LOGIC_PUSHDOWN)   //
    {
        e_post.type = EVENT_ESTOP_IN;
        e_post.data = CODE_KEY_ESTOP;
        if(state_input_h)
            os_queue_send(state_input_h, &e_post);
    } else {
        sBoardTxPDO.board_status = STATUS_RUNNING;
    }
    // LOG_INFO("entering %s state\r\n", (char *)state_data);
}

static void running_exit_msg(void *state_data, struct event *event)
{
    sBoardTxPDO.board_status = STATUS_ROOT;
    SUS_LOGI(TAG, "exit running\n");
    // LOG_INFO("exiting %s state\r\n", (char *)state_data);
}

void shutdown_2_standby(timer_id_t tid, void *arg)
{
    struct event e_post;
    struct io_out_ctl output_gpio;
    static uint8_t close_count = 0;
    SUS_LOGI(TAG, "shutdown to standby\n");
    // if(1 == loop1_status) {
    //     output_gpio.id  = LOOP1_CTL_PIN;
    //     output_gpio.ctl = RELAY_CLOSE;
    //     if(gpio_output_h)
    //         os_queue_send(gpio_output_h, &output_gpio);
    //     loop1_status = SWITCH_OFF;
    //     // LOG_INFO("close RELAY_IPC\n");
    // }
    // if(1 == loop2_status) {
    //     output_gpio.id  = LOOP2_CTL_PIN;
    //     output_gpio.ctl = RELAY_CLOSE;
    //     if(gpio_output_h)
    //         os_queue_send(gpio_output_h, &output_gpio);
    //     loop2_status = SWITCH_OFF;
    //     // LOG_INFO("close RELAY_DISPLAY\n");
    // }
    if(1 == loop3_status) {
        output_gpio.id  = LOOP3_CTL_PIN;
        output_gpio.ctl = RELAY_CLOSE;
        if(gpio_output_h)
            os_queue_send(gpio_output_h, &output_gpio);
        loop3_status = SWITCH_OFF;
        // LOG_INFO("close RELAY_IPC_MODULE\n");
    }

    if(1 == loop4_status) {
        output_gpio.id  = LOOP4_CTL_PIN;
        output_gpio.ctl = RELAY_CLOSE;
        if(gpio_output_h)
            os_queue_send(gpio_output_h, &output_gpio);
        loop4_status = SWITCH_OFF;
        // LOG_INFO("close RELAY_IPC_MODULE\n");
    }
    // else if (1 == switch_mechanical_arm) {
    //     output_gpio.id = LOOP4_CTL_PIN;
    //     output_gpio.ctl = RELAY_CLOSE;
    //     os_queue_send(gpio_output_h, &output_gpio);
    //     switch_mechanical_arm = SWITCH_OFF;
    //     LOG_INFO("close RELAY_MECHANICAL_ARM \n");
    // } else if (1 == switch_master_station_status) {
    //     output_gpio.id = LOOP5_CTL_PIN;
    //     output_gpio.ctl = RELAY_CLOSE;
    //     os_queue_send(gpio_output_h, &output_gpio);
    //     switch_master_station_status = SWITCH_OFF;
    //     LOG_INFO("close  RELAY_MASTER_STATION\n");
    // }
    os_stop_timer(t_back_to_standby);
    e_post.type = EVENT_STANDBY;
    e_post.data = 1;
    if(state_input_h)
        os_queue_send(state_input_h, &e_post);
}
static void net_power_off_enter_msg(void *state_data, struct event *event)
{
    running_flag = false;
    os_start_timer(t_to_poweroff, 10000);

    // //dac5679_set_color(RGB_CLOSE);//测试用RGB颜色设定
    // drv_gpio_write(out24v_id[RELAY_UPS],RELAY_OPEN);
    // printf( "entering %s state\r\n", (char *)state_data );
}

static void net_power_off_exit_msg(void *state_data, struct event *event)
{
    // sBoardTxPDO.board_status = STATUS_ROOT;
    // sBoardTxPDO.power_off_from_board = false;
    // printf( "exiting %s state\r\n", (char *)state_data );
}

static void shutdown_enter_msg(void *state_data, struct event *event)
{
    running_flag = false;
    struct event e_post;
    struct io_out_ctl output_gpio;
    rgb_ctl_value = 0;
    SUS_LOGI(TAG, "enter shutdown\n");
    if(1 == loop1_status) {
        output_gpio.id  = LOOP1_CTL_PIN;
        output_gpio.ctl = RELAY_CLOSE;
        if(gpio_output_h)
            os_queue_send(gpio_output_h, &output_gpio);
        loop1_status = SWITCH_OFF;
        // LOG_INFO("close RELAY_IPC\n");
    }
    if(1 == loop2_status) {
        output_gpio.id  = LOOP2_CTL_PIN;
        output_gpio.ctl = RELAY_CLOSE;
        if(gpio_output_h)
            os_queue_send(gpio_output_h, &output_gpio);
        loop2_status = SWITCH_OFF;
        // LOG_INFO("close RELAY_DISPLAY\n");
    }
    // uint8_t rgb_ctl = 0;
    // // rgb_set_color(BLANK, TURN_OFF);   //关闭RGB灯
    // if(queue_rgb_clt) {
    //     os_queue_send(queue_rgb_clt, &rgb_ctl);
    // }
    // LOG_INFO("entering %s state\r\n", (char *)state_data);
    //dac5679_set_color(RGB_BLUE);//测试用RGB颜色设定
    sBoardTxPDO.board_status = STATUS_SHUTDOWN;
    if(t_back_to_standby) {
        os_start_timer(t_back_to_standby, 15000);
    }
}

static void shutdown_exit_msg(void *state_data, struct event *event)
{
    sBoardTxPDO.board_status = STATUS_ROOT;
    SUS_LOGI(TAG, "exit shutdown\n");
    // LOG_INFO("exiting %s state\r\n", (char *)state_data);
}

//进入急停控制急停继电器断开  三个抱闸抱住
static void estop_enter_msg(void *state_data, struct event *event)
{
    //急停继电器干接点断开
    struct io_out_ctl output_gpio;
    SUS_LOGI(TAG, "enter estop\n");
    running_flag      = false;
    rgb_ctl_value     = 1;              // rgb keep red
    safe_dry_con_flag = DRY_CON_OPEN;   //急停继电器干接点断开
    output_gpio.id    = ESTOP_CTL_PIN;
    output_gpio.ctl   = DRY_CON_OPEN;
    if(gpio_output_h)
        os_queue_send(gpio_output_h, &output_gpio);

    output_gpio.id  = HOLD_BREAK1_PIN;   //锁抱闸1
    output_gpio.ctl = BRAKE_ENABLE;
    if(gpio_output_h)
        os_queue_send(gpio_output_h, &output_gpio);

    output_gpio.id  = HOLD_BREAK2_PIN;   //锁抱闸2
    output_gpio.ctl = BRAKE_ENABLE;
    if(gpio_output_h)
        os_queue_send(gpio_output_h, &output_gpio);

    output_gpio.id  = HOLD_BREAK3_PIN;   //锁抱闸3
    output_gpio.ctl = BRAKE_ENABLE;
    if(gpio_output_h)
        os_queue_send(gpio_output_h, &output_gpio);

    // //停止定时器t_to_running
    if(t_to_running) {
        if(os_is_timer_active(t_to_running)) {
            os_stop_timer(t_to_running);
        }
    }
    if(t_back_to_standby) {
        if(os_is_timer_active(t_back_to_standby)) {
            os_stop_timer(t_back_to_standby);
        }
    }
    if(t_to_poweroff) {
        if(os_is_timer_active(t_to_poweroff)) {
            os_stop_timer(t_to_poweroff);
        }
    }

    sBoardTxPDO.board_status = STATUS_ESTOP;
    //dac5679_set_color(RGB_RED);//测试用RGB颜色设定
    // LOG_INFO("entering %s state\r\n", (char *)state_data);
}

static void estop_exit_msg(void *state_data, struct event *event)
{
    struct io_out_ctl output_gpio;
    struct event e_post;
    SUS_LOGI(TAG, "exit estop\n");
    safe_dry_con_flag = DRY_CON_CLOSE;   //急停继电器干接点导通
    output_gpio.id    = ESTOP_CTL_PIN;
    output_gpio.ctl   = DRY_CON_CLOSE;
    if(gpio_output_h)
        os_queue_send(gpio_output_h, &output_gpio);
    // if (key[ESTOP_STATUS_PIN].key_logic == KEY_LOGIC_PUSHDOWN) {
    //     e_post.type = EVENT_ESTOP_IN;
    //     e_post.data = CODE_KEY_ESTOP;
    //     os_queue_send(state_input_h, &e_post);
    // } else {
    //     output_gpio.id = ESTOP_CTL_PIN;
    //     output_gpio.ctl = RELAY_OPEN;
    //     os_queue_send(gpio_output_h, &output_gpio);
    // }

    // LOG_INFO("exiting %s state\r\n", (char *)state_data);
}

static void action_standby(void *oldstate_data, struct event *event, void *state_new_data)
{
    // LOG_INFO("enter standby action\r\n");
}

static void action_start_up(void *oldstate_data, struct event *event, void *state_new_data)
{
    // LOG_INFO("enter start up action\r\n");
}

static void action_running(void *oldstate_data, struct event *event, void *state_new_data)
{
    // LOG_INFO("enter running action\r\n");
}
static void action_shut_down(void *oldstate_data, struct event *event, void *state_new_data)
{
    // LOG_INFO("enter shut down action\r\n");
}

static void action_net_power_off(void *oldstate_data, struct event *event, void *state_new_data)
{

    // LOG_INFO("enter net power off action\r\n");
}

static void action_estop_in(void *oldstate_data, struct event *event, void *state_new_data)
{
    // struct state * p_back_to_prev_state = sst_container_of(&oldstate_data, struct state, data);
    //  memcpy(&back_to_prev_state,p_back_to_prev_state, sizeof(struct state));
    // back_to_prev_state.parent_state = p_back_to_prev_state->parent_state;
    // back_to_prev_state.entry_state = p_back_to_prev_state->entry_state;
    // back_to_prev_state.transitions = p_back_to_prev_state->transitions;
    // back_to_prev_state.num_transitions = p_back_to_prev_state->num_transitions;
    // back_to_prev_state.data = p_back_to_prev_state->data;
    // back_to_prev_state.entry_action = p_back_to_prev_state->entry_action;
    // back_to_prev_state.exit_action = p_back_to_prev_state->exit_action;
    // LOG_INFO("enter estop action\r\n");
}

static void action_estop_out(void *oldstate_data, struct event *event, void *state_new_data)
{
    // LOG_INFO("exit estop action\r\n");
}

static void action_back2run(void *oldstate_data, struct event *event, void *state_new_data)
{
    // LOG_INFO("back to run state\r\n");
}

static void action_back2prev(void *oldstate_data, struct event *event, void *state_new_data)
{
    // LOG_INFO("back to previous enter state\r\n");
}

static bool guard_not_run2estop_change(void *condition, struct event *event)
{
    if(event->type != EVENT_ESTOP_OUT) {
        return false;
    }

    return ((int)event->data == (int)condition);
}

static bool guard_run2estop_change(void *condition, struct event *event)
{
    if(event->type != EVENT_ESTOP_OUT) {
        return false;
    }

    return ((int)event->data == (int)condition);
}
static void timer_create_init()
{
    //创建一个定时器,Shutdown - standby
    t_back_to_standby = os_create_timer(WAIT_ID, true, shutdown_2_standby, NULL);   //创建循环定时器
    if(!t_back_to_standby) {
        // LOG_INFO("t_back_to_standby timer create failed.\n");
    }
    //创建一个定时器,startup - running
    t_to_running = os_create_timer(CHECK_ECAT_ID, true, change_2_running, NULL);   //创建循环定时器
    if(!t_to_running) {
        // LOG_INFO("t_to_running timer create failed.\n");
    }
    t_to_poweroff = os_create_timer(POWEROFF_ID, false, change_2_poweroff, NULL);   //创建循环定时器
    if(!t_to_poweroff) {
        // LOG_INFO("t_to_poweroff timer create failed.\n");
    }
}

struct state_machine m;
void sm_task()
{
    struct state *p_back_to_prev_state;
    timer_create_init();   //创建定时器
    sm_init(&m, &state_standby, &state_error);
    //led_enter_standby();
    sBoardTxPDO.board_status = STATUS_STANDBY;
    // sBoardTxPDO.estop_code = CODE_NONE_ESTOP;
    sBoardTxPDO.power_off_from_board = false;

    struct event e_received;

    while(1) {
        os_queue_receive(state_input_h, &e_received);
        // e_received.type = EVENT_START_UP;
        int ret = sm_handle_event(&m, &(struct event){ e_received.type, e_received.data });
        // e_received.type = EVENT_ESTOP_IN;
        // ret = sm_handle_event(&m,&(struct event){e_received.type,e_received.data});
        p_back_to_prev_state = sm_previous_state(&m);
        if(EVENT_ESTOP_IN == e_received.type) {
            // sBoardTxPDO.estop_code = e_received.data;
            memcpy(&back_to_prev_state, p_back_to_prev_state, sizeof(struct state));
            // printf("enter estop in and the type code is %d\n", sBoardTxPDO.estop_code);
        } else {
            // sBoardTxPDO.estop_code = CODE_NONE_ESTOP;
        }
        // os_delay(100);
    }
}

int sm_run_init()
{
    os_task_h sm_h;
    state_input_h = os_queue_create(QUEUE_STATE_MACHINE_ID, 8, sizeof(struct event));
    sm_h          = os_create_task_ext(sm_task, NULL, 7, 256, "sm_task");
    if(sm_h == NULL) {
        // LOG_INFO("Error creating SM task\r\n");
        return -1;
    } else
        return 0;
}

bool_t sm_module_init(void)
{
    sm_run_init();   //状态机task
    return true;
}
