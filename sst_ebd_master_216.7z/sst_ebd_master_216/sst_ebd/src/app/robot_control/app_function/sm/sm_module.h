#ifndef _SM_H
#define _SM_H

#define QUEUE_STATE_MACHINE_ID 0

#define SWITCH_OFF  0
#define SWITCH_ON   1


enum timer_id{
    WAIT_ID,
    CHECK_ECAT_ID,
    POWEROFF_ID,
};






typedef enum {
    STATUS_ROOT,
    STATUS_STANDBY,
    STATUS_STARTUP,
    STATUS_RUNNING,
    STATUS_SHUTDOWN,
    STATUS_POWEROFF,
    STATUS_ESTOP,
} BOARD_STATUS;

typedef enum{
    CODE_NONE_ESTOP,
    CODE_ECAT_ERROR = 3,
    CODE_SOFT_ESTOP,
    CODE_KEY_ESTOP,
}ENTER_ESTOP_CODE;
bool_t sm_module_init(void);

#endif /* _SM_H */
