/**
\addtogroup EL9800Appl EL9800 application
@{
*/

/**
\file el9800appl.c
\author EthercatSSC@beckhoff.com
\brief Implementation

\version 5.11

<br>Changes to version V5.10:<br>
V5.11 ECAT11: create application interface function pointer, add eeprom emulation interface functions<br>
V5.11 EL9800 1: reset outputs on fallback from OP state<br>
<br>Changes to version V5.01:<br>
V5.10 ECAT6: Add "USE_DEFAULT_MAIN" to enable or disable the main function<br>
<br>Changes to version V5.0:<br>
V5.01 EL9800 2: Add TxPdo Parameter object 0x1802<br>
<br>Changes to version V4.30:<br>
V4.50 ECAT2: Create generic application interface functions. Documentation in Application Note ET9300.<br>
V4.50 COE2: Handle invalid PDO assign values.<br>
V4.30 : create file
*/

/*-----------------------------------------------------------------------------------------
------
------    Includes
------
-----------------------------------------------------------------------------------------*/
#include <stdio.h>
#include "ecat_def.h"
/* ECATCHANGE_START(V5.11) ECAT11*/
#include "applInterface.h"
/* ECATCHANGE_END(V5.11) ECAT11*/

#include "el9800hw.h"
#include "ecatappl.h"
#define _EVALBOARD_
#include "el9800appl.h"
#undef _EVALBOARD_
#include "log.h"
#include "os_queue.h"
#include "os_timer.h"
#include "os_utils.h"
#include "sm.h"
#include "sm_module.h"
#include "gpio_dev.h"
#include "dev.h"
#include "io_output.h"
#include "key_check.h"
#include "timer_dev.h"
#include "iomap.h"
#define ECAT_RESET_PIN HAL_GPIO_61   //PD13
static const char *TAG = "el9800appl";
// extern key_stat_t key[3];
extern struct state_machine m;
extern dev_t *ecat_gpio_dev;
/*--------------------------------------------------------------------------------------
------
------    local types and defines
------
--------------------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------------------
------
------    local variables and constants
------
-----------------------------------------------------------------------------------------*/
//extern gpio_io_config_t gconfig[TOTAL_GPIO_NUM];
//extern sst_device_t *gpio_handler;
//static sst_device_t *lan9252_reset_gpio_handler;
/*-----------------------------------------------------------------------------------------
------
------    application specific functions
------
-----------------------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------------------
------
------    generic functions
------
-----------------------------------------------------------------------------------------*/

/////////////////////////////////////////////////////////////////////////////////////////
/**
 \brief    The function is called when an error state was acknowledged by the master

*/
///////////////////////////////////////////////////////////////////////////////////////

void APPL_AckErrorInd(UINT16 stateTrans)
{
}

/////////////////////////////////////////////////////////////////////////////////////////
/**
 \return    AL Status Code (see ecatslv.h ALSTATUSCODE_....)

 \brief    The function is called in the state transition from INIT to PREOP when
           all general settings were checked to start the mailbox handler. This function
           informs the application about the state transition, the application can refuse
           the state transition when returning an AL Status error code.
           The return code NOERROR_INWORK can be used, if the application cannot confirm
           the state transition immediately, in that case the application need to be complete 
           the transition by calling ECAT_StateChange.

*/
///////////////////////////////////////////////////////////////////////////////////////

UINT16 APPL_StartMailboxHandler(void)
{
    return ALSTATUSCODE_NOERROR;
}

/////////////////////////////////////////////////////////////////////////////////////////
/**
 \return     0, NOERROR_INWORK

 \brief    The function is called in the state transition from PREEOP to INIT
             to stop the mailbox handler. This functions informs the application
             about the state transition, the application cannot refuse
             the state transition.

*/
///////////////////////////////////////////////////////////////////////////////////////

UINT16 APPL_StopMailboxHandler(void)
{
    return ALSTATUSCODE_NOERROR;
}

/////////////////////////////////////////////////////////////////////////////////////////
/**
 \param    pIntMask    pointer to the AL Event Mask which will be written to the AL event Mask
                        register (0x204) when this function is succeeded. The event mask can be adapted
                        in this function
 \return    AL Status Code (see ecatslv.h ALSTATUSCODE_....)

 \brief    The function is called in the state transition from PREOP to SAFEOP when
             all general settings were checked to start the input handler. This function
             informs the application about the state transition, the application can refuse
             the state transition when returning an AL Status error code.
            The return code NOERROR_INWORK can be used, if the application cannot confirm
            the state transition immediately, in that case the application need to be complete 
            the transition by calling ECAT_StateChange.
*/
///////////////////////////////////////////////////////////////////////////////////////

UINT16 APPL_StartInputHandler(UINT16 *pIntMask)
{
    return ALSTATUSCODE_NOERROR;
}

/////////////////////////////////////////////////////////////////////////////////////////
/**
 \return     0, NOERROR_INWORK

 \brief    The function is called in the state transition from SAFEOP to PREEOP
             to stop the input handler. This functions informs the application
             about the state transition, the application cannot refuse
             the state transition.

*/
///////////////////////////////////////////////////////////////////////////////////////

UINT16 APPL_StopInputHandler(void)
{
    return ALSTATUSCODE_NOERROR;
}

/////////////////////////////////////////////////////////////////////////////////////////
/**
 \return    AL Status Code (see ecatslv.h ALSTATUSCODE_....)

 \brief    The function is called in the state transition from SAFEOP to OP when
             all general settings were checked to start the output handler. This function
             informs the application about the state transition, the application can refuse
             the state transition when returning an AL Status error code.
           The return code NOERROR_INWORK can be used, if the application cannot confirm
           the state transition immediately, in that case the application need to be complete 
           the transition by calling ECAT_StateChange.
*/
///////////////////////////////////////////////////////////////////////////////////////

UINT16 APPL_StartOutputHandler(void)
{
    return ALSTATUSCODE_NOERROR;
}

/////////////////////////////////////////////////////////////////////////////////////////
/**
 \return     0, NOERROR_INWORK

 \brief    The function is called in the state transition from OP to SAFEOP
             to stop the output handler. This functions informs the application
             about the state transition, the application cannot refuse
             the state transition.

*/
///////////////////////////////////////////////////////////////////////////////////////

UINT16 APPL_StopOutputHandler(void)
{
    /*ECATCHANGE_START(V5.11) EL9800 1*/

    /*ECATCHANGE_END(V5.11) EL9800 1*/
    return ALSTATUSCODE_NOERROR;
}

/////////////////////////////////////////////////////////////////////////////////////////
/**
\return     0(ALSTATUSCODE_NOERROR), NOERROR_INWORK
\param      pInputSize  pointer to save the input process data length
\param      pOutputSize  pointer to save the output process data length

\brief    This function calculates the process data sizes from the actual SM-PDO-Assign
            and PDO mapping
*/
///////////////////////////////////////////////////////////////////////////////////////
UINT16 APPL_GenerateMapping(UINT16 *pInputSize, UINT16 *pOutputSize)
{
    UINT16 result                 = ALSTATUSCODE_NOERROR;
    UINT16 PDOAssignEntryCnt      = 0;
    OBJCONST TOBJECT OBJMEM *pPDO = NULL;
    UINT16 PDOSubindex0           = 0;
    UINT32 *pPDOEntry             = NULL;
    UINT16 PDOEntryCnt            = 0;
    UINT16 InputSize              = 0;
    UINT16 OutputSize             = 0;

    /*Scan object 0x1C12 RXPDO assign*/
    for(PDOAssignEntryCnt = 0; PDOAssignEntryCnt < sRxPDOassign.u16SubIndex0;
        PDOAssignEntryCnt++) {
        pPDO = OBJ_GetObjectHandle(sRxPDOassign.aEntries[PDOAssignEntryCnt]);
        if(pPDO != NULL) {
            PDOSubindex0 = *((UINT16 *)pPDO->pVarPtr);
            for(PDOEntryCnt = 0; PDOEntryCnt < PDOSubindex0; PDOEntryCnt++) {
                pPDOEntry = (UINT32 *)((UINT8 *)pPDO->pVarPtr + (OBJ_GetEntryOffset((PDOEntryCnt + 1), pPDO) >> 3));   //goto PDO entry
                // we increment the expected output size depending on the mapped Entry
                OutputSize += (UINT16)((*pPDOEntry) & 0xFF);
            }
        } else {
            /*assigned PDO was not found in object dictionary. return invalid mapping*/
            OutputSize = 0;
            result     = ALSTATUSCODE_INVALIDOUTPUTMAPPING;
            break;
        }
    }

    OutputSize = (OutputSize + 7) >> 3;

    if(result == 0) {
        /*Scan Object 0x1C13 TXPDO assign*/
        for(PDOAssignEntryCnt = 0; PDOAssignEntryCnt < sTxPDOassign.u16SubIndex0;
            PDOAssignEntryCnt++) {
            pPDO = OBJ_GetObjectHandle(sTxPDOassign.aEntries[PDOAssignEntryCnt]);
            if(pPDO != NULL) {
                PDOSubindex0 = *((UINT16 *)pPDO->pVarPtr);
                for(PDOEntryCnt = 0; PDOEntryCnt < PDOSubindex0; PDOEntryCnt++) {
                    pPDOEntry = (UINT32 *)((UINT8 *)pPDO->pVarPtr + (OBJ_GetEntryOffset((PDOEntryCnt + 1), pPDO) >> 3));   //goto PDO entry
                    // we increment the expected output size depending on the mapped Entry
                    InputSize += (UINT16)((*pPDOEntry) & 0xFF);
                }
            } else {
                /*assigned PDO was not found in object dictionary. return invalid mapping*/
                InputSize = 0;
                result    = ALSTATUSCODE_INVALIDINPUTMAPPING;
                break;
            }
        }
    }
    InputSize = (InputSize + 7) >> 3;

    *pInputSize  = InputSize;
    *pOutputSize = OutputSize;
    return result;
}

/////////////////////////////////////////////////////////////////////////////////////////
/**
\param      pData  pointer to input process data
\brief      This function will copies the inputs from the local memory to the ESC memory
            to the hardware
*/
///////////////////////////////////////////////////////////////////////////////////////
void APPL_InputMapping(UINT16 *pData)
{
    UINT16 j         = 0;
    UINT16 *pTmpData = (UINT16 *)pData;

    /* we go through all entries of the TxPDO Assign object to get the assigned TxPDOs */
    for(j = 0; j < sTxPDOassign.u16SubIndex0; j++) {
        switch(sTxPDOassign.aEntries[j]) {
                /* TxPDO 1 */
            case 0x1A00:
                // *pTmpData++ = SWAPWORD(((UINT16 *)&sSafboard_IO_In)[1]);
                // *pTmpData++ = SWAPWORD(((UINT16 *)&sSafboard_IO_In)[1] >> 16);
                // *pTmpData++ = SWAPWORD(((UINT16 *)&sSafboard_IO_In)[2]);
                *pTmpData++ = sSafboard_IO_In.column_position;
                *pTmpData++ = sSafboard_IO_In.column_position >> 16;
                // *pTmpData++ = sSafboard_IO_In.bSwitch1 << 15 | sSafboard_IO_In.bSwitch2 << 14 | sSafboard_IO_In.bSwitch3 << 13 | sSafboard_IO_In.bSwitch4 << 12 | sSafboard_IO_In.bSwitch5 << 11 | sSafboard_IO_In.bSwitch6 << 10 | sSafboard_IO_In.bSwitch7 << 9 | sSafboard_IO_In.bSwitch8 << 8 | sSafboard_IO_In.SubIndex009;
                *pTmpData++ = SWAPWORD(((UINT16 *)&sSafboard_IO_In)[4]);
                break;
            case 0x1A01:
                *pTmpData++ = sEncode1_value;
                *pTmpData++ = sEncode1_value >> 16;
                *pTmpData++ = sEncode2_value;
                *pTmpData++ = sEncode2_value >> 16;
                *pTmpData++ = sEncode3_value;
                *pTmpData++ = sEncode3_value >> 16;
                break;
                /* TxPDO 3 */
            case 0x1A02:
                *pTmpData++ = SWAPWORD(((UINT16 *)&sSigboard_IO_In)[1]);
                // *pTmpData++ = SWAPWORD(((UINT16 *)&sSigboard_IO_In)[2]);
                break;
            case 0x1A03:
                *pTmpData++ = SWAPWORD(((UINT16 *)&sBoardTxPDO)[1]);
                *pTmpData++ = SWAPWORD(((UINT16 *)&sBoardTxPDO)[2]);
                *pTmpData++ = SWAPWORD(((UINT16 *)&sBoardTxPDO)[3]);
                break;
        }
    }
}

/////////////////////////////////////////////////////////////////////////////////////////
/**
\param      pData  pointer to output process data

\brief    This function will copies the outputs from the ESC memory to the local memory
            to the hardware
*/
///////////////////////////////////////////////////////////////////////////////////////
void APPL_OutputMapping(UINT16 *pData)
{
    UINT16 j         = 0;
    UINT16 *pTmpData = (UINT16 *)pData;

    /* we go through all entries of the RxPDO Assign object to get the assigned RxPDOs */
    for(j = 0; j < sRxPDOassign.u16SubIndex0; j++) {
        switch(sRxPDOassign.aEntries[j]) {
            /* RxPDO 2 */
            case 0x1601:
                ((UINT16 *)&sSafboard_IO_Out)[1] = SWAPWORD(*pTmpData++);
                break;
            case 0x1602:
                ((UINT16 *)&sBoardRxPDO)[1] = SWAPWORD(*pTmpData++);
                ((UINT16 *)&sBoardRxPDO)[2] = SWAPWORD(*pTmpData++);
                ((UINT16 *)&sBoardRxPDO)[3] = SWAPWORD(*pTmpData++);
                ((UINT16 *)&sBoardRxPDO)[4] = SWAPWORD(*pTmpData++);
                break;
        }
    }
}

bool now_estop_flag         = false;
bool now_err_clr_flag       = false;
bool now_shutdown_flag      = false;
bool old_estop_flag         = false;
bool old_err_clr_flag       = false;
bool old_shutdown_flag      = false;
bool brake1_enable_flag     = false;
bool old_brake1_enable_flag = false;
bool brake2_enable_flag     = false;
bool old_brake2_enable_flag = false;
bool brake3_enable_flag     = false;
bool old_brake3_enable_flag = false;
bool up_move_control        = false;
bool old_up_move_control    = false;
bool down_move_control      = false;
bool old_down_move_control  = false;
bool forward_move_control   = false;
bool backward_move_control  = false;
// unsigned short count_heart;
unsigned short status_step;
extern os_queue_h state_input_h;

//extern uint8_t drycon_id[GPIO_SAF_OUT_MAX];//暂时屏蔽，之后要用

extern bool ecat_app_enter_type;
extern os_queue_h queue_rgb_clt;
extern os_queue_h gpio_output_h;
extern key_stat_t key[3];
extern uint8_t light_ctl_single;
extern key_stat_t up_down_key[2];
uint16_t safeboard_err_code;
extern uint16_t adc_value;
extern uint32_t adc_aver_value;
extern dev_t *test_timer;
extern uint32_t voltage_value;
extern uint8_t rgb_ctl_value;
static uint16_t test_sw_value = 0;
/////////////////////////////////////////////////////////////////////////////////////////
/**
\brief    This function will called from the synchronisation ISR 
            or from the mainloop if no synchronisation is supported
*/
///////////////////////////////////////////////////////////////////////////////////////
void APPL_Application(void)
{
    static uint8_t num = 0;
    struct event e_post_from_ecat;
    uint8_t system_state;
    static uint8_t old_rgb_ctl_value = 0;
    static uint8_t new_rgb_ctl_value = 0;
    static uint8_t heart_count       = 0;
    struct io_out_ctl output_gpio;
    struct io_out_ctl move_ctl_gpio;
    // count_heart = sBoardRxPDO.tbd5;
    // sEncode1_value = 0x10;
    // sBoardTxPDO.board_status = 0x01;
    // sBoardTxPDO.power_off_from_board = 1;
    // sBoardTxPDO.board_warning_code = 0x03;
    sBoardTxPDO.error_code = safeboard_err_code;
    // sEncode2_value = 0x11;
    // sEncode3_value = heart_count;
    now_estop_flag        = sBoardRxPDO.estop_req_from_ecat;
    now_err_clr_flag      = sBoardRxPDO.board_err_clr;
    now_shutdown_flag     = sBoardRxPDO.power_off_req_from_ecat;
    status_step           = sBoardRxPDO.ecat_status;
    new_rgb_ctl_value     = sBoardRxPDO.entire_sys_status;   //获取整个系统状态 根据状态控制rgb灯
    light_ctl_single      = sBoardRxPDO.light_control;       //亮度控制
    brake1_enable_flag    = sSafboard_IO_Out.blift_shaft_enable;
    brake2_enable_flag    = sSafboard_IO_Out.bsaf_tbd2;
    brake3_enable_flag    = sSafboard_IO_Out.bsaf_tbd3;
    up_move_control       = sSafboard_IO_Out.bsaf_tbd4;
    down_move_control     = sSafboard_IO_Out.bsaf_tbd5;
    forward_move_control  = sSafboard_IO_Out.bsaf_tbd6;
    backward_move_control = sSafboard_IO_Out.bsaf_tbd7;
    //立柱上升按键
    if(key[COLUMN_UP_PIN].key_logic == KEY_LOGIC_PUSHDOWN) {
        sSafboard_IO_In.bSwitch1 = 1;
    } else if(key[COLUMN_UP_PIN].key_logic == KEY_LOGIC_PUSHUP) {
        sSafboard_IO_In.bSwitch1 = 0;
    }

    //立柱下降按键
    if(key[COLUMN_DOWN_PIN].key_logic == KEY_LOGIC_PUSHDOWN) {
        sSafboard_IO_In.bSwitch2 = 1;
    } else if(key[COLUMN_DOWN_PIN].key_logic == KEY_LOGIC_PUSHUP) {
        sSafboard_IO_In.bSwitch2 = 0;
    }
    //关节前俯按钮
    if(key[JOINT_FORWARD_PIN].key_logic == KEY_LOGIC_PUSHDOWN) {
        sSafboard_IO_In.bSwitch3 = 1;
    } else if(key[JOINT_FORWARD_PIN].key_logic == KEY_LOGIC_PUSHUP) {
        sSafboard_IO_In.bSwitch3 = 0;
    }

    //关节后仰按钮
    if(key[JOINT_BACKWARD_PIN].key_logic == KEY_LOGIC_PUSHDOWN) {
        sSafboard_IO_In.bSwitch4 = 1;
    } else if(key[JOINT_BACKWARD_PIN].key_logic == KEY_LOGIC_PUSHUP) {
        sSafboard_IO_In.bSwitch4 = 0;
    }

    //抱闸按钮
    if(key[BRAKE_PIN].key_logic == KEY_LOGIC_PUSHDOWN) {
        sSafboard_IO_In.bSwitch5 = 1;
    } else if(key[BRAKE_PIN].key_logic == KEY_LOGIC_PUSHUP) {
        sSafboard_IO_In.bSwitch5 = 0;
    }

    // sSafboard_IO_In.column_position = 0x12345678;   //adc_value;//升降柱位置ad值
    sSafboard_IO_In.column_position = voltage_value;   //adc_value;//升降柱位置ad值
    // sSafboard_IO_In.bSwitch1       = 1;
    // sSafboard_IO_In.bSwitch2       = 1;
    // sSafboard_IO_In.bSwitch3       = 1;
    // sSafboard_IO_In.bSwitch4       = 1;
    // sSafboard_IO_In.bSwitch5       = 0;
    // sSafboard_IO_In.bSwitch6       = 1;
    // sSafboard_IO_In.bSwitch7       = 1;
    // test_sw_value                  = sSafboard_IO_In.bSwitch1 << 15 | sSafboard_IO_In.bSwitch2 << 14 | sSafboard_IO_In.bSwitch3 << 13 | sSafboard_IO_In.bSwitch4 << 12 | sSafboard_IO_In.bSwitch5 << 11 | sSafboard_IO_In.bSwitch6 << 10 | sSafboard_IO_In.bSwitch7 << 9 | sSafboard_IO_In.bSwitch8 << 8 | sSafboard_IO_In.SubIndex009;
    sBoardTxPDO.heart_beat_counter = heart_count;
    if(bEcatOutputUpdateRunning) {   //OP状态下
        heart_count++;
        if(heart_count > 127) {
            heart_count = 0;
        }
        /*抱闸1控制*/
        if(old_brake1_enable_flag != brake1_enable_flag) {
            old_brake1_enable_flag = brake1_enable_flag;
            output_gpio.id         = HOLD_BREAK1_PIN;
            if(brake1_enable_flag) {
                brake1_enable_flag = 0;
                SUS_LOGI(TAG, "brake1 release ctl\n");
            } else {
                brake1_enable_flag = 1;
                SUS_LOGI(TAG, "brake1 hold ctl\n");
            }
            output_gpio.ctl = brake1_enable_flag;
            if(gpio_output_h) {
                if(ENTER_TYPE_IRQ == ecat_app_enter_type) {
                    os_queue_send_from_isr(gpio_output_h, &output_gpio);
                } else {
                    os_queue_send(gpio_output_h, &output_gpio);
                }
            }
        }
        /*抱闸1控制*/
        /*抱闸2控制*/
        if(old_brake2_enable_flag != brake2_enable_flag) {
            old_brake2_enable_flag = brake2_enable_flag;
            output_gpio.id         = HOLD_BREAK2_PIN;
            if(brake2_enable_flag) {
                brake2_enable_flag = 0;
                SUS_LOGI(TAG, "brake2 release ctl\n");
            } else {
                brake2_enable_flag = 1;
                SUS_LOGI(TAG, "brake2 hold ctl\n");
            }
            output_gpio.ctl = brake2_enable_flag;
            if(gpio_output_h) {
                if(ENTER_TYPE_IRQ == ecat_app_enter_type) {
                    os_queue_send_from_isr(gpio_output_h, &output_gpio);
                } else {
                    os_queue_send(gpio_output_h, &output_gpio);
                }
            }
        }
        /*抱闸2控制*/
        /*抱闸3控制*/
        if(old_brake3_enable_flag != brake3_enable_flag) {
            old_brake3_enable_flag = brake3_enable_flag;
            output_gpio.id         = HOLD_BREAK3_PIN;
            if(brake3_enable_flag) {
                brake3_enable_flag = 0;
                SUS_LOGI(TAG, "brake3 release ctl\n");
            } else {
                brake3_enable_flag = 1;
                SUS_LOGI(TAG, "brake3 hold ctl\n");
            }
            output_gpio.ctl = brake3_enable_flag;
            if(gpio_output_h) {
                if(ENTER_TYPE_IRQ == ecat_app_enter_type) {
                    os_queue_send_from_isr(gpio_output_h, &output_gpio);
                } else {
                    os_queue_send(gpio_output_h, &output_gpio);
                }
            }
        }
        /*抱闸3控制*/

        /*上升控制*/
        if(old_up_move_control != up_move_control) {
            old_up_move_control = up_move_control;
            output_gpio.id      = UP_MOVE_PIN;
            if(up_move_control) {
                output_gpio.ctl = 0;
                SUS_LOGI(TAG, "upmove enable ctl\n");
            } else {
                output_gpio.ctl = 1;
                SUS_LOGI(TAG, "upmove disable ctl\n");
            }
            if(gpio_output_h) {
                if(ENTER_TYPE_IRQ == ecat_app_enter_type) {
                    os_queue_send_from_isr(gpio_output_h, &output_gpio);
                } else {
                    os_queue_send(gpio_output_h, &output_gpio);
                }
            }
        }
        /*上升控制*/

        /*下降控制*/
        if(old_down_move_control != down_move_control) {
            old_down_move_control = down_move_control;
            output_gpio.id        = DOWN_MOVE_PIN;
            output_gpio.ctl       = down_move_control;
            if(down_move_control) {
                output_gpio.ctl = 0;
                SUS_LOGI(TAG, "downmove enable ctl\n");
            } else {
                output_gpio.ctl = 1;
                SUS_LOGI(TAG, "downmove disable ctl\n");
            }
            if(gpio_output_h) {
                if(ENTER_TYPE_IRQ == ecat_app_enter_type) {
                    os_queue_send_from_isr(gpio_output_h, &output_gpio);
                } else {
                    os_queue_send(gpio_output_h, &output_gpio);
                }
            }
        }
        /*下降控制*/
        if(new_rgb_ctl_value != old_rgb_ctl_value) {
            if(new_rgb_ctl_value <= 8) {   //限制只能从ecat通信获取不大于8的值
                old_rgb_ctl_value = new_rgb_ctl_value;
                SUS_LOGI(TAG, "rgb ctl the val is %d\n", new_rgb_ctl_value);
                rgb_ctl_value = new_rgb_ctl_value;
                // if(queue_rgb_clt) {
                //     if(ENTER_TYPE_IRQ == ecat_app_enter_type) {
                //         os_queue_send_from_isr(queue_rgb_clt, &new_rgb_ctl_value);
                //     } else {
                //         os_queue_send(queue_rgb_clt, &new_rgb_ctl_value);
                //     }
                // }
            }
        }
        if(now_estop_flag != old_estop_flag) {
            old_estop_flag = now_estop_flag;
            if(now_estop_flag)   //ecat急停命令
            {
                SUS_LOGI(TAG, "estop enable ctl\n");
                output_gpio.id  = ESTOP_CTL_PIN;
                output_gpio.ctl = DRY_CON_OPEN;
                if(gpio_output_h) {
                    if(ENTER_TYPE_IRQ == ecat_app_enter_type) {
                        os_queue_send_from_isr(gpio_output_h, &output_gpio);
                    } else {
                        os_queue_send(gpio_output_h, &output_gpio);
                    }
                }

                e_post_from_ecat.type = EVENT_ESTOP_IN;
                e_post_from_ecat.data = 4;
                if(state_input_h) {
                    if(ENTER_TYPE_IRQ == ecat_app_enter_type) {
                        os_queue_send_from_isr(state_input_h, &e_post_from_ecat);
                    } else {
                        os_queue_send(state_input_h, &e_post_from_ecat);
                    }
                }

                // LOG_INFO("----enter estop----\n");
                //进入estop
            }
        }

        if(now_err_clr_flag != old_err_clr_flag) {
            old_err_clr_flag = now_err_clr_flag;
            if(now_err_clr_flag && !now_estop_flag)   //ecat清除急停命令
            {
                if(key[ESTOP_STATUS_PIN].key_logic == KEY_LOGIC_PUSHUP)   //急停按钮松开状态
                {
                    SUS_LOGI(TAG, "estop clean ctl\n");
                    output_gpio.id  = ESTOP_CTL_PIN;
                    output_gpio.ctl = DRY_CON_CLOSE;
                    if(gpio_output_h) {
                        if(ENTER_TYPE_IRQ == ecat_app_enter_type) {
                            os_queue_send_from_isr(gpio_output_h, &output_gpio);
                        } else {
                            os_queue_send(gpio_output_h, &output_gpio);
                        }
                    } else {
                        SUS_LOGE(TAG, "gpio_output_h do not create\n");
                    }

                    e_post_from_ecat.type = EVENT_ESTOP_OUT;
                    e_post_from_ecat.data = 4;
                    if(state_input_h) {
                        if(ENTER_TYPE_IRQ == ecat_app_enter_type) {
                            os_queue_send_from_isr(state_input_h, &e_post_from_ecat);
                        } else {
                            os_queue_send(state_input_h, &e_post_from_ecat);
                        }
                    } else {
                        SUS_LOGE(TAG, "state_input_h do not create\n");
                    }
                }

                // LOG_INFO("----clean error----\n");
            }
        }

        if(now_shutdown_flag != old_shutdown_flag) {
            old_shutdown_flag = now_shutdown_flag;
            if(now_shutdown_flag)   //关机指令
            {
                SUS_LOGI(TAG, "shutdown ctl\n");
                e_post_from_ecat.type = EVENT_SHUT_DOWN;
                e_post_from_ecat.data = 2;
                if(state_input_h) {
                    if(ENTER_TYPE_IRQ == ecat_app_enter_type) {
                        os_queue_send_from_isr(state_input_h, &e_post_from_ecat);
                    } else {
                        os_queue_send(state_input_h, &e_post_from_ecat);
                    }
                } else {
                    SUS_LOGE(TAG, "state_input_h do not create\n");
                }
            }
        }
    }

    /* start the conversion of the A/D converter */

    //AD1CON1bits.SAMP = 0; // start Converting
    //while (!AD1CON1bits.DONE);// conversion done?
    //sAIInputs.i16Analoginput = ADC1BUF0; // yes then get ADC value

    // sAIInputs.i16Analoginput = 0;
    /* we toggle the TxPDO Toggle after updating the data of the corresponding TxPDO */
    // sAIInputs.bTxPDOToggle ^= 1;

    /* we simulate a problem of the analog input, if the Switch4 is on in this example,
       in this case the TxPDO State has to set to indicate the problem to the master */
    // if ( sDIInputs.bSwitch4 )
    //     sAIInputs.bTxPDOState = 1;
    // else
    //     sAIInputs.bTxPDOState = 0;
}

/////////////////////////////////////////////////////////////////////////////////////////
/**
 \param     index               index of the requested object.
 \param     subindex            subindex of the requested object.
 \param     objSize             size of the requested object data, calculated with OBJ_GetObjectLength
 \param     pData               Pointer to the buffer where the data can be copied to
 \param     bCompleteAccess     Indicates if a complete read of all subindices of the
                                object shall be done or not

 \return    ABORTIDX_XXX

 \brief     Handles SDO read requests to TxPDO Parameter
*/
///////////////////////////////////////////////////////////////////////////////////////
UINT8 ReadObject0x1802(UINT16 index, UINT8 subindex, UINT32 dataSize, UINT16 MBXMEM *pData,
                       UINT8 bCompleteAccess)
{

    if(bCompleteAccess)
        return ABORTIDX_UNSUPPORTED_ACCESS;

    if(subindex == 0) {
        *pData = TxPDO1802Subindex0;
    } else if(subindex == 6) {
        /*clear destination buffer (no excluded TxPDO set)*/
        if(dataSize > 0)
            MBXMEMSET(pData, 0x00, dataSize);
    } else if(subindex == 7) {
        /*min size is one Byte*/
        UINT8 *pu8Data = (UINT8 *)pData;

        //Reset Buffer
        *pu8Data = 0;

        // *pu8Data = sAIInputs.bTxPDOState;
    } else if(subindex == 9) {
        /*min size is one Byte*/
        UINT8 *pu8Data = (UINT8 *)pData;

        //Reset Buffer
        *pu8Data = 0;

        // *pu8Data = sAIInputs.bTxPDOToggle;
    } else
        return ABORTIDX_SUBINDEX_NOT_EXISTING;

    return 0;
}

void reset_9252_chip()
{
    gpio_config_t ecat_reset = { ECAT_RESET_PIN, GPIO_IO_OUTPUT_PP, NULL, NULL, 1 };
    uint8_t gpio_group, gpio_pin;
    uint8_t ret = iomap_lookup_gpio(GPIO_ECAT_RST, &gpio_pin, &gpio_group);
    if(ret == ERR_OK) {
        ecat_reset.id = gpio_group * 16 + gpio_pin;
    } else {
        SUS_LOGE(TAG, "ECAT RST can not get pin\n");
    }
    dev_control(ecat_gpio_dev, IOC_GPIO_SET, (unsigned long)&ecat_reset);
    os_delay(100);
    ecat_reset.data = 0;
    dev_control(ecat_gpio_dev, IOC_GPIO_SET, (unsigned long)&ecat_reset);
    os_delay(100);
    ecat_reset.data = 1;
    dev_control(ecat_gpio_dev, IOC_GPIO_SET, (unsigned long)&ecat_reset);
    //     ecat_reset.data = 1;
    //     gpio_device_ctl(ECAT_RESET_PIN,IOC_GPIO_SET,&ecat_reset);
    //     os_delay(100);
    //     ecat_reset.data = 0;
    //     gpio_device_ctl(ECAT_RESET_PIN,IOC_GPIO_SET,&ecat_reset);
    //     os_delay(100);
    //     ecat_reset.data = 1;
    //     gpio_device_ctl(ECAT_RESET_PIN,IOC_GPIO_SET,&ecat_reset);
}
/////////////////////////////////////////////////////////////////////////////////////////
/**

 \brief    This is the main function

*/
///////////////////////////////////////////////////////////////////////////////////////
static timer_id_t check_op;
struct state *now_sm_state;
extern bool running_flag;
void ethcat_task(void *arg)
{
    struct event e_post;
    reset_9252_chip();
    HW_Init();
    MainInit();
    bRunApplication = TRUE;
    do {
        MainLoop();
        os_delay(1);
        if(running_flag) {
            if(!bEcatOutputUpdateRunning)                    //仅在OP时 bEcatOutputUpdateRunning 为1
            {                                                //非OP状态
                e_post.type = EVENT_ESTOP_IN;                //临时屏蔽 测试用
                e_post.data = CODE_ECAT_ERROR;               //临时屏蔽 测试用
                if(state_input_h)                            //临时屏蔽 测试用
                    os_queue_send(state_input_h, &e_post);   //临时屏蔽 测试用
            }
        }
    } while(bRunApplication == TRUE);

    HW_Release();
}

/** @} */
