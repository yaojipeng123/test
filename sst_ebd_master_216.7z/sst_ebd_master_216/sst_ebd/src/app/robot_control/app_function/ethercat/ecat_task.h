#ifndef _ECAT_H
#define _ECAT_H

/**
 * @brief init gpio timer fmc
 * 
 * @return bool_t 
 */
int32_t ethercat_init(void);

/**
 * @brief create ecat task
 * 
 * @return bool_t 
 */
bool_t ethercat_run(void);

/**
 * @brief not use
 * 
 * @return bool_t 
 */
bool_t ethercat_clean(void);

#endif /* _ECAT_H */