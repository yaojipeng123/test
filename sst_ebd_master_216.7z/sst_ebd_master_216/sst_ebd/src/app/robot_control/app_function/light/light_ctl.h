#ifndef LIGHT_CTL_H
#define LIGHT_CTL_H

/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t light_init(void);

/**
 * @brief 
 * 
 * @return bool_t 
 */
bool_t light_run(void);



#endif
