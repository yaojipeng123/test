#include "types.h"
#include "os_utils.h"
#include "os_task.h"

#include "errno.h"
#include "sm.h"
#include "dev.h"
#include "acoustooptic_ctl.h"
#include "pwm_dev.h"
#include "os_queue.h"
#include "os_mem.h"

#include "stdio.h"
#include "sm_module.h"

#include "hal_gpio.h"
#include "hal_timer.h"
#include "hal_pwm.h"

#include "gpio_dev.h"
#include "timer_dev.h"

#include "iomap.h"
#include "log.h"

#define LIGHT_CLOSE     0   //灯灭
#define LIGHT_OPEN      1   //灯亮
#define LIGHT_CTL_CYCLE 100
#define LIGHT_CTL_DUTY  50
static const char *TAG = "light";
/*
    DIG_OUT4    HAL_GPIO_137     PI9        照明灯控1
    DIG_OUT5    HAL_GPIO_138     PI10       照明灯控2
*/

gpio_config_t light_ctl_pin  = { HAL_GPIO_137, GPIO_IO_OUTPUT_PP, NULL, NULL, LIGHT_CLOSE };
gpio_config_t light_ctl_pin2 = { HAL_GPIO_138, GPIO_IO_OUTPUT_PP, NULL, NULL, LIGHT_CLOSE };
uint8_t light_ctl_single     = 0;

dev_t *light_dev;
dev_t *light_io_ctl;
dev_t *light_ctl_timer;
os_queue_h queue_light_clt;
void light_set_level(uint8_t level);
void light_ctl_task(void *arg)
{
    uint8_t duty_ctl = 18;
    SUS_LOGI(TAG, "light ctl task start\n");
    while(1) {
        // // light_set_level(1);
        switch(light_ctl_single) {
            case 1:
                duty_ctl = 6;
                break;
            case 2:
                duty_ctl = 4;
                break;
            case 3:
                duty_ctl = 2;
                break;
            case 4:
                duty_ctl = 8;
                break;
            default:
                duty_ctl = 18;
                break;
        }
        // light_ctl_pin.data  = LIGHT_OPEN;
        // light_ctl_pin2.data = LIGHT_OPEN;
        // dev_control(light_io_ctl, IOC_GPIO_SET, (unsigned long)&light_ctl_pin);   //亮
        // dev_control(light_io_ctl, IOC_GPIO_SET, (unsigned long)&light_ctl_pin2);
        hal_gpio_output_high(light_ctl_pin.id);
        hal_gpio_output_high(light_ctl_pin2.id);
        // os_delay(20 - duty_ctl);
        os_delay(duty_ctl);
        // os_delay(1);
        // light_ctl_pin.data  = LIGHT_CLOSE;
        // light_ctl_pin2.data = LIGHT_CLOSE;
        // dev_control(light_io_ctl, IOC_GPIO_SET, (unsigned long)&light_ctl_pin);
        // dev_control(light_io_ctl, IOC_GPIO_SET, (unsigned long)&light_ctl_pin2);
        hal_gpio_output_low(light_ctl_pin.id);
        hal_gpio_output_low(light_ctl_pin2.id);
        // os_delay(duty_ctl);
        // os_delay(duty_ctl);
        os_delay(20 - duty_ctl);
    }
}
int32_t light_init(void)
{   //pwm   gpio_out

    // int32_t ret = ERR_OK;
    // pwm_config_t pwm_set;

    // light_dev = dev_find("pwm3");//rgb灯控的pwm初始化
    // if(!light_dev)
    // {
    //     return ERR_FAIL;
    // }
    // dev_init(light_dev);

    light_io_ctl = dev_find("gpio");

    if(!light_io_ctl) {
        SUS_LOGE(TAG, "light gpio find failed\n");
        return ERR_FAIL;
    }
    dev_init(light_io_ctl);
    hal_gpio_open(light_ctl_pin.id, HAL_GPIO_OUTPUT);
    hal_gpio_open(light_ctl_pin2.id, HAL_GPIO_OUTPUT);
    // light_timer_init();
    SUS_LOGI(TAG, "light inited\n");
    // queue_light_clt = os_queue_create(QUEUE_SYSTEM_STATE_ID, 2, sizeof(uint8_t));
    return ERR_OK;
}

bool_t light_run(void)
{
    // rgb_set_color(RED,SHORT_SHINE);
    // rgb_set_color(GREEN,SHORT_SHINE);
    // rgb_set_color(BLUE,SHORT_SHINE);
    os_create_task_ext(light_ctl_task, NULL, 7, 1024, "light_ctl_task");
    return true;
}
void light_ctl_cb()
{
    static uint16_t i         = 0;
    static uint16_t duty_set  = 0;
    static uint16_t cycle_set = 0;

    duty_set  = LIGHT_CTL_DUTY;
    cycle_set = LIGHT_CTL_CYCLE;
    i++;
    if(i < duty_set) {
        // light_ctl_pin.data  = LIGHT_OPEN;
        // light_ctl_pin2.data = LIGHT_OPEN;
        // dev_control(light_io_ctl, IOC_GPIO_SET, (unsigned long)&light_ctl_pin);   //亮
        // dev_control(light_io_ctl, IOC_GPIO_SET, (unsigned long)&light_ctl_pin2);
        hal_gpio_output_high(light_ctl_pin.id);
        hal_gpio_output_high(light_ctl_pin2.id);
    } else {
        // light_ctl_pin.data  = LIGHT_CLOSE;
        // light_ctl_pin2.data = LIGHT_CLOSE;
        // dev_control(light_io_ctl, IOC_GPIO_SET, (unsigned long)&light_ctl_pin);   //灭
        // dev_control(light_io_ctl, IOC_GPIO_SET, (unsigned long)&light_ctl_pin2);
        hal_gpio_output_low(light_ctl_pin.id);
        hal_gpio_output_low(light_ctl_pin2.id);
    }
    if(i >= cycle_set) {
        i = 0;
    }
}
uint8_t light_timer_init()
{
    light_ctl_timer = dev_find("timer2");
    if(!light_ctl_timer) {
        return ERR_FAIL;
    }
    timer_alarm_t *light_timer_config = os_mem_malloc(LIB_MID, sizeof(timer_alarm_t));
    if(!light_timer_config) {
        os_mem_free(light_timer_config);
        return ERR_FAIL;
    }
    memset(light_timer_config, 0x0, sizeof(timer_alarm_t));
    light_timer_config->period = 0x0a;
    light_timer_config->repeat = true;
    light_timer_config->cb     = light_ctl_cb;

    light_ctl_timer->user_data = (void *)light_timer_config;
    // hal_timer_start(test_timer_id);
    dev_open(light_ctl_timer, TIM_NORMAL);
    dev_control(light_ctl_timer, IOC_TIMER_CONTROL, IO_TIMER_START);
    hal_gpio_open(light_ctl_pin.id, HAL_GPIO_OUTPUT);
    hal_gpio_open(light_ctl_pin2.id, HAL_GPIO_OUTPUT);
}
void light_set_level(uint8_t level)
{
    uint32_t l_period             = 0;
    pwm_set_config_t light_config = { 0, 0, 0, 4 };
    switch(level) {
        case 0:
            break;
            // case 1:
            //         l_period = 10000-1;
            //         light_config.pulse =  l_period/10;//设置50%占空比
            //         dev_control(light_dev,IOC_PWM_DUTY_CYCLE,(unsigned long)l_period);//修改周期
            //         dev_control(light_dev,IOC_PWM_START,(unsigned long)&light_config);//启动pwm

            // break;
    }
}