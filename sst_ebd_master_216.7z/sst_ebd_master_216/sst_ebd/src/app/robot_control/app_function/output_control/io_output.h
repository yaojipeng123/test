#ifndef _IO_OUTPUT_H
#define _IO_OUTPUT_H

#include "gpio_dev.h"

#define DRY_CON_OPEN  1
#define DRY_CON_CLOSE 0

#define BRAKE_ENABLE  1
#define BRAKE_DISABLE 0

#define RELAY_OPEN  0
#define RELAY_CLOSE 1

#define SWITCH_ON  1
#define SWITCH_OFF 0

#define QUEUE_GPIO_OUTPUT_ID 0
struct io_out_ctl {
    uint8_t id;
    bool ctl;
};

typedef enum {
    UPS_CTL_PIN,
    LOOP1_CTL_PIN,
    LOOP2_CTL_PIN,
    LOOP3_CTL_PIN,
    LOOP4_CTL_PIN,
    HOLD_BREAK1_PIN,
    HOLD_BREAK2_PIN,
    HOLD_BREAK3_PIN,
    ESTOP_CTL_PIN,
    ERROR_LEVEL1_PIN,
    ERROR_LEVEL2_PIN,
    ERROR_LEVEL3_PIN,
    // HOLD_BREAK_PIN,
    UP_MOVE_PIN,
    DOWN_MOVE_PIN,
    MAX_GPIO_OUTPUT_PIN,
} GPIO_OUTPUT_PIN;

// uint8_t input_pin[MAX_GPIO_INPUT_PIN] = {HAL_GPIO_130, HAL_GPIO_131, HAL_GPIO_122, HAL_GPIO_123,
//                                          HAL_GPIO_124};

/**
 * @brief create output gpio control task
 * 
 * @return bool_t 
 */
bool_t output_gpio_run(void);

/**
 * @brief init the output gpio
 * 
 * @return int32_t 
 */
int32_t output_gpio_init(void);

/**
 * @brief not use
 * 
 * @return bool_t 
 */
bool_t output_gpio_clean(void);

#endif /* _IO_OUTPUT_H */
