#include "types.h"
#include "stdio.h"
#include "sm_module.h"

#include "os_queue.h"
#include "os_utils.h"
#include "os_task.h"

#include "hal_gpio.h"
#include "hal_timer.h"
#include "hal_pwm.h"

#include "io_output.h"
#include "gpio_dev.h"
#include "dev.h"
#include "iomap.h"
#include "io_input.h"
#include "log.h"
#include "gpio_id.h"

// #define IOMAP_CFG_MAX 32
static const char *TAG = "io_output";
extern iomap_iomap_cfg_t iomap_cfg[GPIO_IOMAP_MAX];
extern uint8_t dig_state[5];
uint8_t safe_dry_con_flag = 0;   //急停干节点
uint8_t err1_dry_con_flag = 0;   //报警音1干节点
uint8_t err2_dry_con_flag = 0;   //报警音2干节点
uint8_t err3_dry_con_flag = 0;   //报警音3干节点
uint8_t hold_dry_con_flag = 0;   //抱闸使能

os_queue_h gpio_output_h;
dev_t *output_gpio_dev;
bool estop_key_flag = false;
bool loop1_status   = SWITCH_OFF;
bool loop2_status   = SWITCH_OFF;
bool loop3_status   = SWITCH_OFF;
bool loop4_status   = SWITCH_OFF;

struct io_out_ctl all_output_gpio = { 0xff, 0 };   //初始化选中所有output gpio 初始化为0
/*
        DIG_OUT0    HAL_GPIO_132    PI4  8-4         ups关闭信号
        DIG_OUT1    HAL_GPIO_133    PI5  8-5         控制回路1上下电 操作头 声音报警器 24V
        DIG_OUT2    HAL_GPIO_134    PI6  8-6         控制回路2上下电  植发工控机 调整臂 信号板卡 升降柱
        DIG_OUT3    HAL_GPIO_135    PI7  8-7         控制回路3上下电  工作站
        DIG_OUT6    HAL_GPIO_139    PI11  8-11       控制回路4上下电  关节模组
        DIG_OUT7    HAL_GPIO_66     PE2  4-2         抱闸1控制
        DIG_OUT8    HAL_GPIO_44     PC12  2-12       抱闸2控制
        DIG_OUT9    HAL_GPIO_45     PC13  2-13       抱闸3控制

        SAF_OUT0    HAL_GPIO_67     PE3  4-3         急停动作
        SAF_OUT1    HAL_GPIO_68     PE4  4-4         控制报警 报警音1
        SAF_OUT2    HAL_GPIO_114    PH2  7-2         控制报警 报警音2
        SAF_OUT3    HAL_GPIO_115    PH3  7-3         控制报警 报警音3
        // SAF_OUT4    HAL_GPIO_118    PH6         抱闸使能信号 默认使能状态
        SAF_OUT5    HAL_GPIO_119    PH7  7-7         升降柱上升
        SAF_OUT6    HAL_GPIO_109    PG13 6-13        升降柱下降
*/
gpio_config_t output_config[MAX_GPIO_OUTPUT_PIN] = {
    { HAL_GPIO_132, GPIO_IO_OUTPUT_PP, NULL, NULL, 0 },
    { HAL_GPIO_133, GPIO_IO_OUTPUT_PP, NULL, NULL, 0 },
    { HAL_GPIO_134, GPIO_IO_OUTPUT_PP, NULL, NULL, 0 },
    { HAL_GPIO_135, GPIO_IO_OUTPUT_PP, NULL, NULL, 0 },
    { HAL_GPIO_139, GPIO_IO_OUTPUT_PP, NULL, NULL, 0 },
    { HAL_GPIO_66, GPIO_IO_OUTPUT_PP, NULL, NULL, 0 },
    { HAL_GPIO_44, GPIO_IO_OUTPUT_PP, NULL, NULL, 0 },
    { HAL_GPIO_45, GPIO_IO_OUTPUT_PP, NULL, NULL, 0 },
    { HAL_GPIO_67, GPIO_IO_OUTPUT_PP, NULL, NULL, 0 },
    { HAL_GPIO_68, GPIO_IO_OUTPUT_PP, NULL, NULL, 0 },
    { HAL_GPIO_114, GPIO_IO_OUTPUT_PP, NULL, NULL, 0 },
    { HAL_GPIO_115, GPIO_IO_OUTPUT_PP, NULL, NULL, 0 },
    // {HAL_GPIO_118, GPIO_IO_OUTPUT_PP, NULL, NULL, 0},
    { HAL_GPIO_119, GPIO_IO_OUTPUT_PP, NULL, NULL, 0 },
    { HAL_GPIO_109, GPIO_IO_OUTPUT_PP, NULL, NULL, 0 },
};

void output_gpio_iomap_get()   //Get Pin value from iomap
{
    uint8_t ret = ERR_OK;
    uint8_t gpio_group, gpio_pin;
    for(int i = 0; i < MAX_GPIO_OUTPUT_PIN; i++) {
        ret = iomap_lookup_gpio(GPIO_UPS_CTL + i, &gpio_pin, &gpio_group);
        if(ret == ERR_OK) {
            output_config[UPS_CTL_PIN + i].id = gpio_group * 16 + gpio_pin;
        } else {
            SUS_LOGE(TAG, "output key can not get pin,the id is %d\n", i);
        }
    }
}

void drv_gpio_write(unsigned int id, unsigned int data)   //set pin high or low
{
    output_config[id].data = data;
    dev_control(output_gpio_dev, IOC_GPIO_SET, (unsigned long)&output_config[id]);
    // switch(id) {   //记录，用于反馈判断
    //     // case UPS_CTL_PIN:dig_state[DIG_POWER_STATE] = data;break;
    //     case LOOP1_CTL_PIN:
    //         dig_state[LOOP1_POWER_STATE] = data;
    //         break;
    //     case LOOP2_CTL_PIN:
    //         dig_state[LOOP2_POWER_STATE] = data;
    //         break;
    //     case LOOP3_CTL_PIN:
    //         dig_state[LOOP3_POWER_STATE] = data;
    //         break;
    //     // case LOOP3_CTL_PIN:dig_state[DIG_OPERATE_POWER_STATE] = data;break;
    //     default:
    //         break;
    // }
}
int io_output_firat_configure()
{
    drv_gpio_write(UPS_CTL_PIN, DRY_CON_OPEN);   //UPS工作
    // drv_gpio_write(UPS_CTL_PIN, 0);   //UPS不工作

    drv_gpio_write(LOOP1_CTL_PIN, RELAY_CLOSE);   //回路1
    // drv_gpio_write(LOOP1_CTL_PIN, 0);//回路1
    drv_gpio_write(LOOP2_CTL_PIN, RELAY_CLOSE);   //回路2
    // drv_gpio_write(LOOP2_CTL_PIN, 0);//回路2
    drv_gpio_write(LOOP3_CTL_PIN, RELAY_CLOSE);   //回路3
    // drv_gpio_write(LOOP3_CTL_PIN, 0);//回路3
    drv_gpio_write(LOOP4_CTL_PIN, RELAY_CLOSE);   //回路4  0：吸合工作
    // drv_gpio_write(LOOP4_CTL_PIN, 0);//回路4
    drv_gpio_write(ESTOP_CTL_PIN, DRY_CON_CLOSE);   //急停干接点闭合
    // drv_gpio_write(ESTOP_CTL_PIN, 1);//急停干接点闭合
    drv_gpio_write(ERROR_LEVEL1_PIN, DRY_CON_OPEN);   //报警音1
    // drv_gpio_write(ERROR_LEVEL1_PIN, 0);//报警音1
    // drv_gpio_write(ERROR_LEVEL1_PIN, 1);//报警音1
    drv_gpio_write(ERROR_LEVEL2_PIN, DRY_CON_OPEN);   //报警音2
    // drv_gpio_write(ERROR_LEVEL2_PIN, 0);//报警音2
    // drv_gpio_write(ERROR_LEVEL2_PIN, 1);//报警音2
    drv_gpio_write(ERROR_LEVEL3_PIN, DRY_CON_OPEN);   //报警音3 1：不报警
    // drv_gpio_write(ERROR_LEVEL3_PIN, 0);//报警音3
    // drv_gpio_write(ERROR_LEVEL3_PIN, 1);//报警音3
    // drv_gpio_write(HOLD_BREAK1_PIN, DRY_CON_CLOSE);   //解抱闸
    drv_gpio_write(HOLD_BREAK1_PIN, DRY_CON_OPEN);   //锁抱闸
    // drv_gpio_write(HOLD_BREAK2_PIN, DRY_CON_CLOSE);   //解抱闸
    drv_gpio_write(HOLD_BREAK2_PIN, DRY_CON_OPEN);   //锁抱闸
    // drv_gpio_write(HOLD_BREAK3_PIN, DRY_CON_CLOSE);   //解抱闸
    drv_gpio_write(HOLD_BREAK3_PIN, DRY_CON_OPEN);   //锁抱闸
    // drv_gpio_write(HOLD_BREAK_PIN, 1);//
    // drv_gpio_write(HOLD_BREAK_PIN, 0);//
    drv_gpio_write(UP_MOVE_PIN, DRY_CON_OPEN);   //升降柱上升失能   0：使能
    // drv_gpio_write(UP_MOVE_PIN, 0);                //升降柱上升使能
    // drv_gpio_write(UP_MOVE_PIN, 1);                //升降柱上升失能
    drv_gpio_write(DOWN_MOVE_PIN, DRY_CON_OPEN);   //升降柱下降使能
    // drv_gpio_write(DOWN_MOVE_PIN, 1);//升降柱下降失能
    // drv_gpio_write(DOWN_MOVE_PIN, 0);//升降柱下降
    // drv_gpio_write(ERROR_LEVEL1_PIN, DRY_CON_CLOSE);
    // drv_gpio_write(ERROR_LEVEL1_PIN, DRY_CON_OPEN);
    // drv_gpio_write(ERROR_LEVEL2_PIN, DRY_CON_CLOSE);
    // drv_gpio_write(ERROR_LEVEL2_PIN, DRY_CON_OPEN);
    // drv_gpio_write(ERROR_LEVEL3_PIN, DRY_CON_CLOSE);
    // drv_gpio_write(ERROR_LEVEL3_PIN, DRY_CON_OPEN);

    safe_dry_con_flag = DRY_CON_CLOSE;   //急停干接点闭合状态
    loop1_status      = SWITCH_OFF;
    loop2_status      = SWITCH_OFF;
    loop3_status      = SWITCH_OFF;
    loop4_status      = SWITCH_OFF;
    // switch_master_station_status = SWITCH_OFF;
    // switch_mechanical_arm = SWITCH_OFF;
}

void gpio_output_task(void *arg)
{
    uint8_t mask = 0x01;
    bool out_ctl = 0;
    SUS_LOGI(TAG, "gpio output task start\n");
    while(1) {
        os_queue_receive(gpio_output_h, &all_output_gpio);
        // printf("io output task reveive\n");
        drv_gpio_write(all_output_gpio.id, all_output_gpio.ctl);
    }
}

int32_t output_gpio_init(void)
{
    // gpio_device_init();
    int32_t ret     = ERR_OK;
    output_gpio_dev = dev_find("gpio");

    if(!output_gpio_dev) {
        SUS_LOGE(TAG, "output gpio find failed\n");
        return ERR_FAIL;
    }
    dev_init(output_gpio_dev);
    gpio_output_h = os_queue_create(QUEUE_GPIO_OUTPUT_ID, 8, sizeof(struct io_out_ctl));
    output_gpio_iomap_get();
    io_output_firat_configure();   //上电外部IO初次配置
    SUS_LOGI(TAG, "output gpio inited\n");
    return ret;
}

bool_t output_gpio_run(void)
{
    uint8_t status_power = 0;

    int i;
    os_create_task_ext(gpio_output_task, NULL, 7, 128, "gpio_output_task");

    return true;
}
