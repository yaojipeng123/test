#ifndef _KEY_H
#define _KEY_H

/*故障代码所需包含的信息还未确定，先自定一下*/
// #define ONOFF_KEY_ERR_CODE   0x000133            //其中0001为故障码 3为故障源：安全板卡  3为故障等级（1等级最高依次降低）
// #define ESTOP_KEY_ERR_CODE   0x000232            //其中0002为故障码 3为故障源：安全板卡  2为故障等级（1等级最高依次降低）
// #define POWER_KEY_ERR_CODE   0x000333            //其中0003为故障码 3为故障源：安全板卡  3为故障等级（1等级最高依次降低）
#define POWER_KEY_ERR_CODE      0x0100
#define ESTOP_KEY_ERR_CODE      0x0001
#define ONOFF_KEY_ERR_CODE      0x0002
#define UPMOVE_KEY_ERR_CODE      0x0020
#define DOWNMOVE_KEY_ERR_CODE      0x0040
/*woring 需要报警   error 需要急停*/
#define ABNORMAL_NONE   0x00
#define ABNORMAL_WORING 0x01
#define ABNORMAL_ERROR  0x02

/*目前最多八种woring 一个bit对应一种woring*/
#define UPMOVE_KEY_WORING    0x01
#define DOWNMOVE_KEY_WORING    0x02

/*目前最多八种error 一个bit对应一种error*/
#define ESTOP_KEY_ERROR     0x01

/**
 * @brief set key irq
 * @param
 * @return boot_t 
 */
bool_t key_gpio_run(void);

/**
 * @brief init the gpio about key
 * @param
 * @return boot_t 
 */
int32_t key_gpio_init(void);


#endif