#include "types.h"
#include "stdio.h"
#include "dev.h"
#include "os_utils.h"
#include "os_queue.h"
#include "os_task.h"

#include "iomap.h"
#include "gpio_id.h"
#include "key_check.h"
#include "gpio_dev.h"
#include "sm.h"
#include "key.h"
#include "acoustooptic_ctl.h"
#include "log.h"
dev_t *key_gpio_dev;
os_queue_h queue_error;
extern uint16_t safeboard_err_code;
extern iomap_iomap_cfg_t iomap_cfg[GPIO_IOMAP_MAX];
extern os_queue_h queue_rgb_clt;
key_stat_t key[MAX_PIN];
static const char *TAG = "key";
/*
    DIG_IN0     HAL_GPIO_130    PI2  8-2         开关按键
    DIG_IN1     HAL_GPIO_131    PI3  8-3         网电源状态
    DIG_IN2     HAL_GPIO_122    PH10  7-10        急停按钮状态

    DIG_IN3     HAL_GPIO_123    PH11  7-11        抱闸按钮
    DIG_IN4     HAL_GPIO_124    PH12  7-12        立柱上升按钮
    DIG_IN5     HAL_GPIO_125    PH13  7-13        立柱下降按钮
    DIG_IN6     HAL_GPIO_126    PH14  7-14        关节前俯按钮
    DIG_IN7     HAL_GPIO_127    PH15  7-15        关节后仰按钮
    
*/
gpio_config_t key_input_config[] = {
    { HAL_GPIO_130, GPIO_IRQ_EDGE_BOTH, onoff_button_isr, NULL, 0 },
    { HAL_GPIO_131, GPIO_IRQ_EDGE_BOTH, power_button_isr, NULL, 0 },
    { HAL_GPIO_122, GPIO_IRQ_EDGE_BOTH, estop_button_isr, NULL, 0 },
    { HAL_GPIO_123, GPIO_IRQ_EDGE_BOTH, brake_button_isr, NULL, 0 },
    { HAL_GPIO_124, GPIO_IRQ_EDGE_BOTH, column_up_button_isr, NULL, 0 },
    { HAL_GPIO_125, GPIO_IRQ_EDGE_BOTH, column_down_button_isr, NULL, 0 },
    { HAL_GPIO_126, GPIO_IRQ_EDGE_BOTH, joint_forward_button_isr, NULL, 0 },
    { HAL_GPIO_127, GPIO_IRQ_EDGE_BOTH, joint_backward_button_isr, NULL, 0 },
};

void key_gpio_iomap_get()
{
    uint8_t ret = ERR_OK;
    uint8_t gpio_group, gpio_pin;
    for(int i = 0; i < MAX_PIN; i++) {
        ret = iomap_lookup_gpio(GPIO_ONOFF_KEY + i, &gpio_pin, &gpio_group);
        if(ret == ERR_OK) {
            key_input_config[ONOFF_STATUS_PIN + i].id = gpio_group * 16 + gpio_pin;
        } else {
            SUS_LOGE(TAG, "input key can not get pin,the id is %d\n", i);
        }
    }
}

int32_t key_gpio_init(void)
{
    int32_t ret = ERR_OK;
    uint8_t err_code_send;
    // struct breakdown abnormal_type = {0};
    queue_error = os_queue_create(QUEUE_ERROR_ID, 8, sizeof(struct event));   //消息队列长度预估为8，若出现消息队列溢出现象，需增大这个值

    key_gpio_iomap_get();
    // gpio_device_init();
    set_power_timer(&key_input_config[POWER_STATUS_PIN]);
    set_estop_timer(&key_input_config[ESTOP_STATUS_PIN]);
    set_onoff_timer(&key_input_config[ONOFF_STATUS_PIN]);
    set_brake_timer(&key_input_config[BRAKE_PIN]);
    set_upmove_timer(&key_input_config[COLUMN_UP_PIN]);
    set_downmove_timer(&key_input_config[COLUMN_DOWN_PIN]);
    set_forward_timer(&key_input_config[JOINT_FORWARD_PIN]);
    set_backward_timer(&key_input_config[JOINT_BACKWARD_PIN]);
    key_gpio_dev = dev_find("gpio");

    if(!key_gpio_dev) {
        SUS_LOGE(TAG, "key gpio find failed\n");
        return ERR_FAIL;
    }
    dev_init(key_gpio_dev);

    /*开机自检阶段——按键检测*/
    /*Check the state of the key when the power is on for the first time. If the key is abnormal, report an error*/
    key_input_config[POWER_STATUS_PIN].config = GPIO_IO_INPUT_PU;
    dev_control(key_gpio_dev, IOC_GPIO_GET, (unsigned long)&key_input_config[POWER_STATUS_PIN]);
    key[POWER_STATUS_PIN].key_physic = key_input_config[POWER_STATUS_PIN].data;
    if(key[POWER_STATUS_PIN].key_physic)   //网电源未上电，需提示 故障等级三
    {
        SUS_LOGE(TAG, "power status is off inited\n");
        key[POWER_STATUS_PIN].key_logic = KEY_LOGIC_PUSHUP;

        safeboard_err_code = safeboard_err_code | POWER_KEY_ERR_CODE;   //设定故障位
        // err_code_send      = 0xf1;                                      //存在故障
        // if(queue_rgb_clt)
        //     os_queue_send(queue_rgb_clt, &err_code_send);
    } else {
        key[POWER_STATUS_PIN].key_logic = KEY_LOGIC_PUSHDOWN;   //网电源开启状态
    }

    key_input_config[ESTOP_STATUS_PIN].config = GPIO_IO_INPUT_PU;
    dev_control(key_gpio_dev, IOC_GPIO_GET, (unsigned long)&key_input_config[ESTOP_STATUS_PIN]);
    key[ESTOP_STATUS_PIN].key_physic = key_input_config[ESTOP_STATUS_PIN].data;   //急停拍下为1
    if(key[ESTOP_STATUS_PIN].key_physic)                                          //急停按键拍下报警 故障等级一
    {
        SUS_LOGE(TAG, "estop status is pushdown inited\n");
        key[ESTOP_STATUS_PIN].key_logic = KEY_LOGIC_PUSHDOWN;

        safeboard_err_code = safeboard_err_code | ESTOP_KEY_ERR_CODE;   //设定故障位
        err_code_send      = 0xf1;                                      //存在故障
        if(queue_rgb_clt)
            os_queue_send(queue_rgb_clt, &err_code_send);
    } else {
        key[ESTOP_STATUS_PIN].key_logic = KEY_LOGIC_PUSHUP;
    }

    key_input_config[ONOFF_STATUS_PIN].config = GPIO_IO_INPUT_PU;
    dev_control(key_gpio_dev, IOC_GPIO_GET, (unsigned long)&key_input_config[ONOFF_STATUS_PIN]);
    key[ONOFF_STATUS_PIN].key_physic = key_input_config[ONOFF_STATUS_PIN].data;   //开关按下为0
    if(!key[ONOFF_STATUS_PIN].key_physic)                                         //开关按键异常 故障等级一
    {
        key[ONOFF_STATUS_PIN].key_logic = KEY_LOGIC_PUSHDOWN;
        SUS_LOGE(TAG, "onoff status is pushdown inited\n");
        safeboard_err_code = safeboard_err_code | ONOFF_KEY_ERR_CODE;   //设定故障位
        err_code_send      = 0xf1;                                      //存在一二级故障
        if(queue_rgb_clt)
            os_queue_send(queue_rgb_clt, &err_code_send);
    } else {
        key[ONOFF_STATUS_PIN].key_logic = KEY_LOGIC_PUSHUP;
    }

    key_input_config[BRAKE_PIN].config = GPIO_IO_INPUT_PU;
    dev_control(key_gpio_dev, IOC_GPIO_GET, (unsigned long)&key_input_config[BRAKE_PIN]);
    key[BRAKE_PIN].key_physic = key_input_config[BRAKE_PIN].data;   //开关按下为0
    if(!key[BRAKE_PIN].key_physic)                                  //开关按键异常 故障等级一
    {
        key[BRAKE_PIN].key_logic = KEY_LOGIC_PUSHDOWN;
        SUS_LOGE(TAG, "BRAKE status is off inited\n");
        safeboard_err_code = safeboard_err_code | ONOFF_KEY_ERR_CODE;   //设定故障位
        err_code_send      = 0xf1;                                      //存在一二级故障
        if(queue_rgb_clt)
            os_queue_send(queue_rgb_clt, &err_code_send);
    } else {
        key[BRAKE_PIN].key_logic = KEY_LOGIC_PUSHUP;
    }

    key_input_config[COLUMN_UP_PIN].config = GPIO_IO_INPUT_PU;
    dev_control(key_gpio_dev, IOC_GPIO_GET, (unsigned long)&key_input_config[COLUMN_UP_PIN]);
    key[COLUMN_UP_PIN].key_physic = key_input_config[COLUMN_UP_PIN].data;   //
    if(!key[COLUMN_UP_PIN].key_physic)                                      //
    {
        key[COLUMN_UP_PIN].key_logic = KEY_LOGIC_PUSHDOWN;
        SUS_LOGE(TAG, "upmove status is off inited\n");
        safeboard_err_code = safeboard_err_code | UPMOVE_KEY_ERR_CODE;   //设定故障位
        err_code_send      = 0xf1;                                       //存在一二级故障
        if(queue_rgb_clt)
            os_queue_send(queue_rgb_clt, &err_code_send);
    } else {
        key[COLUMN_UP_PIN].key_logic = KEY_LOGIC_PUSHUP;
    }

    key_input_config[COLUMN_DOWN_PIN].config = GPIO_IO_INPUT_PU;
    dev_control(key_gpio_dev, IOC_GPIO_GET, (unsigned long)&key_input_config[COLUMN_DOWN_PIN]);
    key[COLUMN_DOWN_PIN].key_physic = key_input_config[COLUMN_DOWN_PIN].data;   //
    if(!key[COLUMN_DOWN_PIN].key_physic)                                        //
    {
        key[COLUMN_DOWN_PIN].key_logic = KEY_LOGIC_PUSHDOWN;
        SUS_LOGE(TAG, "downmove status is off inited\n");
        safeboard_err_code = safeboard_err_code | DOWNMOVE_KEY_ERR_CODE;   //设定故障位
        err_code_send      = 0xf1;                                         //存在一二级故障
        if(queue_rgb_clt)
            os_queue_send(queue_rgb_clt, &err_code_send);
    } else {
        key[COLUMN_DOWN_PIN].key_logic = KEY_LOGIC_PUSHUP;
    }

    key_input_config[JOINT_FORWARD_PIN].config = GPIO_IO_INPUT_PU;
    dev_control(key_gpio_dev, IOC_GPIO_GET, (unsigned long)&key_input_config[JOINT_FORWARD_PIN]);
    key[JOINT_FORWARD_PIN].key_physic = key_input_config[JOINT_FORWARD_PIN].data;   //
    if(!key[JOINT_FORWARD_PIN].key_physic)                                          //
    {
        key[JOINT_FORWARD_PIN].key_logic = KEY_LOGIC_PUSHDOWN;
        SUS_LOGE(TAG, "forward status is off inited\n");
        safeboard_err_code = safeboard_err_code | DOWNMOVE_KEY_ERR_CODE;   //设定故障位
        err_code_send      = 0xf1;                                         //存在一二级故障
        if(queue_rgb_clt)
            os_queue_send(queue_rgb_clt, &err_code_send);
    } else {
        key[JOINT_FORWARD_PIN].key_logic = KEY_LOGIC_PUSHUP;
    }

    key_input_config[JOINT_BACKWARD_PIN].config = GPIO_IO_INPUT_PU;
    dev_control(key_gpio_dev, IOC_GPIO_GET, (unsigned long)&key_input_config[JOINT_BACKWARD_PIN]);
    key[JOINT_BACKWARD_PIN].key_physic = key_input_config[JOINT_BACKWARD_PIN].data;   //
    if(!key[JOINT_BACKWARD_PIN].key_physic)                                           //
    {
        key[JOINT_BACKWARD_PIN].key_logic = KEY_LOGIC_PUSHDOWN;
        SUS_LOGE(TAG, "backward status is off inited\n");
        safeboard_err_code = safeboard_err_code | DOWNMOVE_KEY_ERR_CODE;   //设定故障位
        err_code_send      = 0xf1;                                         //存在一二级故障
        if(queue_rgb_clt)
            os_queue_send(queue_rgb_clt, &err_code_send);
    } else {
        key[JOINT_BACKWARD_PIN].key_logic = KEY_LOGIC_PUSHUP;
    }
    return ret;
}

/*Set the key to interrupt trigger*/
bool_t key_gpio_run(void)
{
    key_input_config[POWER_STATUS_PIN].config = GPIO_IRQ_EDGE_BOTH | GPIO_IRQ_ENABLE;
    dev_control(key_gpio_dev, IOC_GPIO_SET_IRQ, (unsigned long)&key_input_config[POWER_STATUS_PIN]);

    key_input_config[ESTOP_STATUS_PIN].config = GPIO_IRQ_EDGE_BOTH | GPIO_IRQ_ENABLE;
    dev_control(key_gpio_dev, IOC_GPIO_SET_IRQ, (unsigned long)&key_input_config[ESTOP_STATUS_PIN]);

    key_input_config[ONOFF_STATUS_PIN].config = GPIO_IRQ_EDGE_BOTH | GPIO_IRQ_ENABLE;
    dev_control(key_gpio_dev, IOC_GPIO_SET_IRQ, (unsigned long)&key_input_config[ONOFF_STATUS_PIN]);

    key_input_config[BRAKE_PIN].config = GPIO_IRQ_EDGE_BOTH | GPIO_IRQ_ENABLE;
    dev_control(key_gpio_dev, IOC_GPIO_SET_IRQ, (unsigned long)&key_input_config[BRAKE_PIN]);

    key_input_config[COLUMN_DOWN_PIN].config = GPIO_IRQ_EDGE_BOTH | GPIO_IRQ_ENABLE;
    dev_control(key_gpio_dev, IOC_GPIO_SET_IRQ, (unsigned long)&key_input_config[COLUMN_DOWN_PIN]);

    key_input_config[COLUMN_UP_PIN].config = GPIO_IRQ_EDGE_BOTH | GPIO_IRQ_ENABLE;
    dev_control(key_gpio_dev, IOC_GPIO_SET_IRQ, (unsigned long)&key_input_config[COLUMN_UP_PIN]);

    key_input_config[JOINT_FORWARD_PIN].config = GPIO_IRQ_EDGE_BOTH | GPIO_IRQ_ENABLE;
    dev_control(key_gpio_dev, IOC_GPIO_SET_IRQ, (unsigned long)&key_input_config[JOINT_FORWARD_PIN]);

    key_input_config[JOINT_BACKWARD_PIN].config = GPIO_IRQ_EDGE_BOTH | GPIO_IRQ_ENABLE;
    dev_control(key_gpio_dev, IOC_GPIO_SET_IRQ, (unsigned long)&key_input_config[JOINT_BACKWARD_PIN]);
    return true;
}