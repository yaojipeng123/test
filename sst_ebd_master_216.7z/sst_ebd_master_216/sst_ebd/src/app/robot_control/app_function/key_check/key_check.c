#include "types.h"
#include "stdio.h"

#include "os_utils.h"
#include "os_task.h"
#include "os_timer.h"
#include "os_queue.h"

#include "hal_gpio.h"
#include "hal_timer.h"
#include "log.h"
#include "dev.h"
#include "key_check.h"
#include "key.h"
#include "sm.h"
#include "sm_module.h"
#include "iomap.h"
#include "io_input.h"
#include "acoustooptic_ctl.h"
// #define IOMAP_CFG_MAX 32
#define TEST_GPIO_INPUT  HAL_GPIO_115   //(GPIOH, 3)
#define TEST_GPIO_OUTPUT HAL_GPIO_17    //(GPIOB, 1)
#define INT_ESC_PIN      HAL_GPIO_8
#define RUN_LED          HAL_GPIO_51
static const char *TAG = "key_check";
static timer_id_t tpower;      //定时器句柄
static timer_id_t testop;      //定时器句柄
static timer_id_t tonoff;      //定时器句柄
static timer_id_t tbrake;      //定时器句柄
static timer_id_t tupmove;     //定时器句柄
static timer_id_t tdownmove;   //定时器句柄
static timer_id_t tforward;    //定时器句柄
static timer_id_t tbackward;   //定时器句柄
extern dev_t *key_gpio_dev;
extern os_queue_h state_input_h;
extern iomap_iomap_cfg_t iomap_cfg[GPIO_IOMAP_MAX];
extern uint16_t safeboard_err_code;
extern uint8_t dig_state[DIG_ID_MAX];
extern os_queue_h queue_rgb_clt;
extern bool running_flag;
extern struct state_machine m;
// void test_callback();
void power_button_isr();
void estop_button_isr();
void onoff_button_isr();
void get_power_info(timer_id_t tid, void *arg);
void get_estop_info(timer_id_t tid, void *arg);
void get_onoff_info(timer_id_t tid, void *arg);
void get_brake_info(timer_id_t tid, void *arg);
void get_upmove_info(timer_id_t tid, void *arg);
void get_downmove_info(timer_id_t tid, void *arg);
void get_forward_info(timer_id_t tid, void *arg);
void get_backward_info(timer_id_t tid, void *arg);
bool_t onoff_status_flag = 0;
uint8_t estop_key_status;
// uint8_t net_power_key_status;
#define TAG "key_check"
extern key_stat_t key[MAX_PIN];

void set_power_timer(gpio_config_t *arg)
{
    tpower = os_create_timer(SWTIMER_POWER_ID, true, get_power_info, arg);   //创建定时器
}

void set_estop_timer(gpio_config_t *arg)
{
    testop = os_create_timer(SWTIMER_ESTOP_ID, true, get_estop_info, arg);   //创建定时器
}

void set_onoff_timer(gpio_config_t *arg)
{
    tonoff = os_create_timer(SWTIMER_ONOFF_ID, true, get_onoff_info, arg);   //创建定时器
    // tdelay = os_create_timer(DELAY_ID,false,change_to_shutdown,NULL);
    // printf("%d",tkey);
}
void set_brake_timer(gpio_config_t *arg)   //立柱上升按键触发定时器动作
{
    tbrake = os_create_timer(SWTIMER_ONOFF_ID, true, get_brake_info, arg);   //创建定时器
}

void set_upmove_timer(gpio_config_t *arg)   //立柱上升按键触发定时器动作
{
    tupmove = os_create_timer(SWTIMER_ONOFF_ID, true, get_upmove_info, arg);   //创建定时器
}
void set_downmove_timer(gpio_config_t *arg)   //立柱下降按键触发定时器动作
{
    tdownmove = os_create_timer(SWTIMER_ONOFF_ID, true, get_downmove_info, arg);   //创建定时器
}

void set_forward_timer(gpio_config_t *arg)   //关节前俯按键触发定时器动作
{
    tforward = os_create_timer(SWTIMER_ONOFF_ID, true, get_forward_info, arg);   //创建定时器
}
void set_backward_timer(gpio_config_t *arg)
{
    tbackward = os_create_timer(SWTIMER_ONOFF_ID, true, get_backward_info, arg);   //创建定时器
}

void get_power_info(timer_id_t tid, void *arg)
{
    struct state *now_state;
    uint8_t err_code_send;
    struct event e_post_from_powerkey = { 0 };
    gpio_config_t *gpio_config;
    gpio_config = arg;

    gpio_config->config = GPIO_IO_INPUT_PU;
    dev_control(key_gpio_dev, IOC_GPIO_GET, (unsigned long)gpio_config);
    key[POWER_STATUS_PIN].key_physic = gpio_config->data;
    gpio_config->config              = GPIO_IRQ_EDGE_BOTH | GPIO_IRQ_ENABLE;
    dev_control(key_gpio_dev, IOC_GPIO_SET_IRQ, (unsigned long)gpio_config);

    if(key[POWER_STATUS_PIN].key_physic == POWER_KEY_PUSH_UP) {
        key[POWER_STATUS_PIN].keyon_counts++;
        key[POWER_STATUS_PIN].keyoff_counts = 0;
    } else {
        key[POWER_STATUS_PIN].keyon_counts = 0;
        key[POWER_STATUS_PIN].keyoff_counts++;
    }

    if(key[POWER_STATUS_PIN].keyon_counts >= 10)   //网电源断开
    {
        now_state = sm_current_state(&m);
        // net_power_key_status = 0;
        key[POWER_STATUS_PIN].keyon_counts = 0;
        key[POWER_STATUS_PIN].key_logic    = KEY_LOGIC_PUSHUP;   //网电源断开
        if(now_state->data == STATUS_STANDBY) {
            e_post_from_powerkey.type = EVENT_NET_POWER_OFF;
            e_post_from_powerkey.data = 1;
            if(state_input_h)
                os_queue_send(state_input_h, &e_post_from_powerkey);
        }

        safeboard_err_code = safeboard_err_code | POWER_KEY_ERR_CODE;   //设定故障位
        err_code_send      = 0xf1;
        if(queue_rgb_clt)
            os_queue_send(queue_rgb_clt, &err_code_send);
        SUS_LOGI(TAG, "power key HOLD_ON\n");
        os_stop_timer(tid);
    } else if(key[POWER_STATUS_PIN].keyoff_counts >= 10) {   //按键自锁OFF
        // net_power_key_status = 1;
        key[POWER_STATUS_PIN].keyoff_counts = 0;
        key[POWER_STATUS_PIN].key_logic     = KEY_LOGIC_PUSHDOWN;
        safeboard_err_code                  = safeboard_err_code & (~POWER_KEY_ERR_CODE);   //清除故障位
        if(safeboard_err_code & 0xff00 == 0)                                                //取高八位，判断是否存在三级故障
        {
            err_code_send = 0xf0;   //清除故障
            if(queue_rgb_clt)
                os_queue_send(queue_rgb_clt, &err_code_send);
        }
        SUS_LOGI(TAG, "power key HOLD_OFF\n");
        os_stop_timer(tid);
    }
}
void get_estop_info(timer_id_t tid, void *arg)
{
    // key_ctr_config_t *set_config;
    // gpio_io_config_t *gpio_set_config;
    // gpio_irq_config_t *gpio_irq_set_config;
    uint8_t err_code_send;
    struct event e_post_from_hw_estop = { 0 };
    gpio_config_t *gpio_config;
    gpio_config = arg;

    // set_config = arg;
    // gpio_set_config = set_config->gconfig;
    // gpio_irq_set_config = set_config->girqconfig;
    gpio_config->config = GPIO_IO_INPUT_PU;
    dev_control(key_gpio_dev, IOC_GPIO_GET, (unsigned long)gpio_config);
    key[ESTOP_STATUS_PIN].key_physic = gpio_config->data;
    gpio_config->config              = GPIO_IRQ_EDGE_BOTH | GPIO_IRQ_ENABLE;
    dev_control(key_gpio_dev, IOC_GPIO_SET_IRQ, (unsigned long)gpio_config);
    if(key[ESTOP_STATUS_PIN].key_physic == ESTOP_KEY_PUSH_DOWN) {
        key[ESTOP_STATUS_PIN].keyon_counts++;
        key[ESTOP_STATUS_PIN].keyoff_counts = 0;
    } else {
        key[ESTOP_STATUS_PIN].keyon_counts = 0;
        key[ESTOP_STATUS_PIN].keyoff_counts++;
    }
    if(key[ESTOP_STATUS_PIN].keyon_counts >= 10) {   //按键自锁ON
        SUS_LOGI(TAG, "ESTOP ENABLE\r\n");
        estop_key_status                   = 1;
        key[ESTOP_STATUS_PIN].keyon_counts = 0;
        key[ESTOP_STATUS_PIN].key_logic    = KEY_LOGIC_PUSHDOWN;   //按键状态为保持按下

        e_post_from_hw_estop.type = EVENT_ESTOP_IN;
        e_post_from_hw_estop.data = 5;
        if(state_input_h)
            os_queue_send(state_input_h, &e_post_from_hw_estop);
        safeboard_err_code = safeboard_err_code | ESTOP_KEY_ERR_CODE;   //设定急停故障位
        err_code_send      = 0xf1;                                      //设定故障
        if(queue_rgb_clt)
            os_queue_send(queue_rgb_clt, &err_code_send);
        os_stop_timer(tid);
        return;
        //
    }
    if(key[ESTOP_STATUS_PIN].keyoff_counts >= 10) {   //急停松开
        key[ESTOP_STATUS_PIN].keyoff_counts = 0;
        key[ESTOP_STATUS_PIN].key_logic     = KEY_LOGIC_PUSHUP;   //按键状态为保持松开
        if(!running_flag)                                         //临时屏蔽 仅测试用
        {
            e_post_from_hw_estop.type = EVENT_ESTOP_OUT;
            e_post_from_hw_estop.data = 5;   // event stop out 2 means go back to run state 1 means go back to default state
            if(state_input_h)
                os_queue_send(state_input_h, &e_post_from_hw_estop);
        }                                                   //临时屏蔽 仅测试用
        safeboard_err_code = safeboard_err_code & 0xfffe;   //(~ESTOP_KEY_ERR_CODE);//清除急停故障位
        if((safeboard_err_code & 0x00ff) == 0)              //低八位表示一二级故障
        {
            err_code_send = 0xf0;   //清除故障
            if(queue_rgb_clt)
                os_queue_send(queue_rgb_clt, &err_code_send);
        }

        estop_key_status = 0;
        SUS_LOGI(TAG, "ESTOP DISABLE\r\n");
        os_stop_timer(tid);
        return;
    }
}
void get_onoff_info(timer_id_t tid, void *arg)
{
    // key_ctr_config_t *set_config;
    // gpio_io_config_t *gpio_set_config;
    // gpio_irq_config_t *gpio_irq_set_config;
    uint8_t err_code_send;
    gpio_config_t *gpio_config;
    struct event e_post_from_button = { 0 };

    gpio_config = arg;
    // gpio_set_config = set_config->gconfig;
    // gpio_irq_set_config = set_config->girqconfig;
    gpio_config->config = GPIO_IO_INPUT_PU;
    dev_control(key_gpio_dev, IOC_GPIO_GET, (unsigned long)gpio_config);
    key[ONOFF_STATUS_PIN].key_physic = gpio_config->data;
    gpio_config->config              = GPIO_IRQ_EDGE_BOTH | GPIO_IRQ_ENABLE;
    dev_control(key_gpio_dev, IOC_GPIO_SET_IRQ, (unsigned long)gpio_config);
    if(key[ONOFF_STATUS_PIN].key_physic == ONOFF_KEY_PUSH_DOWN) {
        //counter ++;
        key[ONOFF_STATUS_PIN].keyon_counts++;
    } else {
        safeboard_err_code = safeboard_err_code & (~ONOFF_KEY_ERR_CODE);
        if(safeboard_err_code & 0x00ff == 0)   //取低八位，判断是否存在一二级故障
        {
            err_code_send = 0xf0;   //清除故障
            if(queue_rgb_clt)
                os_queue_send(queue_rgb_clt, &err_code_send);
        }

        if((key[ONOFF_STATUS_PIN].keyon_counts > 10) && (key[ONOFF_STATUS_PIN].keyon_counts < 200)) {   //短按
            key[ONOFF_STATUS_PIN].key_logic = KEY_LOGIC_SHORT_PUSHDOWN;
            SUS_LOGI(TAG, "onoff key short on\n");
            e_post_from_button.type = EVENT_START_UP;
            e_post_from_button.data = 1;
            // dig_state[DIG_ONOFF_STATE] = 1;
            if(state_input_h)
                os_queue_send(state_input_h, &e_post_from_button);
        }
        key[ONOFF_STATUS_PIN].keyon_counts = 0;
        os_stop_timer(tid);
    }
    if(key[ONOFF_STATUS_PIN].keyon_counts >= 200) {   //长按2s 200*10=2000ms
        key[ONOFF_STATUS_PIN].key_logic = KEY_LOGIC_LONG_PUSHDOWN;
        if(onoff_status_flag) {
            e_post_from_button.type = EVENT_SHUT_DOWN;
            e_post_from_button.data = 2;
        } else {
            e_post_from_button.type = EVENT_START_UP;
            e_post_from_button.data = 1;
        }

        // dig_state[DIG_ONOFF_STATE] = 0;
        if(state_input_h)
            os_queue_send(state_input_h, &e_post_from_button);
        SUS_LOGI(TAG, "onoff key long on\n");
        key[ONOFF_STATUS_PIN].keyon_counts = 0;
        os_stop_timer(tid);
    }
}

void get_brake_info(timer_id_t tid, void *arg)
{
    gpio_config_t *gpio_config;

    gpio_config         = arg;
    gpio_config->config = GPIO_IO_INPUT_PU;
    dev_control(key_gpio_dev, IOC_GPIO_GET, (unsigned long)gpio_config);
    key[BRAKE_PIN].key_physic = gpio_config->data;
    gpio_config->config       = GPIO_IRQ_EDGE_BOTH | GPIO_IRQ_ENABLE;
    dev_control(key_gpio_dev, IOC_GPIO_SET_IRQ, (unsigned long)gpio_config);
    if(key[BRAKE_PIN].key_physic == KEY_PUSH_DOWN) {
        key[BRAKE_PIN].keyon_counts++;
        key[BRAKE_PIN].keyoff_counts = 0;
    } else {
        key[BRAKE_PIN].keyon_counts = 0;
        key[BRAKE_PIN].keyoff_counts++;
    }

    if(key[BRAKE_PIN].keyon_counts >= 10) {   //按键自锁ON
        key[BRAKE_PIN].keyon_counts = 0;
        key[BRAKE_PIN].key_logic    = KEY_LOGIC_PUSHDOWN;   //按键状态为保持按下
        SUS_LOGI(TAG, "brake key push down\n");
        os_stop_timer(tid);
    }
    if(key[BRAKE_PIN].keyoff_counts >= 10) {
        key[BRAKE_PIN].keyoff_counts = 0;
        key[BRAKE_PIN].key_logic     = KEY_LOGIC_PUSHUP;   //按键状态为保持按下
        SUS_LOGI(TAG, "brake key push up\n");
        os_stop_timer(tid);
    }
    /**/
}

void get_upmove_info(timer_id_t tid, void *arg)
{
    gpio_config_t *gpio_config;

    gpio_config         = arg;
    gpio_config->config = GPIO_IO_INPUT_PU;
    dev_control(key_gpio_dev, IOC_GPIO_GET, (unsigned long)gpio_config);
    key[COLUMN_UP_PIN].key_physic = gpio_config->data;
    gpio_config->config           = GPIO_IRQ_EDGE_BOTH | GPIO_IRQ_ENABLE;
    dev_control(key_gpio_dev, IOC_GPIO_SET_IRQ, (unsigned long)gpio_config);
    if(key[COLUMN_UP_PIN].key_physic == KEY_PUSH_DOWN) {
        key[COLUMN_UP_PIN].keyon_counts++;
        key[COLUMN_UP_PIN].keyoff_counts = 0;
    } else {
        key[COLUMN_UP_PIN].keyon_counts = 0;
        key[COLUMN_UP_PIN].keyoff_counts++;
    }

    if(key[COLUMN_UP_PIN].keyon_counts >= 10) {   //按键自锁ON
        key[COLUMN_UP_PIN].keyon_counts = 0;
        key[COLUMN_UP_PIN].key_logic    = KEY_LOGIC_PUSHDOWN;   //按键状态为保持按下
        SUS_LOGI(TAG, "up_move key push down\n");
        os_stop_timer(tid);
    }
    if(key[COLUMN_UP_PIN].keyoff_counts >= 10) {
        key[COLUMN_UP_PIN].keyoff_counts = 0;
        key[COLUMN_UP_PIN].key_logic     = KEY_LOGIC_PUSHUP;   //按键状态为保持按下
        SUS_LOGI(TAG, "up_move key push up\n");
        os_stop_timer(tid);
    }
}

void get_downmove_info(timer_id_t tid, void *arg)
{
    gpio_config_t *gpio_config;
    struct event e_post_from_button = { 0 };
    gpio_config                     = arg;
    gpio_config->config             = GPIO_IO_INPUT_PU;
    dev_control(key_gpio_dev, IOC_GPIO_GET, (unsigned long)gpio_config);
    key[COLUMN_DOWN_PIN].key_physic = gpio_config->data;
    gpio_config->config             = GPIO_IRQ_EDGE_BOTH | GPIO_IRQ_ENABLE;
    dev_control(key_gpio_dev, IOC_GPIO_SET_IRQ, (unsigned long)gpio_config);
    if(key[COLUMN_DOWN_PIN].key_physic == KEY_PUSH_DOWN) {
        key[COLUMN_DOWN_PIN].keyon_counts++;
        key[COLUMN_DOWN_PIN].keyoff_counts = 0;
    } else {
        key[COLUMN_DOWN_PIN].keyon_counts = 0;
        key[COLUMN_DOWN_PIN].keyoff_counts++;
    }

    if(key[COLUMN_DOWN_PIN].keyon_counts >= 10) {   //按键自锁ON
        key[COLUMN_DOWN_PIN].keyon_counts = 0;
        key[COLUMN_DOWN_PIN].key_logic    = KEY_LOGIC_PUSHDOWN;   //按键状态为保持按下
        SUS_LOGI(TAG, "down_move key push down\n");
        os_stop_timer(tid);
    }
    if(key[COLUMN_DOWN_PIN].keyoff_counts >= 10) {
        key[COLUMN_DOWN_PIN].keyoff_counts = 0;
        key[COLUMN_DOWN_PIN].key_logic     = KEY_LOGIC_PUSHUP;   //按键状态为保持按下
        SUS_LOGI(TAG, "down_move key push up\n");
        os_stop_timer(tid);
    }
}

void get_forward_info(timer_id_t tid, void *arg)
{
    gpio_config_t *gpio_config;
    struct event e_post_from_button = { 0 };
    gpio_config                     = arg;
    gpio_config->config             = GPIO_IO_INPUT_PU;
    dev_control(key_gpio_dev, IOC_GPIO_GET, (unsigned long)gpio_config);
    key[JOINT_FORWARD_PIN].key_physic = gpio_config->data;
    gpio_config->config               = GPIO_IRQ_EDGE_BOTH | GPIO_IRQ_ENABLE;
    dev_control(key_gpio_dev, IOC_GPIO_SET_IRQ, (unsigned long)gpio_config);
    if(key[JOINT_FORWARD_PIN].key_physic == KEY_PUSH_DOWN) {
        key[JOINT_FORWARD_PIN].keyon_counts++;
        key[JOINT_FORWARD_PIN].keyoff_counts = 0;
    } else {
        key[JOINT_FORWARD_PIN].keyon_counts = 0;
        key[JOINT_FORWARD_PIN].keyoff_counts++;
    }

    if(key[JOINT_FORWARD_PIN].keyon_counts >= 10) {   //按键自锁ON
        key[JOINT_FORWARD_PIN].keyon_counts = 0;
        key[JOINT_FORWARD_PIN].key_logic    = KEY_LOGIC_PUSHDOWN;   //按键状态为保持按下
        SUS_LOGI(TAG, "joint_forward key push down\n");
        os_stop_timer(tid);
    }
    if(key[JOINT_FORWARD_PIN].keyoff_counts >= 10) {
        key[JOINT_FORWARD_PIN].keyoff_counts = 0;
        key[JOINT_FORWARD_PIN].key_logic     = KEY_LOGIC_PUSHUP;   //按键状态为保持按下
        SUS_LOGI(TAG, "joint_forward key push up\n");
        os_stop_timer(tid);
    }
}

void get_backward_info(timer_id_t tid, void *arg)
{
    gpio_config_t *gpio_config;
    struct event e_post_from_button = { 0 };
    gpio_config                     = arg;
    gpio_config->config             = GPIO_IO_INPUT_PU;
    dev_control(key_gpio_dev, IOC_GPIO_GET, (unsigned long)gpio_config);
    key[JOINT_BACKWARD_PIN].key_physic = gpio_config->data;
    gpio_config->config                = GPIO_IRQ_EDGE_BOTH | GPIO_IRQ_ENABLE;
    dev_control(key_gpio_dev, IOC_GPIO_SET_IRQ, (unsigned long)gpio_config);
    if(key[JOINT_BACKWARD_PIN].key_physic == KEY_PUSH_DOWN) {   //按下0 松开1
        key[JOINT_BACKWARD_PIN].keyon_counts++;
        key[JOINT_BACKWARD_PIN].keyoff_counts = 0;
    } else {
        key[JOINT_BACKWARD_PIN].keyon_counts = 0;
        key[JOINT_BACKWARD_PIN].keyoff_counts++;
    }

    if(key[JOINT_BACKWARD_PIN].keyon_counts >= 10) {   //按键自锁ON
        key[JOINT_BACKWARD_PIN].keyon_counts = 0;
        key[JOINT_BACKWARD_PIN].key_logic    = KEY_LOGIC_PUSHDOWN;   //按键状态为保持按下
        SUS_LOGI(TAG, "joint_backward key push down\n");
        os_stop_timer(tid);
    }
    if(key[JOINT_BACKWARD_PIN].keyoff_counts >= 10) {
        key[JOINT_BACKWARD_PIN].keyoff_counts = 0;
        key[JOINT_BACKWARD_PIN].key_logic     = KEY_LOGIC_PUSHUP;   //按键状态为保持按下
        SUS_LOGI(TAG, "joint_backward key push up\n");
        os_stop_timer(tid);
    }
}

void power_button_isr()
{
    if(tpower == (timer_id_t)NULL) {
        SUS_LOGI(TAG, "tpower timer not creat befor");
    } else {
        os_start_timer_from_isr(tpower, 10);
    }
}

void estop_button_isr()
{
    if(testop == (timer_id_t)NULL) {
        SUS_LOGI(TAG, "testop timer not creat befor");
    } else {
        os_start_timer_from_isr(testop, 10);
    }
}

void onoff_button_isr()
{
    if(tonoff == (timer_id_t)NULL) {
        SUS_LOGI(TAG, "testop timer not creat befor");
    } else {
        os_start_timer_from_isr(tonoff, 10);
    }
}

void brake_button_isr()
{
    if(tbrake == (timer_id_t)NULL) {
        SUS_LOGI(TAG, "tbrake timer not creat befor");
    } else {
        os_start_timer_from_isr(tbrake, 10);
    }
}

void column_up_button_isr()
{
    if(tupmove == (timer_id_t)NULL) {
        SUS_LOGI(TAG, "tupmove timer not creat befor");
    } else {
        os_start_timer_from_isr(tupmove, 10);
    }
}

void column_down_button_isr()
{
    if(tdownmove == (timer_id_t)NULL) {
        SUS_LOGI(TAG, "tdownmove timer not creat befor");
    } else {
        os_start_timer_from_isr(tdownmove, 10);
    }
}

void joint_forward_button_isr()
{
    if(tforward == (timer_id_t)NULL) {
        SUS_LOGI(TAG, "tforward timer not creat befor");
    } else {
        os_start_timer_from_isr(tforward, 10);
    }
}

void joint_backward_button_isr()
{
    if(tbackward == (timer_id_t)NULL) {
        SUS_LOGI(TAG, "tbackward timer not creat befor");
    } else {
        os_start_timer_from_isr(tbackward, 10);
    }
}

// void key_gpio_iomap_get()
// {
// key_input_config[POWER_STATUS_PIN].id = (iomap_cfg[GPIO_POWER_KEY].group<<4)+iomap_cfg[GPIO_POWER_KEY].gpio;
// key_input_config[ESTOP_STATUS_PIN].id = (iomap_cfg[GPIO_ESTOP_KEY].group<<4)+iomap_cfg[GPIO_ESTOP_KEY].gpio;
// key_input_config[ONOFF_STATUS_PIN].id = (iomap_cfg[GPIO_ONOFF_KET].group<<4)+iomap_cfg[GPIO_ONOFF_KET].gpio;
// }
// os_queue_h queue_abnormal;

bool_t key_gpio_clean(void)
{
    return true;
}

// void test_callback()
// {
//     printf("enter irq\n");
// }

// RUN_MODULE(gpio_function, gpio_init, gpio_run, gpio_clean, 1);
