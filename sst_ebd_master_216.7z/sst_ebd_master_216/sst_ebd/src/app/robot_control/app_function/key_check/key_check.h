#ifndef _KEY_CHECK_H
#define _KEY_CHECK_H

#include "gpio_dev.h"

#define POWER_KEY_PUSH_DOWN  0
#define POWER_KEY_PUSH_UP    1
#define ESTOP_KEY_PUSH_DOWN  1
#define ESTOP_KEY_PUSH_UP    0
#define ONOFF_KEY_PUSH_DOWN  0
#define ONOFF_KEY_PUSH_UP    1
#define ONOFF_KEY_SHORT_ON   2
#define ONOFF_KEY_LONG_ON    3
#define QUEUE_ERROR_ID       0
#define COLUMN_KEY_PUSH_UP   1
#define COLUMN_KEY_PUSH_DOWN 0
#define KEY_PUSH_UP          1
#define KEY_PUSH_DOWN        0

/*按键状态 初始未知状态0    按键按下状态：1     按键松开状态0*/
#define KEY_LOGIC_INIT           0
#define KEY_LOGIC_PUSHDOWN       1
#define KEY_LOGIC_PUSHUP         2
#define KEY_LOGIC_LONG_PUSHDOWN  3
#define KEY_LOGIC_SHORT_PUSHDOWN 4

/*woring 需要报警   error 需要急停*/
#define ABNORMAL_NONE   0x00
#define ABNORMAL_WORING 0x01
#define ABNORMAL_ERROR  0x02

/*目前最多八种woring 一个bit对应一种woring*/
#define POWER_KEY_WORING 0x01
#define ONOFF_KEY_WORING 0x02

/*目前最多八种error 一个bit对应一种error*/
#define ESTOP_KEY_ERROR 0x01

enum key_timer_id {
    SWTIMER_POWER_ID,
    SWTIMER_ESTOP_ID,
    SWTIMER_ONOFF_ID,
};

struct breakdown {
    uint8_t grade;
    uint8_t data;
};

enum input_pin {
    ONOFF_STATUS_PIN,
    POWER_STATUS_PIN,
    ESTOP_STATUS_PIN,
    BRAKE_PIN,
    COLUMN_UP_PIN,
    COLUMN_DOWN_PIN,
    JOINT_FORWARD_PIN,
    JOINT_BACKWARD_PIN,
    MAX_PIN,
};

typedef struct
{
    uint8_t key_logic;
    bool_t key_physic;
    uint8_t keyon_counts;
    uint8_t keyoff_counts;
} key_stat_t;
// bool_t key_gpio_run(void);
// bool_t key_gpio_init(void);
// bool_t key_gpio_clean(void);

/**
 * @brief power button interrupt trigger function
 * @param
 */
void power_button_isr();

/**
 * @brief estop button interrupt trigger function
 * @param
 */
void estop_button_isr();

/**
 * @brief onoff button interrupt trigger function
 * @param
 */
void onoff_button_isr();

void brake_button_isr();

/**
 * @brief column upmove button interrupt trigger function
 * 
 */
void column_up_button_isr();
/**
 * @brief column downmove button interrupt trigger function
 * 
 */
void column_down_button_isr();

void joint_forward_button_isr();

void joint_backward_button_isr();
/**
 * @brief Set the power timer object
 * 
 * @param arg 
 */

void set_power_timer(gpio_config_t *arg);
/**
 * @brief Set the estop timer object
 * 
 * @param arg 
 */
void set_estop_timer(gpio_config_t *arg);

/**
 * @brief Set the onoff timer object
 * 
 * @param arg 
 */
void set_onoff_timer(gpio_config_t *arg);
/**
 * @brief Set the upmove timer object
 * 
 * @param arg 
 */
void set_upmove_timer(gpio_config_t *arg);

/**
 * @brief Set the downmove timer object
 * 
 * @param arg 
 */
void set_downmove_timer(gpio_config_t *arg);

void set_brake_timer(gpio_config_t *arg);
void set_forward_timer(gpio_config_t *arg);
void set_backward_timer(gpio_config_t *arg);
#endif /* _KEY_CHECK_H */
