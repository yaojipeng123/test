#include "types.h"
#include "stdio.h"

#include "hal_gpio.h"
#include "gpio_dev.h"
#include "dev.h"
#include "led.h"
#include "os_utils.h"
#include "os_task.h"
#include "log.h"
#include "timer_dev.h"
#include "hal_timer.h"
#include "gpio_id.h"
#define RUN_LED HAL_GPIO_51   //PD3

static const char *TAG = "led";

dev_t *led_gpio_dev = NULL;
dev_t *test_timer;

// void test_callback()
// {
//     static uint8_t i = 0;
//     printf("1111\n");
//     i++;
//     if(i==10)
//     {
//         dev_control(test_timer,IOC_TIMER_CONTROL,IO_TIMER_STOP);
//     }

// }
void run_led_task(void *arg)
{
    gpio_config_t test = { RUN_LED, GPIO_IO_OUTPUT_PP, NULL, NULL, 0 };
    uint8_t gpio_group, gpio_pin;
    uint8_t ret = iomap_lookup_gpio(GPIO_RUN_LED, &gpio_pin, &gpio_group);
    if(ret == ERR_OK) {
        test.id = gpio_group * 16 + gpio_pin;
    } else {
        SUS_LOGE(TAG, "run led can not get pin\n");
    }
    uint8_t test_data = 0;
    while(1) {
        test.data = 1;   //~test.data;
        dev_control(led_gpio_dev, IOC_GPIO_SET, (unsigned long)&test);
        // LOG_INFO("fmt, aerg... is %d\n",test.data);
        os_delay(1000);   //闪烁间隔为1s的程序运行指示灯
        test.data = 0;    //~test.data;
        dev_control(led_gpio_dev, IOC_GPIO_SET, (unsigned long)&test);
        os_delay(1000);
    }
}
static int32_t test_timer_cb(void *data)
{
    return ERR_OK;
}

int32_t run_led_init(void)
{
    int32_t ret  = ERR_OK;
    led_gpio_dev = dev_find("gpio");
    if(!led_gpio_dev) {
        SUS_LOGE(TAG, "led gpio find failed\n");
        ret = ERR_FAIL;
    }
    dev_init(led_gpio_dev);

    // test_timer = dev_find("timer2");
    // if (!test_timer) {
    //     return ERR_FAIL;
    // }

    // timer_alarm_t *test_config = os_mem_malloc(1, sizeof(timer_alarm_t));
    // if (!test_config) {
    //     os_mem_free(test_config);
    //     return ERR_FAIL;
    // }
    // memset(test_config, 0x0, sizeof(timer_alarm_t));
    // test_config->period = 0x0a;
    // test_config->repeat = true;
    // test_config->cb = test_callback;

    // test_timer->user_data = (void *)test_config;
    // // hal_timer_start(test_timer_id);
    // dev_open(test_timer,TIM_NORMAL);
    // dev_control(test_timer,IOC_TIMER_CONTROL,IO_TIMER_START);

    return ret;
}

bool_t run_led_run(void)
{
    os_create_task_ext(run_led_task, NULL, 7, 1024, "run_led_task");
    return true;
}
