#ifndef _ACOUSTOOPTIC_CTL_H
#define _ACOUSTOOPTIC_CTL_H


#define LEVEL_1     1
#define LEVEL_2     2
#define LEVEL_3     3
#define LEVEL_4     4

/*临时定义*/
#define RED         1
#define YELLOW      2
#define GREEN       3
#define BLUE        4
#define BLANK       0       //异常灯关闭

#define KEEP_LIGHT  1       //常亮
#define SHINE       2       //闪烁
#define SHORT_SHINE 3       //快闪
#define TURN_OFF    0       //熄灭

#define QUEUE_ERROR_LEVEL_ID    0
#define QUEUE_SYSTEM_STATE_ID    1

#define CLEAN_LEVEL_1_2_ERR     0xf0    //清除一二级故障 
#define SET_LEVEL_1_2_ERR       0xf1    //设定一二级故障
#define CLEAN_LEVEL_3_ERR       0xf2    //清除三级故障
#define SET_LEVEL_3_ERR         0xf3    //设定三级故障


/**
 * @brief init gpio and pwm about alarm
 * 
 * @return bool_t 
 */
int32_t alarm_init(void);

bool_t alarm_run(void);

#endif /* _ACOUSTOOPTIC_CTL_H */
