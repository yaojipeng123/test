#include "types.h"
#include "os_utils.h"
#include "os_task.h"

#include "errno.h"
#include "sm.h"
#include "dev.h"
#include "acoustooptic_ctl.h"
#include "pwm_dev.h"
#include "os_queue.h"
#include "io_output.h"
#include "log.h"

#define R_PWM_CH                1
#define G_PWM_CH                2
#define B_PWM_CH                3
#define RGB_PWM_MODE_1          0
#define RGB_PWM_MODE_2          1
#define RGB_PWM_OCPOLARITY_HIGH 0
#define RGB_PWM_OCPOLARITY_LOW  1
// dev_t *horn_gpio_dev;
// need pwm_dev as global variable or not?
// os_queue_h queue_error_level;
os_queue_h queue_rgb_clt;
extern os_queue_h gpio_output_h;
dev_t *r_pwm_dev;
dev_t *g_pwm_dev;
dev_t *b_pwm_dev;
/*控制颜色与动作的具体值可后期通过读取flash的值来更改*/
uint8_t color_array[]  = { BLANK, RED, RED, YELLOW, BLANK, BLUE, BLUE, GREEN, GREEN };
uint8_t state_array[]  = { TURN_OFF, KEEP_LIGHT, KEEP_LIGHT, KEEP_LIGHT, TURN_OFF, SHORT_SHINE, KEEP_LIGHT, SHINE, KEEP_LIGHT };
static const char *TAG = "acoustooptic";
void rgb_set_color(uint8_t color, uint8_t action);

void close_all_alarm()
{
    struct io_out_ctl output_gpio;
    SUS_LOGI(TAG, "close_all_alarm\n");
    output_gpio.id  = ERROR_LEVEL1_PIN;
    output_gpio.ctl = DRY_CON_OPEN;
    if(gpio_output_h)
        os_queue_send(gpio_output_h, &output_gpio);
    else
        SUS_LOGE(TAG, "gpio_output_h do not create\n");
    output_gpio.id  = ERROR_LEVEL2_PIN;
    output_gpio.ctl = DRY_CON_OPEN;
    if(gpio_output_h)
        os_queue_send(gpio_output_h, &output_gpio);
    output_gpio.id  = ERROR_LEVEL3_PIN;
    output_gpio.ctl = DRY_CON_OPEN;
    if(gpio_output_h)
        os_queue_send(gpio_output_h, &output_gpio);
}
void alarm_control(uint8_t ctl_val)
{
    struct io_out_ctl output_gpio;
    SUS_LOGI(TAG, "alarm_control is %d\n", ctl_val);
    switch(ctl_val) {
        case 1:
            close_all_alarm();
            output_gpio.id  = ERROR_LEVEL1_PIN;
            output_gpio.ctl = DRY_CON_CLOSE;
            if(gpio_output_h)
                os_queue_send(gpio_output_h, &output_gpio);
            break;
        case 2:
            close_all_alarm();
            output_gpio.id  = ERROR_LEVEL2_PIN;
            output_gpio.ctl = DRY_CON_CLOSE;
            if(gpio_output_h)
                os_queue_send(gpio_output_h, &output_gpio);
            break;
        case 3:
            close_all_alarm();
            output_gpio.id  = ERROR_LEVEL3_PIN;
            output_gpio.ctl = DRY_CON_CLOSE;
            if(gpio_output_h)
                os_queue_send(gpio_output_h, &output_gpio);
            break;
        default:
            close_all_alarm();
            break;
    }
}
uint8_t rgb_ctl_value;
void system_state_handle_task(void *arg)
{

    // uint8_t old_value;
    static uint8_t light_to_set         = 0xff;
    static uint8_t prev_ecat_status_ctl = 0;
    static uint8_t level1_counter       = 0;
    static uint8_t old_rgb_ctl          = 0;
    struct io_out_ctl output_gpio;
    // static bool_t level_1_2_status;//一二级故障有无状态
    // static bool_t level_3_status;//三级故障有无状态
    if(queue_rgb_clt) {
        while(1) {
            // rgb_set_color(RED,KEEP_LIGHT);
            // os_queue_receive(queue_rgb_clt, &rgb_ctl_value);   //rgb_ctl_value 高四位为主站的控灯信息 bit1为三级故障有无 bit0位一二级故障有无
            // if(rgb_ctl_value!=old_value)
            // {
            if(old_rgb_ctl != rgb_ctl_value) {
                old_rgb_ctl = rgb_ctl_value;
                SUS_LOGI(TAG, "queue recive rgb_ctl_value is%d\n", rgb_ctl_value);
                if(rgb_ctl_value < 0xf0) {
                    if(level1_counter == 0)   //安全板卡故障不存在
                    {
                        light_to_set = rgb_ctl_value;
                        alarm_control(light_to_set);
                    }
                    // light_to_set = rgb_ctl_value<light_to_set? rgb_ctl_value:light_to_set;
                    prev_ecat_status_ctl = rgb_ctl_value;
                } else if(rgb_ctl_value == 0xf0) {
                    if(--level1_counter == 0) {
                        light_to_set = prev_ecat_status_ctl;
                        close_all_alarm();
                    }
                    // else
                    //     level1_counter--;
                } else if(rgb_ctl_value == 0xf1) {   //板卡自身故障
                    // close_all_alarm();
                    // output_gpio.id  = ERROR_LEVEL1_PIN;
                    // output_gpio.ctl = DRY_CON_CLOSE;
                    // if(gpio_output_h)
                    //     os_queue_send(gpio_output_h, &output_gpio);
                    light_to_set = rgb_ctl_value - 0xf0;   //do sth;
                    alarm_control(light_to_set);
                    level1_counter++;
                }
                SUS_LOGI(TAG, "level1_counter IS %d\n", level1_counter);
                rgb_set_color(color_array[light_to_set], state_array[light_to_set]);
            }
            os_delay(50);
        }
    }
}
int32_t alarm_init(void)
{   //pwm   gpio_out

    int32_t ret = ERR_OK;
    pwm_config_t pwm_set;

    r_pwm_dev = dev_find("pwm0");   //rgb灯控的pwm初始化
    g_pwm_dev = dev_find("pwm1");
    b_pwm_dev = dev_find("pwm2");
    if((!r_pwm_dev) || (!g_pwm_dev) || (!b_pwm_dev)) {
        SUS_LOGE(TAG, "pwm find failed\n");
        return ERR_FAIL;
    }
    dev_init(r_pwm_dev);
    dev_init(g_pwm_dev);
    dev_init(b_pwm_dev);

    queue_rgb_clt = os_queue_create(QUEUE_SYSTEM_STATE_ID, 2, sizeof(uint8_t));
    SUS_LOGI(TAG, "alarm init ok\n");
    return ret;
}

void rgb_set_color(uint8_t color, uint8_t action)
{
    /*set pwm to set color*/
    uint32_t r_period = 0;
    uint32_t g_period = 0;
    uint32_t b_period = 0;
    uint8_t r_channel, g_channel, b_channel;
    pwm_set_config_t r_pwm_config = { RGB_PWM_MODE_1, 0, RGB_PWM_OCPOLARITY_HIGH, R_PWM_CH };
    pwm_set_config_t g_pwm_config = { RGB_PWM_MODE_1, 0, RGB_PWM_OCPOLARITY_HIGH, G_PWM_CH };
    pwm_set_config_t b_pwm_config = { RGB_PWM_MODE_1, 0, RGB_PWM_OCPOLARITY_HIGH, B_PWM_CH };
    if(action == TURN_OFF) {   //停止三路pwm
        SUS_LOGI(TAG, "rgb turn off\n");
        r_channel = R_PWM_CH;
        g_channel = G_PWM_CH;
        b_channel = B_PWM_CH;
        dev_control(r_pwm_dev, IOC_PWM_STOP, (unsigned long)r_channel);
        dev_control(g_pwm_dev, IOC_PWM_STOP, (unsigned long)g_channel);
        dev_control(b_pwm_dev, IOC_PWM_STOP, (unsigned long)b_channel);
    } else if(action == SHORT_SHINE)   //快闪 闪烁频率0.5s
    {
        switch(color) {
            case RED:   //红色快闪
                SUS_LOGI(TAG, "RED SHORT_SHINE\n");
                r_channel = R_PWM_CH;
                g_channel = G_PWM_CH;
                b_channel = B_PWM_CH;
                dev_control(r_pwm_dev, IOC_PWM_STOP, (unsigned long)r_channel);
                dev_control(g_pwm_dev, IOC_PWM_STOP, (unsigned long)g_channel);
                dev_control(b_pwm_dev, IOC_PWM_STOP, (unsigned long)b_channel);
                //修改R路pwm的频率，实现快闪 初始化分频后时钟频率为1MHz，重载值500000时    1MHz/500000=2Hz   1s/2=0.5s pwm周期是0.5s
                r_period           = 10000 - 1;
                r_pwm_config.pulse = r_period / 2;                                     //设置50%占空比
                dev_control(r_pwm_dev, IOC_PWM_DUTY_CYCLE, (unsigned long)r_period);   //修改周期
                dev_control(r_pwm_dev, IOC_PWM_START, (unsigned long)&r_pwm_config);   //启动pwm
                break;
            case GREEN:   //绿色快闪
                SUS_LOGI(TAG, "GREEN SHORT_SHINE\n");
                r_channel = R_PWM_CH;
                g_channel = G_PWM_CH;
                b_channel = B_PWM_CH;
                dev_control(r_pwm_dev, IOC_PWM_STOP, (unsigned long)r_channel);
                dev_control(g_pwm_dev, IOC_PWM_STOP, (unsigned long)g_channel);
                dev_control(b_pwm_dev, IOC_PWM_STOP, (unsigned long)b_channel);
                //修改R路pwm的频率，实现快闪 初始化分频后时钟频率为1MHz，重载值500000时    1MHz/500000=2Hz   1s/2=0.5s pwm周期是0.5s
                g_period           = 10000 - 1;
                g_pwm_config.pulse = g_period / 2;                                     //设置50%占空比
                dev_control(g_pwm_dev, IOC_PWM_DUTY_CYCLE, (unsigned long)g_period);   //修改周期
                dev_control(g_pwm_dev, IOC_PWM_START, (unsigned long)&g_pwm_config);   //启动pwm
                break;
            case BLUE:   //蓝色快闪
                SUS_LOGI(TAG, "BLUE SHORT_SHINE\n");
                r_channel = R_PWM_CH;
                g_channel = G_PWM_CH;
                b_channel = B_PWM_CH;
                dev_control(r_pwm_dev, IOC_PWM_STOP, (unsigned long)r_channel);
                dev_control(g_pwm_dev, IOC_PWM_STOP, (unsigned long)g_channel);
                dev_control(b_pwm_dev, IOC_PWM_STOP, (unsigned long)b_channel);
                //修改R路pwm的频率，实现快闪 初始化分频后时钟频率为1MHz，重载值500000时    1MHz/500000=2Hz   1s/2=0.5s pwm周期是0.5s
                b_period           = 10000 - 1;
                b_pwm_config.pulse = b_period / 2;                                     //设置50%占空比
                dev_control(b_pwm_dev, IOC_PWM_DUTY_CYCLE, (unsigned long)b_period);   //修改周期
                dev_control(b_pwm_dev, IOC_PWM_START, (unsigned long)&b_pwm_config);   //启动pwm
                break;
        }
    } else if(action == SHINE)   //闪烁 闪烁频率1s
    {
        switch(color) {
            case RED:   //红色闪烁
                SUS_LOGI(TAG, "RED SHINE\n");
                r_channel = R_PWM_CH;
                g_channel = G_PWM_CH;
                b_channel = B_PWM_CH;
                dev_control(r_pwm_dev, IOC_PWM_STOP, (unsigned long)r_channel);
                dev_control(g_pwm_dev, IOC_PWM_STOP, (unsigned long)g_channel);
                dev_control(b_pwm_dev, IOC_PWM_STOP, (unsigned long)b_channel);
                //修改R路pwm的频率，实现快闪 初始化分频后时钟频率为1MHz，重载值1000000时    1MHz/1000000=1Hz   1s/1=1s pwm周期是1s
                r_period           = 20000 - 1;
                r_pwm_config.pulse = r_period / 2;                                     //设置50%占空比
                dev_control(r_pwm_dev, IOC_PWM_DUTY_CYCLE, r_period);                  //修改周期
                dev_control(r_pwm_dev, IOC_PWM_START, (unsigned long)&r_pwm_config);   //启动pwm
                break;
            case GREEN:   //绿色闪烁
                SUS_LOGI(TAG, "GREEN SHINE\n");
                r_channel = R_PWM_CH;
                g_channel = G_PWM_CH;
                b_channel = B_PWM_CH;
                dev_control(r_pwm_dev, IOC_PWM_STOP, (unsigned long)r_channel);
                dev_control(g_pwm_dev, IOC_PWM_STOP, (unsigned long)g_channel);
                dev_control(b_pwm_dev, IOC_PWM_STOP, (unsigned long)b_channel);
                //修改R路pwm的频率，实现快闪 初始化分频后时钟频率为1MHz，重载值1000000时    1MHz/1000000=1Hz   1s/1=1s pwm周期是1s
                g_period           = 20000 - 1;
                g_pwm_config.pulse = g_period / 2;                                     //设置50%占空比
                dev_control(g_pwm_dev, IOC_PWM_DUTY_CYCLE, (unsigned long)g_period);   //修改周期
                dev_control(g_pwm_dev, IOC_PWM_START, (unsigned long)&g_pwm_config);   //启动pwm
                break;
            case BLUE:   //蓝色闪烁
                SUS_LOGI(TAG, "BLUE SHINE\n");
                r_channel = R_PWM_CH;
                g_channel = G_PWM_CH;
                b_channel = B_PWM_CH;
                dev_control(r_pwm_dev, IOC_PWM_STOP, (unsigned long)r_channel);
                dev_control(g_pwm_dev, IOC_PWM_STOP, (unsigned long)g_channel);
                dev_control(b_pwm_dev, IOC_PWM_STOP, (unsigned long)b_channel);
                //修改R路pwm的频率，实现快闪 初始化分频后时钟频率为1MHz，重载值1000000时    1MHz/1000000=1Hz   1s/1=1s pwm周期是1s
                b_period           = 20000 - 1;
                b_pwm_config.pulse = b_period / 2;                                     //设置50%占空比
                dev_control(b_pwm_dev, IOC_PWM_DUTY_CYCLE, (unsigned long)b_period);   //修改周期
                dev_control(b_pwm_dev, IOC_PWM_START, (unsigned long)&b_pwm_config);   //启动pwm
                break;
        }
    } else if(action == KEEP_LIGHT) {
        switch(color) {
            case RED:   //红色常亮
                SUS_LOGI(TAG, "RED KEEP_LIGHT\n");
                r_channel = R_PWM_CH;
                g_channel = G_PWM_CH;
                b_channel = B_PWM_CH;
                dev_control(r_pwm_dev, IOC_PWM_STOP, (unsigned long)r_channel);
                dev_control(g_pwm_dev, IOC_PWM_STOP, (unsigned long)g_channel);
                dev_control(b_pwm_dev, IOC_PWM_STOP, (unsigned long)b_channel);
                //修改R路pwm的频率，实现快闪 初始化分频后时钟频率为1MHz，重载值20000
                r_period           = 20000 - 1;
                r_pwm_config.pulse = r_period;   //设置100%占空比
                // dev_control(r_pwm_dev,IOC_PWM_DUTY_CYCLE,(unsigned long)&r_period);//修改周期
                dev_control(r_pwm_dev, IOC_PWM_START, (unsigned long)&r_pwm_config);   //启动pwm
                break;
            case YELLOW:   //red+green=yellow
                SUS_LOGI(TAG, "YELLOW KEEP_LIGHT\n");
                r_channel = R_PWM_CH;
                g_channel = G_PWM_CH;
                b_channel = B_PWM_CH;
                dev_control(r_pwm_dev, IOC_PWM_STOP, (unsigned long)r_channel);
                dev_control(g_pwm_dev, IOC_PWM_STOP, (unsigned long)g_channel);
                dev_control(b_pwm_dev, IOC_PWM_STOP, (unsigned long)b_channel);
                //修改R路pwm的频率，实现快闪 初始化分频后时钟频率为1MHz，重载值500
                r_period           = 200 - 1;
                g_period           = 200 - 1;
                r_pwm_config.pulse = r_period;                                         //设置100%占空比
                g_pwm_config.pulse = g_period - 160;                                   //设置100%占空比
                dev_control(r_pwm_dev, IOC_PWM_DUTY_CYCLE, (unsigned long)r_period);   //修改周期
                dev_control(g_pwm_dev, IOC_PWM_DUTY_CYCLE, (unsigned long)g_period);   //修改周期
                dev_control(r_pwm_dev, IOC_PWM_START, (unsigned long)&r_pwm_config);   //启动pwm
                dev_control(g_pwm_dev, IOC_PWM_START, (unsigned long)&g_pwm_config);   //启动pwm
                break;
            case GREEN:
                SUS_LOGI(TAG, "GREEN KEEP_LIGHT\n");
                r_channel = R_PWM_CH;
                g_channel = G_PWM_CH;
                b_channel = B_PWM_CH;
                dev_control(r_pwm_dev, IOC_PWM_STOP, (unsigned long)r_channel);
                dev_control(g_pwm_dev, IOC_PWM_STOP, (unsigned long)g_channel);
                dev_control(b_pwm_dev, IOC_PWM_STOP, (unsigned long)b_channel);
                //修改R路pwm的频率，实现快闪 初始化分频后时钟频率为1MHz，重载值500
                g_period           = 20000 - 1;
                g_pwm_config.pulse = g_period;                                         //设置50%占空比
                dev_control(g_pwm_dev, IOC_PWM_DUTY_CYCLE, (unsigned long)g_period);   //修改周期
                dev_control(g_pwm_dev, IOC_PWM_START, (unsigned long)&g_pwm_config);   //启动pwm
                break;
            case BLUE:
                SUS_LOGI(TAG, "BLUE KEEP_LIGHT\n");
                r_channel = R_PWM_CH;
                g_channel = G_PWM_CH;
                b_channel = B_PWM_CH;
                dev_control(r_pwm_dev, IOC_PWM_STOP, (unsigned long)r_channel);
                dev_control(g_pwm_dev, IOC_PWM_STOP, (unsigned long)g_channel);
                dev_control(b_pwm_dev, IOC_PWM_STOP, (unsigned long)b_channel);
                //修改R路pwm的频率，实现快闪 初始化分频后时钟频率为1MHz，重载值500
                b_period           = 20000 - 1;
                b_pwm_config.pulse = b_period;                                         //设置50%占空比
                dev_control(b_pwm_dev, IOC_PWM_DUTY_CYCLE, (unsigned long)b_period);   //修改周期
                dev_control(b_pwm_dev, IOC_PWM_START, (unsigned long)&b_pwm_config);   //启动pwm
                break;
        }
    }
}

bool_t alarm_run(void)
{
    rgb_set_color(BLANK, TURN_OFF);
    // rgb_set_color(GREEN, SHORT_SHINE);
    // rgb_set_color(RED, SHORT_SHINE);
    // rgb_set_color(BLUE, SHORT_SHINE);   //初始化蓝灯快闪 保留
    // rgb_set_color(GREEN, KEEP_LIGHT);
    // rgb_set_color(RED, KEEP_LIGHT);
    // rgb_set_color(YELLOW, KEEP_LIGHT);
    // rgb_set_color(RED, KEEP_LIGHT);
    // rgb_set_color(BLUE, SHORT_SHINE);   //初始化蓝灯快闪 保留
    // rgb_set_color(BLANK, TURN_OFF);
    SUS_LOGI(TAG, "alarm task start\n");
    // rgb_set_color(BLUE,SHORT_SHINE);
    os_create_task_ext(system_state_handle_task, NULL, 7, 1024, "system_state_handle_task");
    return true;
}
