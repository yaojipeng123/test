#include "types.h"
#include "stdio.h"
#include "dev.h"
#include "os_queue.h"

#include "iomap.h"
#include "gpio_id.h"
#include "key.h"
#include "key_check.h"
#include "gpio_dev.h"
#include "sm.h"
#include "io_input.h"
#include "log.h"
dev_t *dig_gpio_dev;
extern os_queue_h queue_rgb_clt;
static const char *TAG = "io_input";

dig_stat_t dig[DIG_ID_MAX] = {
    { false, 0, 0 },
    { false, 0, 0 },
    { false, 0, 0 },
    { false, 0, 0 },
    { false, 0, 0 }
};
key_stat_t up_down_key[2] = {
    { 0, 0, 0, 0 },
    { 0, 0, 0, 0 }
};

uint8_t count[DIG_ID_MAX] = { 0 };

uint8_t dig_state[DIG_ID_MAX] = { 0 };
/* 立柱按键中断做
    // DIG_IN3     HAL_GPIO_123    PH11        立柱上升按钮
    // DIG_IN4     HAL_GPIO_124    PH12        立柱下降按钮
    DIG_IN5     HAL_GPIO_125    PH13        电源回路1上电反馈状态
    DIG_IN6     HAL_GPIO_126    PH14        电源回路2上电反馈状态
    DIG_IN7     HAL_GPIO_127    PH15        电源回路3上电反馈状态
*/
gpio_config_t dig_input[] = {
    // {HAL_GPIO_123,GPIO_IO_INPUT_PU,NULL,NULL,0},//PH11  上升按钮
    // {HAL_GPIO_124,GPIO_IO_INPUT_PU,NULL,NULL,0},//PH12   下降按钮
    { HAL_GPIO_125, GPIO_IO_INPUT_PU, NULL, NULL, 0 },   //PH13   回路1
    { HAL_GPIO_126, GPIO_IO_INPUT_PU, NULL, NULL, 0 },   //PH14     回路2
    { HAL_GPIO_127, GPIO_IO_INPUT_PU, NULL, NULL, 0 }    //PH15     回路3
};

void check_dig(uint8_t dig_id)
{
    uint8_t err_code_send;
    if(dig_id >= DIG_ID_MAX)
        return;
    dev_control(dig_gpio_dev, IOC_GPIO_GET, (unsigned long)&dig_input[dig_id]);
    // if(dig_id>1)
    // {//检测是否上电成功
    if(dig_input[dig_id].data != dig_state[dig_id]) {
        dig[dig_id].diff_count++;
        dig[dig_id].same_count = 0;
        if(dig[dig_id].diff_count >= 10) {
            dig[dig_id].diff_count = 0;
            if(!dig[dig_id].diff_flag) {   //第一次出现继电器检测值与预期值不一致  报错
                dig[dig_id].diff_flag = true;
                err_code_send         = 0xf1;   //设定故障
                if(queue_rgb_clt)
                    os_queue_send(queue_rgb_clt, &err_code_send);
            }
        }
    } else {
        dig[dig_id].diff_count = 0;
        dig[dig_id].same_count++;
        if(dig[dig_id].same_count >= 10) {
            if(dig[dig_id].diff_flag) {   //首次满足清除条件 清除故障
                dig[dig_id].diff_flag = false;
                err_code_send         = 0xf0;   //清除故障
                if(queue_rgb_clt)
                    os_queue_send(queue_rgb_clt, &err_code_send);
            }
        }
    }
    // }
    // else{//判断按键是否按下
    //     dev_control(dig_gpio_dev, IOC_GPIO_GET, (unsigned long)&dig_input[dig_id]);
    //     up_down_key[dig_id].key_physic = dig_input[dig_id].data;
    //     if(up_down_key[dig_id].key_physic)
    //     {
    //         up_down_key[dig_id].keyoff_counts = 0;
    //         up_down_key[dig_id].keyon_counts++;
    //         if(up_down_key[dig_id].keyon_counts>=10)
    //         {
    //             up_down_key[dig_id].keyon_counts = 0;
    //             up_down_key[dig_id].key_logic = KEY_LOGIC_PUSHUP;
    //         }
    //     }else{
    //         up_down_key[dig_id].keyon_counts = 0;
    //         up_down_key[dig_id].keyoff_counts++;
    //         if(up_down_key[dig_id].keyoff_counts>=10)
    //         {
    //             up_down_key[dig_id].keyoff_counts = 0;
    //             up_down_key[dig_id].key_logic = KEY_LOGIC_PUSHDOWN;
    //         }
    //     }
    // }
}

void dig_read_task(void *arg)
{
    SUS_LOGI(TAG, "dig read task start\n");
    while(1) {
        for(int i = 0; i < DIG_ID_MAX; i++) {
            check_dig(i);
        }
        os_delay(7000);
    }
}

int32_t dig_gpio_init(void)
{
    int32_t ret = ERR_OK;

    // key_gpio_iomap_get();
    dig_gpio_dev = dev_find("gpio");

    if(!dig_gpio_dev) {
        SUS_LOGE(TAG, "gpio find failed\n");
        return ERR_FAIL;
    }
    dev_init(dig_gpio_dev);
    SUS_LOGI(TAG, "dig gpio inited\n");
    return ret;
}

bool_t dig_gpio_run(void)
{

    os_create_task_ext(dig_read_task, NULL, 7, 1024, "dig_read_task");

    return true;
}