#ifndef _IO_INPUT_H
#define _IO_INPUT_H

enum dig_id{
    // DIG_UP_STATE,                //升降柱上升按钮状态
    // DIG_DOWN_STATE,                //升降柱下降按钮状态
    LOOP1_POWER_STATE,            //工控机电源状态
    LOOP2_POWER_STATE,         //调整机构电源状态
    LOOP3_POWER_STATE,         //调整机构电源状态
    // DIG_OPERATE_POWER_STATE,        //操作头电源状态
    DIG_ID_MAX
};
typedef struct
{
 	bool_t diff_flag;
	uint8_t diff_count;
    uint8_t same_count;
}dig_stat_t;

#endif