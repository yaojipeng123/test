#include "types.h"
#include "stdio.h"

#include "ecat_task.h"
#include "el9800appl.h"
#include "hal_Fmc.h"
#include "hal_timer.h"

#include "os_task.h"
#include "dev.h"
#include "gpio_dev.h"
#include "timer_dev.h"
#include "led.h"
dev_t *ecat_gpio_dev;
dev_t *ecat_timer;
int32_t ethercat_init(void)
{
    int32_t ret = ERR_OK;
    ecat_timer = dev_find("timer1");
    if (!ecat_timer) {
        return ERR_FAIL;
    }
    ecat_gpio_dev = dev_find("gpio");

    if (!ecat_gpio_dev) {
        return ERR_FAIL;
    }

    dev_init(ecat_gpio_dev);
    ret = hal_fmc_nor_init();
    // hal_fmc_sram_init();

    return ret;
}

bool_t ethercat_run(void)
{

    os_create_task_ext(ethcat_task, NULL, 8, 512, "ethcat_task");   //开始ecat通信task
    // led_test_val = 10;
    // hal_timer_create(1,5000,0,ethercat_init,NULL);
    // hal_timer_start(1);
    return true;
}

bool_t ethercat_clean(void)
{
    return true;
}

// RUN_MODULE(ethercat, ethercat_init, ethercat_run, ethercat_clean, 1);