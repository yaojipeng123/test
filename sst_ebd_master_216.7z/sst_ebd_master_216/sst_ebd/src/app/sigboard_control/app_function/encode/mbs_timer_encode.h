#ifndef _MBS_TIMER_ENCODE_H
#define _MBS_TIMER_ENCODE_H

#define CMD_GET_INFO 0x00
#define CMD_SET_ZERO 0x20
#define CMD_SET_ADDR 0x40
#define INITIAL_ADDR 0x1f
#define ENCODE1_ADDR 0x05
#define ENCODE2_ADDR 0x06
#define ENCODE3_ADDR 0x07
#define RCV_BUF_LEN  6
/**
 * @brief init the timer and set timer's value
 * @param
 * @return int32_t 
 */
int32_t encode_timer_init(void);

/**
 * @brief open timer and start timer
 * @param
 * @return boot_t 
 */
bool_t encode_timer_run(void);
#endif