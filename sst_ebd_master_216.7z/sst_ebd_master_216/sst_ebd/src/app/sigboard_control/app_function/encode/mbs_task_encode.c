#include "types.h"
#include "stdio.h"

#include "hal_gpio.h"
#include "gpio_dev.h"
#include "dev.h"

#include "os_utils.h"
#include "os_task.h"
#include "os_queue.h"

#include "mbs_task_encode.h"
#include "kingkong_encode.h"

#define RS485_RE_PIN HAL_GPIO_7

uint8_t encode1_rcv_buf[128] = {0};
uint8_t encode2_rcv_buf[128] = {0};
uint8_t encode3_rcv_buf[128] = {0};
uint8_t encode4_rcv_buf[128] = {0};
uint32_t encode1_val = 0;
uint32_t encode2_val = 0;
uint32_t encode3_val = 0;
uint32_t encode4_val = 0;
void encode_task(void *arg)
{
    uint8_t ret = 0;
    while (1) {
        // kingkong_set_addr(0x05);
        kingkong_get_info(encode4_rcv_buf,ENCODE4_ADDR,RS485_RE_PIN);
        ret =  kingkong_value_check(encode4_rcv_buf,RCV_BUF_LEN);
        if(ret)
        {
            encode4_val = encode4_rcv_buf[2]+(encode4_rcv_buf[3]<<8)+(encode4_rcv_buf[4]<<16);
            //read encode value error
        }else{
            // encode4_val = 0;
        }
        // kingkong_get_info(encode1_rcv_buf,ENCODE1_ADDR,RS485_RE_PIN);
        // ret =  kingkong_value_check(encode1_rcv_buf,RCV_BUF_LEN);
        // if(ret)
        // {
        //     encode1_val = encode1_rcv_buf[2]+(encode1_rcv_buf[3]<<8)+(encode1_rcv_buf[4]<<16);
        //     //read encode value error
        // }
        // else{
        //     // encode1_val = 0;
        // }
        kingkong_get_info(encode2_rcv_buf,ENCODE2_ADDR,RS485_RE_PIN);
        ret = kingkong_value_check(encode2_rcv_buf,RCV_BUF_LEN);
        if(ret)
        {
            encode2_val = encode2_rcv_buf[2]+(encode2_rcv_buf[3]<<8)+(encode2_rcv_buf[4]<<16);
        }else{
            // encode2_val = 0;
        }
        kingkong_get_info(encode3_rcv_buf,ENCODE3_ADDR,RS485_RE_PIN);
        ret = kingkong_value_check(encode3_rcv_buf,RCV_BUF_LEN);
        if(ret)
        {
            encode3_val = encode3_rcv_buf[2]+(encode3_rcv_buf[3]<<8)+(encode3_rcv_buf[4]<<16);
        }else{
            // encode3_val = 0;
        }
        os_delay(2);
    }
}


int32_t encode_task_init(void)
{
    int32_t ret = ERR_OK;
    ret = kingkong_485_init("uart2",RS485_RE_PIN);

    return ret;
}

bool_t encode_task_run(void)
{
    os_create_task_ext(encode_task, NULL, 7, 1024, "encode_task");
}