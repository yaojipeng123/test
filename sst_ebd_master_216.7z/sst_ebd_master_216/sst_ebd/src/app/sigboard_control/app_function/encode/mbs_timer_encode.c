#include "types.h"
#include "stdio.h"

#include "os_utils.h"
#include "os_task.h"

#include "dev.h"
#include "timer_dev.h"

#include "modules.h"

#include "mbs_timer_encode.h"
#include "kingkong_encode.h"
#include "string.h"
#define RS485_RE_PIN 7// need check later

uint8_t encode1_timer_rcv_buf[128] = {0};
uint8_t encode2_timer_rcv_buf[128] = {0};
uint8_t encode3_timer_rcv_buf[128] = {0};
uint32_t encode1_timer_val = 0;
uint32_t encode2_timer_val = 0;
uint32_t encode3_timer_val = 0;
dev_t *encode_timer;
void encode_timerirq_getvalue();
// timer_status_t encode_timer_config = {0,0,{2,10, true, encode_timerirq_getvalue, NULL}};
// timer_alarm_t etimer_config = {1,10, true, TimerIsr, NULL};
int32_t encode_timer_init(void)
{
    int32_t ret = ERR_OK;
    timer_alarm_t *encode_timer_config = os_mem_malloc(LIB_MID, sizeof(timer_alarm_t));
    if (!encode_timer_config) {
        os_mem_free(encode_timer_config);
        return ERR_FAIL;
    }
    memset(encode_timer_config, 0x0, sizeof(timer_alarm_t));
    encode_timer_config->period = 0x0a;
    encode_timer_config->repeat = true;
    encode_timer_config->cb = encode_timerirq_getvalue;
    encode_timer = dev_find("timer2");
    if (!encode_timer) {
        ret = ERR_FAIL;
        return ret;
    }
    encode_timer->user_data = (void *)encode_timer_config;
    return ret;
}

// void run_encode_timer(void *arg)
// {
//     dev_control(encode_timer,IOC_TIMER_CREATE,(unsigned long)&encode_timer_config);
//     dev_control(encode_timer,IOC_TIMER_CONTROL,IO_TIMER_START);
// }
bool_t encode_timer_run(void)
{
    // dev_control(encode_timer,IOC_TIMER_CREATE,(unsigned long)&encode_timer_config);
    dev_open(encode_timer,TIM_NORMAL);
    dev_control(encode_timer, IOC_TIMER_CONTROL, IO_TIMER_START);
    // os_create_task_ext(run_encode_timer, NULL, 7, 1024, "run_encode_timer");
}

void encode_timerirq_getvalue()
{
    uint8_t ret = 0;
    kingkong_get_info(encode1_timer_rcv_buf, ENCODE1_ADDR,RS485_RE_PIN);
    ret = kingkong_value_check(encode1_timer_rcv_buf, RCV_BUF_LEN);
    if (ret) {
        encode1_timer_val = encode1_timer_rcv_buf[2] + (encode1_timer_rcv_buf[3] << 8)
            + (encode1_timer_rcv_buf[4] << 16);
        //read encode value error
    } else {
        // encode1_timer_val = 0;
    }
    kingkong_get_info(encode2_timer_rcv_buf, ENCODE2_ADDR,RS485_RE_PIN);
    ret = kingkong_value_check(encode2_timer_rcv_buf, RCV_BUF_LEN);
    if (ret) {
        encode2_timer_val = encode2_timer_rcv_buf[2] + (encode2_timer_rcv_buf[3] << 8)
            + (encode2_timer_rcv_buf[4] << 16);
    } else {
        // encode2_timer_val = 0;
    }
    kingkong_get_info(encode3_timer_rcv_buf, ENCODE3_ADDR,RS485_RE_PIN);
    ret = kingkong_value_check(encode3_timer_rcv_buf, RCV_BUF_LEN);
    if (ret) {
        encode3_timer_val = encode3_timer_rcv_buf[2] + (encode3_timer_rcv_buf[3] << 8)
            + (encode3_timer_rcv_buf[4] << 16);
    } else {
        // encode3_timer_val = 0;
    }
}