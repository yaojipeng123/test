#ifndef _MBS_TASK_ENCODE_H
#define _MBS_TASK_ENCODE_H

#define CMD_GET_INFO 0x00
#define CMD_SET_ZERO 0x20
#define CMD_SET_ADDR 0x40
#define INITIAL_ADDR 0x1f
#define ENCODE1_ADDR    0x05
#define ENCODE2_ADDR    0x06
#define ENCODE3_ADDR    0x07
#define ENCODE4_ADDR    0x09
#define RCV_BUF_LEN     6
/**
 * @brief init gpio and uart about 485 communication
 * @param
 * @return int32_t 
 */
int32_t encode_task_init(void);

/**
 * @brief create a task about get the kingkong encode value
 * @param
 * @return boot_t 
 */
bool_t encode_task_run(void);
#endif