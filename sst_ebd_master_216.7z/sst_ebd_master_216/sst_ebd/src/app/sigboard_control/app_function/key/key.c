#include "types.h"
#include "stdio.h"
#include "dev.h"
#include "os_queue.h"

#include "iomap.h"
#include "gpio_id.h"
#include "key_irq_ctl.h"
#include "key.h"
#include "gpio_dev.h"
#include "sm.h"
dev_t *key_gpio_dev;
os_queue_h queue_abnormal;

extern iomap_iomap_cfg_t iomap_cfg[IOMAP_CFG_MAX];

key_stat_t key[3] =
	{
        {0, 0, 0, 0},
        {0, 0, 0, 0},
	    {0, 0, 0, 0}
    };
/*
    HAL_GPIO_130        PI2
    HAL_GPIO_131        PI3
*/
gpio_config_t key_input_config[] = {
    {HAL_GPIO_130, GPIO_IRQ_EDGE_BOTH, upmove_key_isr, NULL,0},
    {HAL_GPIO_131, GPIO_IRQ_EDGE_BOTH, downmove_key_isr, NULL,0},
    // {HAL_GPIO_122, GPIO_IRQ_EDGE_BOTH, onoff_button_isr, NULL,0},
};
void key_gpio_iomap_get()
{
    key_input_config[UPMOVE_KEY_PIN].id = (iomap_cfg[GPIO_UPMOVE_KEY].group<<4)+iomap_cfg[GPIO_UPMOVE_KEY].gpio;
    key_input_config[DOWNMOVE_KEY_PIN].id = (iomap_cfg[GPIO_DOWNMOVE_KEY].group<<4)+iomap_cfg[GPIO_DOWNMOVE_KEY].gpio;
}

int32_t key_gpio_init(void)
{
    int32_t ret = ERR_OK;
    struct breakdown abnormal_type = {0};
    queue_abnormal = os_queue_create(QUEUE_ABNORMAL_ID,8,sizeof(struct event));

    // key_gpio_iomap_get();
    // gpio_device_init();
    set_upmove_timer(&key_input_config[UPMOVE_KEY_PIN]);
    set_downmove_timer(&key_input_config[DOWNMOVE_KEY_PIN]);
    key_gpio_dev = dev_find("gpio");

    if (!key_gpio_dev) {
        return ERR_FAIL;
    }
    dev_init(key_gpio_dev);

    /**/
    key_input_config[UPMOVE_KEY_PIN].config = GPIO_IO_INPUT_PU;
    dev_control(key_gpio_dev, IOC_GPIO_GET, (unsigned long)&key_input_config[UPMOVE_KEY_PIN]);
    key[UPMOVE_KEY_PIN].key_physic = key_input_config[UPMOVE_KEY_PIN].data;
    if(key[UPMOVE_KEY_PIN].key_physic)
    {
        key[UPMOVE_KEY_PIN].key_logic = KEY_LOGIC_PUSHUP;
        abnormal_type.grade = abnormal_type.grade | ABNORMAL_WORING;
        abnormal_type.data = abnormal_type.data | UPMOVE_KEY_WORING;
    }

    key_input_config[DOWNMOVE_KEY_PIN].config = GPIO_IO_INPUT_PU;
    dev_control(key_gpio_dev, IOC_GPIO_GET, (unsigned long)&key_input_config[DOWNMOVE_KEY_PIN]);
    key[DOWNMOVE_KEY_PIN].key_physic = key_input_config[DOWNMOVE_KEY_PIN].data;
    if(key[DOWNMOVE_KEY_PIN].key_physic)
    {
        
        key[DOWNMOVE_KEY_PIN].key_logic = KEY_LOGIC_PUSHDOWN;
        abnormal_type.grade = abnormal_type.grade | ABNORMAL_WORING;
        abnormal_type.data = abnormal_type.data | DOWNMOVE_KEY_WORING;
    }

    /* */
    os_queue_send(queue_abnormal, &abnormal_type);
    return ret;
}



bool_t key_gpio_run(void)
{

    key_input_config[UPMOVE_KEY_PIN].config = GPIO_IRQ_EDGE_BOTH;
    dev_control(key_gpio_dev, IOC_GPIO_SET_IRQ, (unsigned long)&key_input_config[UPMOVE_KEY_PIN]);

    key_input_config[DOWNMOVE_KEY_PIN].config = GPIO_IRQ_EDGE_BOTH;
    dev_control(key_gpio_dev, IOC_GPIO_SET_IRQ, (unsigned long)&key_input_config[DOWNMOVE_KEY_PIN]);

    return true;
}