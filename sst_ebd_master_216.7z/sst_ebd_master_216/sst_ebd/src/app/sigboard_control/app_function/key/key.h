#ifndef _KEY_H
#define _KEY_H

/*woring 需要报警   error 需要急停*/
#define ABNORMAL_NONE   0x00
#define ABNORMAL_WORING 0x01
#define ABNORMAL_ERROR  0x02

/*目前最多八种woring 一个bit对应一种woring*/
#define UPMOVE_KEY_WORING    0x01
#define DOWNMOVE_KEY_WORING    0x02

/*目前最多八种error 一个bit对应一种error*/
#define ESTOP_KEY_ERROR     0x01

/**
 * @brief init gpio timer
 * @param
 * @return boot_t 
 */
bool_t key_gpio_run(void);

/**
 * @brief init the gpio about key
 * @param
 * @return boot_t 
 */
int32_t key_gpio_init(void);


#endif