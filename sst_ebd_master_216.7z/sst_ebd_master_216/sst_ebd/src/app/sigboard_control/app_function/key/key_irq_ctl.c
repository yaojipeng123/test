#include "types.h"
#include "stdio.h"

#include "os_utils.h"
#include "os_task.h"
#include "os_timer.h"
#include "os_queue.h"

#include "log.h"

#include "hal_gpio.h"
#include "hal_timer.h"

#include "dev.h"
#include "key_irq_ctl.h"
#include "sm.h"
// #include "sm_module.h"

// #define IOMAP_CFG_MAX 32
#define TEST_GPIO_INPUT  HAL_GPIO_115   //(GPIOH, 3)
#define TEST_GPIO_OUTPUT HAL_GPIO_17    //(GPIOB, 1)
#define INT_ESC_PIN      HAL_GPIO_8
#define RUN_LED          HAL_GPIO_51
static timer_id_t tupmove;   //定时器句柄
static timer_id_t tdownmove;   //定时器句柄

extern dev_t *key_gpio_dev;
// extern os_queue_h state_input_h;

// void test_callback();

void get_upmove_key(timer_id_t tid, void *arg);
void get_downmove_key(timer_id_t tid, void *arg);



extern key_stat_t key[3] ;



void set_upmove_timer(gpio_config_t *arg)
{
    tupmove = os_create_timer(SWTIMER_UPMOVE_ID, true, get_upmove_key, arg);   //创建定时器
}

void set_downmove_timer(gpio_config_t *arg)
{
    tdownmove = os_create_timer(SWTIMER_DOWNMOVE_ID, true, get_downmove_key, arg);   //创建定时器
}




void get_upmove_key(timer_id_t tid, void *arg)
{
    // key_ctr_config_t *set_config;
    // gpio_io_config_t *gpio_set_config;
    // gpio_irq_config_t *gpio_irq_set_config;
    gpio_config_t *gpio_config;
    struct event e_post_from_button = {0};
    gpio_config = arg;
    // gpio_set_config = set_config->gconfig;
    // gpio_irq_set_config = set_config->girqconfig;
    gpio_config->config = GPIO_IO_INPUT_PU;
    key[UPMOVE_KEY_PIN].key_physic = dev_control(key_gpio_dev,IOC_GPIO_GET,(unsigned long)gpio_config);
    gpio_config->config = GPIO_IRQ_EDGE_BOTH;
    dev_control(key_gpio_dev,IOC_GPIO_SET_IRQ,(unsigned long)gpio_config);
    if(key[UPMOVE_KEY_PIN].key_physic == UPMOVE_KEY_PUSH_DOWN) {
      //counter ++;
      key[UPMOVE_KEY_PIN].keyon_counts++;
    }else{
        if (key[UPMOVE_KEY_PIN].keyon_counts > 10) {   
            key[UPMOVE_KEY_PIN].key_logic = KEY_LOGIC_PUSHDOWN;
            LOG_INFO(LOG_ID,"onoff key short on\n");
            e_post_from_button.type = EVENT_START_UP;
            e_post_from_button.data = 1;
            // os_queue_send(state_input_h, &e_post_from_button);
        }
        key[UPMOVE_KEY_PIN].keyon_counts = 0;
        os_stop_timer(tid);
    }
}

void get_downmove_key(timer_id_t tid, void *arg)
{
    // key_ctr_config_t *set_config;
    // gpio_io_config_t *gpio_set_config;
    // gpio_irq_config_t *gpio_irq_set_config;
    gpio_config_t *gpio_config;
    struct event e_post_from_button = {0};
    gpio_config = arg;
    // gpio_set_config = set_config->gconfig;
    // gpio_irq_set_config = set_config->girqconfig;
    gpio_config->config = GPIO_IO_INPUT_PU;
    key[DOWNMOVE_KEY_PIN].key_physic = dev_control(key_gpio_dev,IOC_GPIO_GET,(unsigned long)gpio_config);
    gpio_config->config = GPIO_IRQ_EDGE_BOTH;
    dev_control(key_gpio_dev,IOC_GPIO_SET_IRQ,(unsigned long)gpio_config);
    if(key[DOWNMOVE_KEY_PIN].key_physic == DOWNMOVE_KEY_PUSH_DOWN) {
      //counter ++;
      key[DOWNMOVE_KEY_PIN].keyon_counts++;
    }else{
        if (key[DOWNMOVE_KEY_PIN].keyon_counts > 10) {   
            key[DOWNMOVE_KEY_PIN].key_logic = KEY_LOGIC_PUSHDOWN;
            LOG_INFO(LOG_ID,"onoff key short on\n");
            e_post_from_button.type = EVENT_START_UP;
            e_post_from_button.data = 1;
            // os_queue_send(state_input_h, &e_post_from_button);
        }
        key[DOWNMOVE_KEY_PIN].keyon_counts = 0;
        os_stop_timer(tid);
    }
}

void upmove_key_isr()
{
    if (tupmove == (timer_id_t)NULL) {
        LOG_INFO(LOG_ID,"tupmove timer not creat befor\n");
    } else {
        os_start_timer_from_isr(tupmove, 10);
    }
}

void downmove_key_isr()
{
    if (tdownmove == (timer_id_t)NULL) {
        LOG_INFO(LOG_ID,"downmove timer not creat befor\n");
    } else {
        os_start_timer_from_isr(tdownmove, 10);
    }
}







bool_t key_gpio_clean(void)
{
    return true;
}
