#ifndef _KEY_IRQ_CTL_H
#define _KEY_IRQ_CTL_H

#include "gpio_dev.h"
#define UPMOVE_KEY_PUSH_DOWN     0
#define UPMOVE_KEY_PUSH_UP       1
#define DOWNMOVE_KEY_PUSH_DOWN     1
#define MOWNMOVE_KEY_PUSH_UP       0

#define QUEUE_ABNORMAL_ID   0

/*按键状态 初始未知状态0    按键按下状态：1     按键松开状态0*/
#define KEY_LOGIC_INIT              0
#define KEY_LOGIC_PUSHDOWN          1
#define KEY_LOGIC_PUSHUP            2
#define KEY_LOGIC_LONG_PUSHDOWN     3
#define KEY_LOGIC_SHORT_PUSHDOWN    4



enum key_timer_id{
    SWTIMER_UPMOVE_ID,
    SWTIMER_DOWNMOVE_ID, 
};


struct breakdown
{
   uint8_t grade;
   uint8_t data;
};

enum input_pin{
    UPMOVE_KEY_PIN,
    DOWNMOVE_KEY_PIN,
};

typedef struct
{
 	uint8_t key_logic;
	uint8_t key_physic;
 	uint8_t keyon_counts;
 	uint8_t keyoff_counts;
}key_stat_t;

/**
 * @brief key interrupt callback
 * 
 */
void upmove_key_isr();

/**
 * @brief key interrupt callback
 * 
 */
void downmove_key_isr();

/**
 * @brief create timer
 * @param arg
 */
void set_upmove_timer(gpio_config_t *arg);

/**
 * @brief create timer
 * @param arg
 */
void set_downmove_timer(gpio_config_t *arg);

#endif /* _KEY_CHECK_H */
