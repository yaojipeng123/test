#ifndef _IO_OUTPUT_H
#define _IO_OUTPUT_H

#include "gpio_dev.h"

#define DRY_CON_OPEN  1
#define DRY_CON_CLOSE 0

#define RELAY_OPEN  0
#define RELAY_CLOSE 1

#define SWITCH_ON  1
#define SWITCH_OFF 0

#define QUEUE_GPIO_OUTPUT_ID 0
struct io_out_ctl {
    uint8_t id;
    bool ctl;
};

typedef enum {
    HOLD_CTL_PIN,
    COLUMN_CTL_PIN,
    MAX_GPIO_OUTPUT_PIN,
} GPIO_OUTPUT_PIN;

// uint8_t input_pin[MAX_GPIO_INPUT_PIN] = {HAL_GPIO_130, HAL_GPIO_131, HAL_GPIO_122, HAL_GPIO_123,
//                                          HAL_GPIO_124};

// void drv_gpio_write(unsigned int id, unsigned int data);

/**
 * @brief init the gpio about DIG_OUT and set initation value
 * 
 * @return boot_t 
 */
int32_t output_gpio_init(void);

/**
 * @brief creat a task
 * 
 * @return boot_t 
 */
bool_t output_gpio_run(void);

/**
 * @brief not use
 * 
 * @return boot_t 
 */
bool_t output_gpio_clean(void);

#endif /* _IO_OUTPUT_H */
