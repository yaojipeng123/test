#include "types.h"
#include "stdio.h"
// #include "sm_module.h"

#include "os_queue.h"
#include "os_utils.h"
#include "os_task.h"

#include "hal_gpio.h"
#include "hal_timer.h"
#include "hal_pwm.h"

#include "io_output.h"
#include "gpio_dev.h"
#include "dev.h"
#include "iomap.h"

// #include "stm32f4xx_hal_tim.h"
#define TEST_GPIO_INPUT  HAL_GPIO_115   //(GPIOH, 3)
#define TEST_GPIO_OUTPUT HAL_GPIO_17    //(GPIOB, 1)
#define INT_ESC_PIN      HAL_GPIO_8
#define RUN_LED          HAL_GPIO_51
#define ON_OFF_PIN       HAL_GPIO_130
#define PWM_TIM_ID       0
#define PWM_TIM_ID1      1
#define OCMODE_PWM1      0
#define OCMODE_PWM2      1
#define OCPOLARITY_HIGH  0
#define OCPOLARITY_LOW   1
#define CHANNEL_1        1
#define CHANNEL_2        2
#define CHANNEL_3        3
#define CHANNEL_4        4

#define ESTOP_KEY_DOWN 1
#define ESTOP_KEY_UP   0
#define POWER_KEY_ON   1
#define POWER_KEY_OFF  0
#define ONOFF_KEY_DOWN 0
#define ONOFF_KEY_UP   1
#define IOMAP_CFG_MAX  32
extern iomap_iomap_cfg_t iomap_cfg[IOMAP_CFG_MAX];

os_queue_h gpio_output_h;
dev_t *output_gpio_dev;
bool estop_key_flag = false;
struct io_out_ctl all_output_gpio = {0xff, 0};   //初始化选中所有output gpio 初始化为0

gpio_config_t output_config[MAX_GPIO_OUTPUT_PIN] = {
    {HAL_GPIO_130, GPIO_IO_OUTPUT_PP, NULL, NULL, 0},
    {HAL_GPIO_131, GPIO_IO_OUTPUT_PP, NULL, NULL, 0},
};

void drv_gpio_write(unsigned int id, unsigned int data)
{
    output_config[id].data = data;
    dev_control(output_gpio_dev, IOC_GPIO_SET, (unsigned long)&output_config[id]);
}
int init_gpio_output_ctl()
{
    drv_gpio_write(HOLD_CTL_PIN, DRY_CON_CLOSE);
    drv_gpio_write(COLUMN_CTL_PIN, RELAY_CLOSE);
}

void gpio_output_task(void *arg)
{
    uint8_t mask = 0x01;
    bool out_ctl = 0;
    while (1) {
        os_queue_receive(gpio_output_h, &all_output_gpio);
        drv_gpio_write(all_output_gpio.id, all_output_gpio.ctl);
    }
}

bool_t output_gpio_run(void)
{
    uint8_t status_power = 0;

    int i;
    os_create_task_ext(gpio_output_task, NULL, 7, 128, "gpio_output_task");

    return true;
}

void output_gpio_iomap_get()
{
    output_config[HOLD_CTL_PIN].id =
        (iomap_cfg[GPIO_UPS_CTL].group << 4) + iomap_cfg[GPIO_UPS_CTL].gpio;
    output_config[COLUMN_CTL_PIN].id =
        (iomap_cfg[GPIO_LOOP1_CTL].group << 4) + iomap_cfg[GPIO_LOOP1_CTL].gpio;
}

int32_t output_gpio_init(void)
{
    // gpio_device_init();
    int32_t ret = ERR_OK;
    output_gpio_dev = dev_find("gpio");

    if (!output_gpio_dev) {
        return ERR_FAIL;
    }
    dev_init(output_gpio_dev);
    gpio_output_h = os_queue_create(QUEUE_GPIO_OUTPUT_ID, 8, sizeof(struct io_out_ctl));
    // output_gpio_iomap_get();
    init_gpio_output_ctl();   //所有外设io控制初始化

    return ret;
}

bool_t output_gpio_clean(void)
{
    return true;
}

