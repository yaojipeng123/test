#ifndef RUN_LED_H
#define RUN_LED_H

/**
 * @brief  init the gpio about run_led
 * 
 * @return bool_t 
 */
int32_t run_led_init(void);

/**
 * @brief  creat a task
 * 
 * @return bool_t
 */
bool_t run_led_run(void);



#endif /* RUN_LED_H */
