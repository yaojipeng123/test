#include "types.h"
#include "stdio.h"

#include "hal.h"
#include "hal_uart.h"

#include "os_utils.h"
#include "os_task.h"

#include "share_task.h"

#include "log.h"
#include "timer_dev.h"
#include "uart_dev.h"
#include "gpio_dev.h"

#include "led.h"
#include "ecat_task.h"

#include "key.h"
// #include "io_output.h"

dev_t *uart_test = NULL;
uint8_t test_buf[] = "hello";
void all_device_init()
{
    gpio_device_init();
    timer_device_init();
    uart_device_init();
    // spi_device_init();
}
int main(void)
{
    int32_t ret = ERR_OK;
    hal_bsp_init();
    hal_timer_init();
    // log_init();

    // share_task_init();
    all_device_init();
    ret = run_led_init();
    if (!ret) {
        run_led_run();
    }
    ret = ethercat_init();
    if (!ret) {
        ethercat_run();
    }
    // // // alarm_init();

    ret = key_gpio_init();
    if(!ret)
    {
        key_gpio_run();
    }
    // ret = output_gpio_init();
    // if(!ret)
    // {
    //     output_gpio_run();
    // }
    // uart_test = dev_find("uart1");
    // if (!uart_test) {
    //     ret = ERR_FAIL;
    // }
    // dev_open(uart_test);

    // dev_write(uart_test,test_buf,6);
    os_start_kernel();
    return 0;
}