/**
\addtogroup EL9800Appl EL9800 application
@{
*/

/**
\file el9800appl.c
\author EthercatSSC@beckhoff.com
\brief Implementation

\version 5.11

<br>Changes to version V5.10:<br>
V5.11 ECAT11: create application interface function pointer, add eeprom emulation interface functions<br>
V5.11 EL9800 1: reset outputs on fallback from OP state<br>
<br>Changes to version V5.01:<br>
V5.10 ECAT6: Add "USE_DEFAULT_MAIN" to enable or disable the main function<br>
<br>Changes to version V5.0:<br>
V5.01 EL9800 2: Add TxPdo Parameter object 0x1802<br>
<br>Changes to version V4.30:<br>
V4.50 ECAT2: Create generic application interface functions. Documentation in Application Note ET9300.<br>
V4.50 COE2: Handle invalid PDO assign values.<br>
V4.30 : create file
*/


/*-----------------------------------------------------------------------------------------
------
------    Includes
------
-----------------------------------------------------------------------------------------*/
#include <stdio.h>
#include "ecat_def.h"
/* ECATCHANGE_START(V5.11) ECAT11*/
#include "applInterface.h"
/* ECATCHANGE_END(V5.11) ECAT11*/

#include "el9800hw.h"
#include "ecatappl.h"
#define _EVALBOARD_
#include "el9800appl.h"
#undef _EVALBOARD_

#include "os_queue.h"
#include "os_timer.h"
#include "os_utils.h"
#include "sm.h"
#include "gpio_dev.h"
#include "dev.h"
#include "key.h"
#define ECAT_RESET_PIN HAL_GPIO_60

// extern key_stat_t key[3];
extern struct state_machine m;
extern dev_t *ecat_gpio_dev ;
/*--------------------------------------------------------------------------------------
------
------    local types and defines
------
--------------------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------------------
------
------    local variables and constants
------
-----------------------------------------------------------------------------------------*/
//extern gpio_io_config_t gconfig[TOTAL_GPIO_NUM];
//extern sst_device_t *gpio_handler;
//static sst_device_t *lan9252_reset_gpio_handler;
/*-----------------------------------------------------------------------------------------
------
------    application specific functions
------
-----------------------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------------------
------
------    generic functions
------
-----------------------------------------------------------------------------------------*/

/////////////////////////////////////////////////////////////////////////////////////////
/**
 \brief    The function is called when an error state was acknowledged by the master

*////////////////////////////////////////////////////////////////////////////////////////

void    APPL_AckErrorInd(UINT16 stateTrans)
{ 
}

/////////////////////////////////////////////////////////////////////////////////////////
/**
 \return    AL Status Code (see ecatslv.h ALSTATUSCODE_....)

 \brief    The function is called in the state transition from INIT to PREOP when
           all general settings were checked to start the mailbox handler. This function
           informs the application about the state transition, the application can refuse
           the state transition when returning an AL Status error code.
           The return code NOERROR_INWORK can be used, if the application cannot confirm
           the state transition immediately, in that case the application need to be complete 
           the transition by calling ECAT_StateChange.

*////////////////////////////////////////////////////////////////////////////////////////

UINT16 APPL_StartMailboxHandler(void)
{
    return ALSTATUSCODE_NOERROR;
}

/////////////////////////////////////////////////////////////////////////////////////////
/**
 \return     0, NOERROR_INWORK

 \brief    The function is called in the state transition from PREEOP to INIT
             to stop the mailbox handler. This functions informs the application
             about the state transition, the application cannot refuse
             the state transition.

*////////////////////////////////////////////////////////////////////////////////////////

UINT16 APPL_StopMailboxHandler(void)
{
    return ALSTATUSCODE_NOERROR;
}

/////////////////////////////////////////////////////////////////////////////////////////
/**
 \param    pIntMask    pointer to the AL Event Mask which will be written to the AL event Mask
                        register (0x204) when this function is succeeded. The event mask can be adapted
                        in this function
 \return    AL Status Code (see ecatslv.h ALSTATUSCODE_....)

 \brief    The function is called in the state transition from PREOP to SAFEOP when
             all general settings were checked to start the input handler. This function
             informs the application about the state transition, the application can refuse
             the state transition when returning an AL Status error code.
            The return code NOERROR_INWORK can be used, if the application cannot confirm
            the state transition immediately, in that case the application need to be complete 
            the transition by calling ECAT_StateChange.
*////////////////////////////////////////////////////////////////////////////////////////

UINT16 APPL_StartInputHandler(UINT16 *pIntMask)
{
    return ALSTATUSCODE_NOERROR;
}

/////////////////////////////////////////////////////////////////////////////////////////
/**
 \return     0, NOERROR_INWORK

 \brief    The function is called in the state transition from SAFEOP to PREEOP
             to stop the input handler. This functions informs the application
             about the state transition, the application cannot refuse
             the state transition.

*////////////////////////////////////////////////////////////////////////////////////////

UINT16 APPL_StopInputHandler(void)
{
    return ALSTATUSCODE_NOERROR;
}

/////////////////////////////////////////////////////////////////////////////////////////
/**
 \return    AL Status Code (see ecatslv.h ALSTATUSCODE_....)

 \brief    The function is called in the state transition from SAFEOP to OP when
             all general settings were checked to start the output handler. This function
             informs the application about the state transition, the application can refuse
             the state transition when returning an AL Status error code.
           The return code NOERROR_INWORK can be used, if the application cannot confirm
           the state transition immediately, in that case the application need to be complete 
           the transition by calling ECAT_StateChange.
*////////////////////////////////////////////////////////////////////////////////////////

UINT16 APPL_StartOutputHandler(void)
{
    return ALSTATUSCODE_NOERROR;
}

/////////////////////////////////////////////////////////////////////////////////////////
/**
 \return     0, NOERROR_INWORK

 \brief    The function is called in the state transition from OP to SAFEOP
             to stop the output handler. This functions informs the application
             about the state transition, the application cannot refuse
             the state transition.

*////////////////////////////////////////////////////////////////////////////////////////

UINT16 APPL_StopOutputHandler(void)
{
/*ECATCHANGE_START(V5.11) EL9800 1*/

/*ECATCHANGE_END(V5.11) EL9800 1*/
    return ALSTATUSCODE_NOERROR;
}

/////////////////////////////////////////////////////////////////////////////////////////
/**
\return     0(ALSTATUSCODE_NOERROR), NOERROR_INWORK
\param      pInputSize  pointer to save the input process data length
\param      pOutputSize  pointer to save the output process data length

\brief    This function calculates the process data sizes from the actual SM-PDO-Assign
            and PDO mapping
*////////////////////////////////////////////////////////////////////////////////////////
UINT16 APPL_GenerateMapping(UINT16* pInputSize,UINT16* pOutputSize)
{
    UINT16 result = ALSTATUSCODE_NOERROR;
    UINT16 PDOAssignEntryCnt = 0;
    OBJCONST TOBJECT OBJMEM * pPDO = NULL;
    UINT16 PDOSubindex0 = 0;
    UINT32 *pPDOEntry = NULL;
    UINT16 PDOEntryCnt = 0;
    UINT16 InputSize = 0;
    UINT16 OutputSize = 0;

    /*Scan object 0x1C12 RXPDO assign*/
    for(PDOAssignEntryCnt = 0; PDOAssignEntryCnt < sRxPDOassign.u16SubIndex0; PDOAssignEntryCnt++)
    {
        pPDO = OBJ_GetObjectHandle(sRxPDOassign.aEntries[PDOAssignEntryCnt]);
        if(pPDO != NULL)
        {
            PDOSubindex0 = *((UINT16 *)pPDO->pVarPtr);
            for(PDOEntryCnt = 0; PDOEntryCnt < PDOSubindex0; PDOEntryCnt++)
            {
                pPDOEntry = (UINT32 *)((UINT8 *)pPDO->pVarPtr + (OBJ_GetEntryOffset((PDOEntryCnt+1),pPDO)>>3));    //goto PDO entry
                // we increment the expected output size depending on the mapped Entry
                OutputSize += (UINT16) ((*pPDOEntry) & 0xFF);
            }
        }
        else
        {
            /*assigned PDO was not found in object dictionary. return invalid mapping*/
            OutputSize = 0;
            result = ALSTATUSCODE_INVALIDOUTPUTMAPPING;
            break;
        }
    }

    OutputSize = (OutputSize + 7) >> 3;

    if(result == 0)
    {
        /*Scan Object 0x1C13 TXPDO assign*/
        for(PDOAssignEntryCnt = 0; PDOAssignEntryCnt < sTxPDOassign.u16SubIndex0; PDOAssignEntryCnt++)
        {
            pPDO = OBJ_GetObjectHandle(sTxPDOassign.aEntries[PDOAssignEntryCnt]);
            if(pPDO != NULL)
            {
                PDOSubindex0 = *((UINT16 *)pPDO->pVarPtr);
                for(PDOEntryCnt = 0; PDOEntryCnt < PDOSubindex0; PDOEntryCnt++)
                {
                    pPDOEntry = (UINT32 *)((UINT8 *)pPDO->pVarPtr + (OBJ_GetEntryOffset((PDOEntryCnt+1),pPDO)>>3));    //goto PDO entry
                    // we increment the expected output size depending on the mapped Entry
                    InputSize += (UINT16) ((*pPDOEntry) & 0xFF);
                }
            }
            else
            {
                /*assigned PDO was not found in object dictionary. return invalid mapping*/
                InputSize = 0;
                result = ALSTATUSCODE_INVALIDINPUTMAPPING;
                break;
            }
        }
    }
    InputSize = (InputSize + 7) >> 3;

    *pInputSize = InputSize;
    *pOutputSize = OutputSize;
    return result;

}


/////////////////////////////////////////////////////////////////////////////////////////
/**
\param      pData  pointer to input process data
\brief      This function will copies the inputs from the local memory to the ESC memory
            to the hardware
*////////////////////////////////////////////////////////////////////////////////////////
void APPL_InputMapping(UINT16* pData)
{
    UINT16 j = 0;
    UINT16 *pTmpData = (UINT16 *)pData;
    
    /* we go through all entries of the TxPDO Assign object to get the assigned TxPDOs */
   for (j = 0; j < sTxPDOassign.u16SubIndex0; j++)
   {
        switch (sTxPDOassign.aEntries[j])
        {
      /* TxPDO 1 */
            case 0x1A00:
                *pTmpData++ = SWAPWORD(((UINT16 *) &sSafboard_IO_In)[1]);
            break;
      /* TxPDO 3 */
            case 0x1A02:
                *pTmpData++ = SWAPWORD(((UINT16 *) &sSigboard_IO_In)[1]);
                *pTmpData++ = SWAPWORD(((UINT16 *) &sSigboard_IO_In)[2]);
            break;
            case 0x1A03:
                *pTmpData++ = SWAPWORD(((UINT16 *) &sBoardTxPDO)[1]);
                *pTmpData++ = SWAPWORD(((UINT16 *) &sBoardTxPDO)[2]);
                *pTmpData++ = SWAPWORD(((UINT16 *) &sBoardTxPDO)[3]);
            break;
      }
   }
}

/////////////////////////////////////////////////////////////////////////////////////////
/**
\param      pData  pointer to output process data

\brief    This function will copies the outputs from the ESC memory to the local memory
            to the hardware
*////////////////////////////////////////////////////////////////////////////////////////
void APPL_OutputMapping(UINT16* pData)
{
    UINT16 j = 0;
    UINT16 *pTmpData = (UINT16 *)pData;

    /* we go through all entries of the RxPDO Assign object to get the assigned RxPDOs */
    for (j = 0; j < sRxPDOassign.u16SubIndex0; j++)
    {
        switch (sRxPDOassign.aEntries[j])
        {
        /* RxPDO 2 */
        case 0x1601:
            ((UINT16 *) &sSafboard_IO_Out)[1] = SWAPWORD(*pTmpData++);
            break;
        case 0x1602:
            ((UINT16 *) &sBoardRxPDO)[1] = SWAPWORD(*pTmpData++);
            ((UINT16 *) &sBoardRxPDO)[2] = SWAPWORD(*pTmpData++);
            ((UINT16 *) &sBoardRxPDO)[3] = SWAPWORD(*pTmpData++);
            break;
        }
    }
}

bool now_estop_flag = false;
bool now_err_clr_flag = false;
bool now_shutdown_flag = false;
bool old_estop_flag = false;
bool old_err_clr_flag = false;
bool old_shutdown_flag = false;
// unsigned short count_heart;
unsigned short status_step;
extern key_stat_t key[8];
// extern os_queue_h state_input_h;

//extern uint8_t drycon_id[GPIO_SAF_OUT_MAX];//暂时屏蔽，之后要用
// extern uint8_t safe_dry_con_flag;
extern bool ecat_app_enter_type ;
/////////////////////////////////////////////////////////////////////////////////////////
/**
\brief    This function will called from the synchronisation ISR 
            or from the mainloop if no synchronisation is supported
*////////////////////////////////////////////////////////////////////////////////////////
void APPL_Application(void)
{
    static uint8_t num = 0;
    struct event e_post_from_ecat;
    // count_heart = sBoardRxPDO.tbd5;
    now_estop_flag = sBoardRxPDO.estop_req_from_ecat;
    now_err_clr_flag = sBoardRxPDO.board_err_clr;
    now_shutdown_flag = sBoardRxPDO.power_off_req_from_ecat;
    status_step = sBoardRxPDO.ecat_status;
    // sSafboard_IO_In.bSwitch4 = 1;
    // sSafboard_IO_In.bSwitch3 = 0;
    //rgb_color_set(status_step);
    if(key[FORWARD_KEY].key_logic == KEY_LOGIC_PUSHDOWN)
    {
        sSafboard_IO_In.bSwitch1 = 1;
    }else if(key[FORWARD_KEY].key_logic == KEY_LOGIC_PUSHUP)
    {
        sSafboard_IO_In.bSwitch1 = 0;
    }

    if(key[BACKWARD_KEY].key_logic == KEY_LOGIC_PUSHDOWN)
    {
        sSafboard_IO_In.bSwitch2 = 1;
    }else if(key[BACKWARD_KEY].key_logic == KEY_LOGIC_PUSHUP)
    {
        sSafboard_IO_In.bSwitch2 = 0;
    }
    if(key[SUSPEND_P].key_logic == KEY_LOGIC_PUSHDOWN)
    {
        sSafboard_IO_In.bSwitch3 = 1;
    }else if(key[SUSPEND_P].key_logic == KEY_LOGIC_PUSHUP)
    {
        sSafboard_IO_In.bSwitch3 = 0;
    }
    if(key[SUSPEND_N].key_logic == KEY_LOGIC_PUSHDOWN)
    {
        sSafboard_IO_In.bSwitch4 = 1;
    }else if(key[SUSPEND_N].key_logic == KEY_LOGIC_PUSHUP)
    {
        sSafboard_IO_In.bSwitch4 = 0;
    }
    if(key[PITCH_UP_KEY].key_logic == KEY_LOGIC_PUSHDOWN)
    {
        sSafboard_IO_In.bSwitch5 = 1;
    }else if(key[PITCH_UP_KEY].key_logic == KEY_LOGIC_PUSHUP)
    {
        sSafboard_IO_In.bSwitch5 = 0;
    }
    if(key[PITCH_DOWN_KEY].key_logic == KEY_LOGIC_PUSHDOWN)
    {
        sSafboard_IO_In.bSwitch6 = 1;
    }else if(key[PITCH_DOWN_KEY].key_logic == KEY_LOGIC_PUSHUP)
    {
        sSafboard_IO_In.bSwitch6 = 0;
    }
    if(key[FORWARD_LIMIT_KEY].key_logic == KEY_LOGIC_PUSHDOWN)
    {
        sSafboard_IO_In.bSwitch7 = 1;
    }else if(key[FORWARD_LIMIT_KEY].key_logic == KEY_LOGIC_PUSHUP)
    {
        sSafboard_IO_In.bSwitch7 = 0;
    }
    if(key[BACKWARD_LIMIT_KEY].key_logic == KEY_LOGIC_PUSHDOWN)
    {
        sSafboard_IO_In.bSwitch8 = 1;
    }else if(key[BACKWARD_LIMIT_KEY].key_logic == KEY_LOGIC_PUSHUP)
    {
        sSafboard_IO_In.bSwitch8 = 0;
    }

    if(bEcatOutputUpdateRunning)
    {//OP状态下
        if(now_estop_flag != old_estop_flag)
        {
            old_estop_flag = now_estop_flag;
            if(now_estop_flag)
            {
                e_post_from_ecat.type = EVENT_ESTOP_IN;
                e_post_from_ecat.data = 4;
                // os_queue_send_from_isr(state_input_h,&e_post_from_ecat);
                printf("----enter estop----\n");
                //进入estop
            }else{
                printf("----ecat clean estop----\n");
                //退出estop
            }
        }

        if(now_err_clr_flag != old_err_clr_flag)
        {
            old_err_clr_flag = now_err_clr_flag;
            if(now_err_clr_flag&&!now_estop_flag)
            {
                e_post_from_ecat.type = EVENT_ESTOP_OUT;
                e_post_from_ecat.data = 4;
                // os_queue_send_from_isr(state_input_h,&e_post_from_ecat);
                printf("----clean error----\n");
            }else{
                
            }
        }
        
        if(now_shutdown_flag != old_shutdown_flag)
        {
            old_shutdown_flag = now_shutdown_flag;
            if(now_shutdown_flag)
            {
                e_post_from_ecat.type = EVENT_NET_POWER_OFF;
                e_post_from_ecat.data = 2;
                // os_queue_send_from_isr(state_input_h,&e_post_from_ecat);
                printf("----enter shutdown----\n");
                //进入shutdown
            }else{
                printf("----ecat clean shutdown flag----\n");
                //退出shutdown
            }
        }
    }
    

    /* start the conversion of the A/D converter */

//AD1CON1bits.SAMP = 0; // start Converting
//while (!AD1CON1bits.DONE);// conversion done?
//sSigboard_IO_In.i16Analoginput = ADC1BUF0; // yes then get ADC value
	
		// sSigboard_IO_In.i16Analoginput = 0;
    /* we toggle the TxPDO Toggle after updating the data of the corresponding TxPDO */
    // sSigboard_IO_In.bTxPDOToggle ^= 1;

    /* we simulate a problem of the analog input, if the Switch4 is on in this example,
       in this case the TxPDO State has to set to indicate the problem to the master */
    // if ( sSafboard_IO_In.bSwitch4 )
    //     sSigboard_IO_In.bTxPDOState = 1;
    // else
    //     sSigboard_IO_In.bTxPDOState = 0;
}

/////////////////////////////////////////////////////////////////////////////////////////
/**
 \param     index               index of the requested object.
 \param     subindex            subindex of the requested object.
 \param     objSize             size of the requested object data, calculated with OBJ_GetObjectLength
 \param     pData               Pointer to the buffer where the data can be copied to
 \param     bCompleteAccess     Indicates if a complete read of all subindices of the
                                object shall be done or not

 \return    ABORTIDX_XXX

 \brief     Handles SDO read requests to TxPDO Parameter
*////////////////////////////////////////////////////////////////////////////////////////
UINT8 ReadObject0x1802( UINT16 index, UINT8 subindex, UINT32 dataSize, UINT16 MBXMEM * pData, UINT8 bCompleteAccess )
{

    if(bCompleteAccess)
        return ABORTIDX_UNSUPPORTED_ACCESS;

    if(subindex == 0)
    {
        *pData = TxPDO1802Subindex0;
    }
    else if(subindex == 6)
    {
        /*clear destination buffer (no excluded TxPDO set)*/
        if(dataSize > 0)
            MBXMEMSET(pData,0x00,dataSize);
    }
    else if(subindex == 7)
    {
        /*min size is one Byte*/
        UINT8 *pu8Data = (UINT8*)pData;
        
        //Reset Buffer
        *pu8Data = 0; 

        // *pu8Data = sSigboard_IO_In.bTxPDOState;
    }
    else if(subindex == 9)
    {
        /*min size is one Byte*/
        UINT8 *pu8Data = (UINT8*)pData;
        
        //Reset Buffer
        *pu8Data = 0; 

        // *pu8Data = sSigboard_IO_In.bTxPDOToggle;
    }
    else
        return ABORTIDX_SUBINDEX_NOT_EXISTING;

    return 0;
}

void reset_9252_chip()
{
    gpio_config_t ecat_reset={ECAT_RESET_PIN,GPIO_IO_OUTPUT_PP,NULL,NULL,1};
    dev_control(ecat_gpio_dev,IOC_GPIO_SET,(unsigned long)&ecat_reset);
    os_delay(100);
    ecat_reset.data = 0;
    dev_control(ecat_gpio_dev,IOC_GPIO_SET,(unsigned long)&ecat_reset);
    os_delay(100);
    ecat_reset.data = 1;
    dev_control(ecat_gpio_dev,IOC_GPIO_SET,(unsigned long)&ecat_reset);
//     ecat_reset.data = 1;
//     gpio_device_ctl(ECAT_RESET_PIN,IOC_GPIO_SET,&ecat_reset);
//     os_delay(100);
//     ecat_reset.data = 0;
//     gpio_device_ctl(ECAT_RESET_PIN,IOC_GPIO_SET,&ecat_reset);
//     os_delay(100);
//     ecat_reset.data = 1;
//     gpio_device_ctl(ECAT_RESET_PIN,IOC_GPIO_SET,&ecat_reset);
}
/////////////////////////////////////////////////////////////////////////////////////////
/**

 \brief    This is the main function

*////////////////////////////////////////////////////////////////////////////////////////
static timer_id_t check_op;
struct state * now_sm_state;

void ethcat_task(void *arg)
{    
    struct event e_post;   
    reset_9252_chip();
    HW_Init();
    MainInit();
    bRunApplication = TRUE;
    do
    {
        MainLoop();
        os_delay(10);
    } while (bRunApplication == TRUE);

    HW_Release();
}

/** @} */
