#include "types.h"
#include "stdio.h"

#include "hal_gpio.h"
#include "gpio_dev.h"
#include "dev.h"
#include "led.h"
#include "os_utils.h"
#include "os_task.h"
#include "log.h"
#define RUN_LED HAL_GPIO_51
#define STEP_PIN HAL_GPIO_132
#define LED0    HAL_GPIO_16 
#define PC_6    HAL_GPIO_38

dev_t *led_gpio_dev = NULL;
void run_led_task(void *arg)
{
    gpio_config_t test = {RUN_LED, GPIO_IO_OUTPUT_PP,NULL,NULL, 0};

    while (1) {
        test.data = ~test.data;
        dev_control(led_gpio_dev, IOC_GPIO_SET, (unsigned long)&test);
        // LOG_INFO(1, "fmt, arg...\n");
        os_delay(1);   //闪烁间隔为1s的程序运行指示灯
    }
}
static int32_t test_timer_cb(void *data)
{
    return ERR_OK;
}

int32_t run_led_init(void)
{
    int32_t ret = ERR_OK;
    led_gpio_dev = dev_find("gpio");
    if (!led_gpio_dev) {
        return ERR_FAIL;
    }
    ret = dev_init(led_gpio_dev);

    return ret;
}

bool_t run_led_run(void)
{
    os_create_task_ext(run_led_task, NULL, 7, 1024, "run_led_task");
    return true;
}

bool_t run_led_clean(void)
{
    return true;
}

// RUN_MODULE(run_led, run_led_init, run_led_run, run_led_clean, 1);