#ifndef RUN_LED_H
#define RUN_LED_H

int32_t run_led_init(void);
bool_t run_led_run(void);
bool_t run_led_clean(void);

#endif /* RUN_LED_H */
