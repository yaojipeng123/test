#ifndef _KEY_H
#define _KEY_H

#define KEY_LOGIC_INIT              0
#define KEY_LOGIC_PUSHDOWN          1
#define KEY_LOGIC_PUSHUP            2

/*woring 需要报警   error 需要急停*/
#define ABNORMAL_NONE   0x00
#define ABNORMAL_WORING 0x01
#define ABNORMAL_ERROR  0x02

/*目前最多八种woring 一个bit对应一种woring*/
#define UPMOVE_KEY_WORING    0x01
#define DOWNMOVE_KEY_WORING    0x02

/*目前最多八种error 一个bit对应一种error*/
#define ESTOP_KEY_ERROR     0x01

enum key_id{
    FORWARD_KEY,        //伸缩向前按钮
    BACKWARD_KEY,       //伸缩向后按钮
    SUSPEND_P,          //悬吊正转
    SUSPEND_N,          //悬吊反转
    PITCH_UP_KEY,       //俯仰向上
    PITCH_DOWN_KEY,     //俯仰向下
    FORWARD_LIMIT_KEY,  //伸缩向前限位
    BACKWARD_LIMIT_KEY, //伸缩向后限位
    KEY_ID_MAX,
};

typedef struct
{
 	uint8_t key_logic;
	uint8_t key_physic;
 	uint8_t keyon_counts;
 	uint8_t keyoff_counts;
}key_stat_t;
bool_t key_gpio_run(void);
int32_t key_gpio_init(void);


#endif