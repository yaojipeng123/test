#ifndef RUN_LED_H
#define RUN_LED_H

/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t run_led_init(void);

/**
 * @brief 
 * 
 * @return bool_t 
 */
bool_t run_led_run(void);

/**
 * @brief 
 * 
 * @return bool_t 
 */
bool_t run_led_clean(void);

#endif /* RUN_LED_H */
