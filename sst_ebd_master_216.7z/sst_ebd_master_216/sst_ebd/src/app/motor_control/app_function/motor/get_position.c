#include "types.h"
#include "stdio.h"

#include "hal_gpio.h"
#include "gpio_dev.h"
#include "dev.h"

#include "os_utils.h"
#include "os_task.h"
#include "os_queue.h"

#include "kingkong_encode.h"
#include "get_position.h"


#define RCV_BUF_LEN     6
#define ENCODE_ADDR     0x05
#define RS485_RE_PIN    HAL_GPIO_7
uint8_t encode_rcv_buf[128] = {0};
int32_t get_position_init()
{
    int32_t ret = ERR_OK;
    ret = kingkong_485_init("uart2",RS485_RE_PIN);
    return ret;
}

uint32_t get_position_value()
{
    uint32_t encode_val = 0;
    int32_t ret = ERR_OK;
    kingkong_get_info(encode_rcv_buf,ENCODE_ADDR,RS485_RE_PIN);
    ret =  kingkong_value_check(encode_rcv_buf,RCV_BUF_LEN);
    if(ret)
    {
        encode_val = encode_rcv_buf[2]+(encode_rcv_buf[3]<<8)+(encode_rcv_buf[4]<<16);
    }
    return encode_val;
}

void get_moto_position(moto_measure_t *ptr)
{
	ptr->last_position = ptr->position;
	ptr->position = get_position_value();
	
	if(ptr->position - ptr->last_position > 65536)
		ptr->round_cnt --;
	else if (ptr->position - ptr->last_position < -65536)
		ptr->round_cnt ++;
	ptr->total_position = ptr->round_cnt * 131072 + ptr->position ;
}