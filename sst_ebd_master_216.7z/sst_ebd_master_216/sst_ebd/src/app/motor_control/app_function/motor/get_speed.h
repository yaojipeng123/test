#ifndef GET_SPEED_H
#define GET_SPEED_H



/**
 * @brief Get the speed init object
 * 
 * @return int32_t 
 */
int32_t get_speed_init();

/**
 * @brief Get the speed value object
 * 
 * @return int16_t 
 */
int16_t get_speed_value();

#endif // !GET_SPEED_H