#ifndef GET_POSITION_H
#define GET_POSITION_H

typedef struct{
	uint32_t 	position;				
	uint32_t 	last_position;	
	int32_t		round_cnt;
	int32_t		total_position;//位置
}moto_measure_t;

/**
 * @brief Get the position init object
 * 
 * @return int32_t 
 */
int32_t get_position_init();

/**
 * @brief Get the position value object
 * 
 * @return uint32_t 
 */
uint32_t get_position_value();

/**
 * @brief Get the moto position object
 * 
 * @param ptr 
 */
void get_moto_position(moto_measure_t *ptr);

#endif // !GET_POSITION_H