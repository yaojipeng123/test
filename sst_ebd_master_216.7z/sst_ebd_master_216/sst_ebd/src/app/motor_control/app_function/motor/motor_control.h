#ifndef MOTOR_H
#define MOTOR_H

#include "hal_gpio.h"

#define PWM_MODE_1      0
#define PWM_MODE_2      1
#define PWM_INIT_PULSE  100
#define OCPOLARITY_H    0
#define OCPOLARITY_L    1
#define PWM_CHANNEL_1   1
#define PWM_CHANNEL_2   2   
#define PWM_CHANNEL_3   3
#define PWM_CHANNEL_4   4
#define DRV8874_ENABLE  1
#define DRV8874_DISABLE 0
#define DRV8874_SLEEP   0
#define DRV8874_ENBALE_PIN  HAL_GPIO_40
#define DRV8874_FAULT_PIN   HAL_GPIO_41
#define DRV8874_ADC_CHANNEL 11
#define SPEED_LOOP  1
#define POSITION_LOOP  2
#define CURRENT_LOOP  3

#define CMD_SET_ENABLE      1
#define CMD_SET_DIRECTION   2
#define CMD_SET_SPEED       3
#define CMD_SET_LOCATION    4

#define QUEUE_MOTOR_ID      0
struct motor_config{
    uint8_t cmd;
    bool_t enable_set;
    bool_t direction_set;
    uint16_t speed_set;
    uint16_t location_set;
};
/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t motor_control_init();

/**
 * @brief 
 * 
 * @return bool_t 
 */
int32_t motor_control_run();


#endif /* MOTOR_H */
