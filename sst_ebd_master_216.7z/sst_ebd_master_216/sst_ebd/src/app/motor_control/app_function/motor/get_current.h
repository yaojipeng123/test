#ifndef GET_CURRENT_H
#define GET_CURRENT_H



/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t adc_current_init();

/**
 * @brief Get the adc current value object
 * 
 * @param channel 
 * @param value 
 * @return float 
 */
float get_adc_current_value(uint32_t channel, uint32_t *value);

#endif // !GET_CURRENT_H