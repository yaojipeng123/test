#include "types.h"
#include "stdio.h"

#include "hal_gpio.h"
#include "gpio_dev.h"
#include "dev.h"
#include "motor_control.h"
#include "os_utils.h"
#include "os_task.h"
#include "os_queue.h"
#include "log.h"
#include "dc_brush_motor_control.h"
#include "pwm_dev.h"
#include "get_position.h"
#include "get_current.h"
#include "get_speed.h"
#include "key.h"
#include "pid.h"

uint32_t drv8874_adc_value = 0;
pwm_set_config_t pwm1_config={PWM_MODE_1,PWM_INIT_PULSE,OCPOLARITY_H,PWM_CHANNEL_1};
pwm_set_config_t pwm2_config={PWM_MODE_1,PWM_INIT_PULSE,OCPOLARITY_L,PWM_CHANNEL_2};
moto_measure_t moto_position = {0};
uint16_t target_speed = 1000;
uint16_t target_position = 1000; 
uint16_t motor_speed = 0;
uint8_t loop_type = 0;
bool_t motor_started = 0;
extern key_stat_t key[8];
extern pid_config_t pid_location;//位置环所用pid参数
extern pid_config_t pid_speed;//速度环所用pid参数
os_queue_h motor_queue;
void run_motor_ctl(void *arg)//单环控制
{
    uint32_t cont_val = 0;
    
    while(1)
    {
        
        if(loop_type == SPEED_LOOP)//速度环
        {  
            motor_speed = get_speed_value();//获取速度
            cont_val = pid_realize(motor_speed);//进行PID计算
        }else if(loop_type == POSITION_LOOP)//位置环
        {
            get_moto_position(&moto_position);//获取位置信息
            cont_val = pid_realize(moto_position.total_position);//进行PID计算
        }

        if(motor_started)
        {
            dc_brush_motor_set_speed(cont_val); 
        }

        // dc_brush_get_adc_value(DRV8874_ADC_CHANNEL,&drv8874_adc_value);//读取电流值
        
        // cont_val = pid_realize(drv8874_adc_value);//进行PID计算
        // dc_brush_motor_set_speed(cont_val); //速度设定
        if(key[START_KEY].key_logic == KEY_LOGIC_PUSHDOWN)
        {
            motor_started = 1;
            dc_brush_motor_enable(DRV8874_ENBALE_PIN,DRV8874_ENABLE);//使能电机
        }
        if(key[STOP_KEY].key_logic == KEY_LOGIC_PUSHDOWN)
        {
            motor_started = 0;
            dc_brush_motor_enable(DRV8874_ENBALE_PIN,DRV8874_DISABLE);//失能电机
        }
        if(key[ACCELERATE_KEY].key_logic == KEY_LOGIC_PUSHDOWN)//加速
        {
            loop_type = SPEED_LOOP;
            target_speed = target_speed+100;
            set_pid_target(target_speed);//设定目标速度
        }
        if(key[SLOWDOWN_KEY].key_logic == KEY_LOGIC_PUSHDOWN)//减速
        {
            loop_type = SPEED_LOOP;
            target_speed = target_speed+100;
            set_pid_target(target_speed);//设定目标速度
            
        }
        if(key[FORWORD_KEY].key_logic == KEY_LOGIC_PUSHDOWN)//正转
        {
            dc_brush_motor_set_direction(MOTOR_FWD);
        }
        if(key[REVERSAL_KEY].key_logic == KEY_LOGIC_PUSHDOWN)//正转
        {
            dc_brush_motor_set_direction(MOTOR_REV);
        }
        if(key[LOCATION_UP_KEY].key_logic == KEY_LOGIC_PUSHDOWN)//位置+
        {
            loop_type = POSITION_LOOP;
            target_position = target_position+100;
            set_pid_target(target_position);//设定目标位置
        }
        if(key[LOCATION_DOWN_KEY].key_logic == KEY_LOGIC_PUSHDOWN)//位置-
        {
            loop_type = POSITION_LOOP;
            target_position = target_position+100;
            set_pid_target(target_position);//设定目标位置
            
        }
    os_delay(1);
    }
    
}
void run_motor_location_speed_ctl(void *arg)//位置 速度环双环控制
{
    static uint32_t location_timer = 0; //位置环周期控制
    float cont_val = 0; //控制量
    while(1)
    {
        if (location_timer++%2 == 0)
        {
            get_moto_position(&moto_position);
            cont_val = location_pid_realize(moto_position.total_position);//进行位置环pid计算
            set_pid_target_plus(&pid_speed,cont_val);//所得结果值给速度环目标值
        }
        motor_speed = get_speed_value();//获取速度
        cont_val = speed_pid_realize(motor_speed);//进行速度环pid计算
        if (cont_val > 0)    // 正转
        {
            dc_brush_motor_set_direction(MOTOR_FWD);
        }
        else                //反转
        {
            cont_val = -cont_val;
            dc_brush_motor_set_direction(MOTOR_REV);
        }
        dc_brush_motor_set_speed(cont_val);
        os_delay(1);
    }
}

void motor_info_config(void *arg)
{
    struct motor_config e_motor_rcv;
    while(1)
    {
        os_queue_receive(motor_queue, &e_motor_rcv);
        switch(e_motor_rcv.cmd)
        {
            case CMD_SET_ENABLE:
                motor_started = e_motor_rcv.enable_set;
                dc_brush_motor_enable(DRV8874_ENBALE_PIN,motor_started);
            break;
            case CMD_SET_DIRECTION:
                dc_brush_motor_set_direction(e_motor_rcv.direction_set);
            break;
            case CMD_SET_SPEED:
                loop_type = SPEED_LOOP;
                set_pid_target(e_motor_rcv.speed_set);//设定目标速度
            break;
            case CMD_SET_LOCATION:
                loop_type = POSITION_LOOP;
                set_pid_target(e_motor_rcv.location_set);//设定目标位置
            break;
            default:
            break;

        }
    }
}
int32_t motor_control_init()
{   int32_t ret = ERR_OK;
    bool_t fault = 0;
    dc_brush_pid_init();//PID值初始化
    ret = dc_brush_motor_gpio_init();
    if(!ret)
    {
        return ERR_FAIL;
    }
    dc_brush_motor_pwm_init("pwm1",(unsigned long)&pwm1_config);//初始化DRV8874的PWM_H
    dc_brush_motor_pwm_init("pwm1",(unsigned long)&pwm2_config);//初始化DRV8874的PWM_L
    dc_brush_motor_enable(DRV8874_ENBALE_PIN,DRV8874_SLEEP);//初始化8874为睡眠状态 DRV8874的nSLEEP
    fault = dc_brush_motor_get_fault(DRV8874_FAULT_PIN);//读取DRV8874的FAULT标志位，从而获取错误
    if(!fault)
    {
        return ERR_FAIL;
    }
    ret = adc_current_init();
    if(!ret)
    {
        return ERR_FAIL;
    }
    ret = get_speed_init();
    if(!ret)
    {
        return ERR_FAIL;
    }
    motor_queue = os_creat_queue(QUEUE_MOTOR_ID, 8, sizeof(struct motor_config));
    return ret;
}

int32_t motor_control_run()
{
    os_create_task_ext(run_motor_ctl, NULL, 7, 1024, "run_motor_ctl");
    os_create_task_ext(motor_info_config,NULL,7,1024,"motor_info_config");
    return ERR_OK;
}