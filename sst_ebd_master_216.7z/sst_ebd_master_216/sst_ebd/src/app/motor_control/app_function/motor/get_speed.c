#include "types.h"
#include "stdio.h"

#include "hal_gpio.h"
#include "gpio_dev.h"
#include "dev.h"

#include "os_utils.h"
#include "os_task.h"
#include "os_queue.h"

#include "tim_encode.h"


int32_t get_speed_init()
{
    int32_t ret = ERR_OK;
    ret = tim_encode_init("timer1");
    return ret;
}

int16_t get_speed_value()
{
    int16_t motor_speed;
    motor_speed = get_speed_from_encode();//根据编码器得出转速
    return motor_speed;
}
