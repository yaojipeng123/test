#include "types.h"
#include "stdio.h"

#include "hal_gpio.h"
#include "gpio_dev.h"
#include "dev.h"
#include "os_utils.h"
#include "os_task.h"
#include "log.h"
#include "dc_brush_motor_control.h"
#include "pwm_dev.h"
#include "adc_dev.h"
//电流环 电流反馈
dev_t *adc_dev;
int32_t adc_current_init()
{
    int32_t ret = ERR_OK;
    ret = dev_init(adc_dev);
    if(!ret)
    {
        return ERR_FAIL;
    }
    ret = dev_control(adc_dev,IOC_ADC_CONTROL,IO_ADC_START);
    if(!ret)
    {
        return ERR_FAIL;
    }
}

float get_adc_current_value(uint32_t channel, uint32_t *value)//DRV8874使用PC1 channel_11,获取电流值，用于电流环PID
{
    adc_config_t adc_config;
    adc_config.channel = channel;
    float current_val;
    adc_config.value = *value;
    dev_control(adc_dev,IOC_ADC_GET_VALUE,(unsigned long)&adc_config);
    current_val = (float)(*adc_config.value)*3.3/4096;//算出电压值
    current_val = (float)(*adc_config.value)/1000;//电压/电阻 算出电流值
    return current_val;

}