#include "types.h"
#include "stdio.h"

#include "dev.h"
#include "os_utils.h"
#include "os_task.h"
#include "os_queue.h"
#include "log.h"
#include "actuator_ctl.h"
#include "mic_linear_actuator.h"
//注册各个id的电机
static int32_t actuator_info_register(actuator_info_t *info);
static actuator_info_t *actuator_find_id(uint8_t id);
static int32_t actuator_set_target_location(uint8_t id,uint16_t location_val);
static int32_t update_actuator_config(uint8_t *buf);
#define MAX_ACTUATOR_NUM    4
#define MAX_BUF_LEN     1024
#define ACTUATOR_ID_1   1
#define ACTUATOR_ID_2   2
#define ACTUATOR_ID_3   3
#define ACTUATOR_ID_4   4

#define INIT_TARGET_LOCATION    0
#define INIT_CURRENT_LOCATION    0
#define TEMPERATURE    0
#define ERROR_VAL    0

os_queue_h location_queue;
actuator_info_t *info_list = NULL;
actuator_info_t actuator_config[MAX_ACTUATOR_NUM] = {
    {ACTUATOR_ID_1,INIT_TARGET_LOCATION,INIT_CURRENT_LOCATION,TEMPERATURE,ERROR_VAL},
    {ACTUATOR_ID_2,INIT_TARGET_LOCATION,INIT_CURRENT_LOCATION,TEMPERATURE,ERROR_VAL},
    {ACTUATOR_ID_3,INIT_TARGET_LOCATION,INIT_CURRENT_LOCATION,TEMPERATURE,ERROR_VAL},
    {ACTUATOR_ID_4,INIT_TARGET_LOCATION,INIT_CURRENT_LOCATION,TEMPERATURE,ERROR_VAL}
};
uint8_t rcv_buf[MAX_BUF_LEN] = {0};
int32_t actuator_ctl_init()
{
    mic_linear_init("usart2");
    for(int i=0;i<MAX_ACTUATOR_NUM;i++)
    {
        actuator_info_register(&actuator_config[i]);//注册信息
        mic_linear_work(actuator_config[i].id);//启动电机
    }
    uart_start_read_buf(rcv_buf);//打开串口接收
    location_queue = os_queue_create(QUEUE_LOCATION_ID, 8, sizeof(struct set_location_cf));
    if(!location_queue)
    {
        return ERR_FAIL;
    }
    return ERR_OK;
    
}

void location_hold_task(void *arg)
{
    while(1)
    {
        update_actuator_config(rcv_buf);//更新actuator_config数组中信息
        for(int i=0;i<MAX_ACTUATOR_NUM;i++)
        {
            if(actuator_config[i].target_location != actuator_config[i].current_location)
            {
                actuator_set_target_location(actuator_config[i].id,actuator_config->target_location);//设置电机对应目标位置
            }
        }
        os_delay(10);
    }

}

void change_location_task(void *arg)
{
    struct set_location_cf e_location;
    while(1)
    {
        os_queue_receive(location_queue, &e_location);
        change_target_location(e_location.id,e_location.location_val);
    }
}

int32_t actuator_ctl_run()
{
    //
    os_create_task_ext(location_hold_task, NULL, 7, 1024, "location_hold_task");
    os_create_task_ext(change_location_task,NULL,7,1024,"change_location_task");
    return ERR_OK;
}

int32_t change_target_location(uint8_t id,uint16_t target_location)//改变目标位置 对外接口
{
    actuator_info_t *actuator_id;
    actuator_id = actuator_find_id(id);
    if(!actuator_id)
    {
        return ERR_FAIL;
    }
    actuator_id->target_location = target_location;
    return ERR_OK;
}


static int32_t update_actuator_config(uint8_t *buf)
{
    int16_t move = -1;
    uint8_t bcc_val = 0;
    uint8_t id = 0;
    actuator_info_t *actuator_id;
    for(int i=0;i<MAX_BUF_LEN;i++)
    {
        if((buf[i] == 0xAA)&&(buf[i+1] == 0x55))//返回的数据是以0xAA 0x55 开头
        { 
            move = i;
            break;
        }
    }
    if(move == -1)
    {
        return ERR_FAIL;
    }
    for(int i=0;i<19;i++)
    {
        bcc_val = bcc_val+buf[move+2+i];//求和算出bcc
    }
    if(bcc_val != buf[move+21])//算出的bcc与数据中的bcc值对比
    {
        return ERR_FAIL;
    }
    id = buf[move+3];//取出ID值
    actuator_id = actuator_find_id(id);
    if(!actuator_id)
    {
        return ERR_FAIL;
    }
    actuator_id->current_location = (buf[move+10]<<8)||buf[move+9];//更新当前位置
    actuator_id->temperature = buf[move+11];//更新温度信息
    actuator_id->error = buf[move+15];//更新error信息
    return ERR_OK;
}

int32_t actuator_change_id(uint8_t old_id,uint8_t new_id)//改变ID
{
    actuator_info_t *actuator_id;
    actuator_id = actuator_find_id(old_id);
    if(!actuator_id)
    {
        return ERR_FAIL;
    }
    mic_linear_set_id(old_id,new_id);
    actuator_id->id = new_id;
    return ERR_OK;
}


static int32_t actuator_set_target_location(uint8_t id,uint16_t location_val)//控制电机动作到目标位置
{
    actuator_info_t *actuator_id;
    actuator_id = actuator_find_id(id);
    if(!actuator_id)
    {
        return ERR_FAIL;
    }
    mic_linear_write_location(id,location_val);
}
static actuator_info_t *actuator_find_id(uint8_t id)
{
    actuator_info_t *cur = info_list;
    while(cur!=NULL)
    {
        if(cur->id == id)
        {
            return cur;
        }
        cur = cur->next;
    }
    return NULL;
}
static int32_t actuator_info_register(actuator_info_t *info)//将不同ID电机的信息注册进列表中
{
    actuator_info_t *cur = info_list;

    if (NULL == info_list) {
        info_list = info;
        info->next = NULL;
    } else {
        while (NULL != cur->next) {
            cur = cur->next;
        }
        cur->next = info;
        info->next = NULL;
    }

    return ERR_OK;
}