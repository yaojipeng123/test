#ifndef ACTUATOR_CTL_H
#define ACTUATOR_CTL_H


#define QUEUE_LOCATION_ID 0


struct set_location_cf
{
   uint8_t id;
   uint16_t location_val;
};

typedef struct actuator_info {
    uint8_t id;
    uint16_t target_location;
    uint16_t current_location;
    uint16_t temperature;
    uint8_t error;
    struct actuator_info *next;
}actuator_info_t;

/**
 * @brief set target location value
 * 
 * @param id 
 * @param target_location 
 * @return int32_t 
 */
int32_t change_target_location(uint8_t id,uint16_t target_location);

/**
 * @brief creat a task to control actuator
 * 
 * @return int32_t 
 */
int32_t actuator_ctl_run();

#endif // !ACTUATOR_CTL_H



