#ifndef _KEY_H
#define _KEY_H

#define KEY_LOGIC_INIT              0
#define KEY_LOGIC_PUSHDOWN          1
#define KEY_LOGIC_PUSHUP            2

/*woring 需要报警   error 需要急停*/
#define ABNORMAL_NONE   0x00
#define ABNORMAL_WORING 0x01
#define ABNORMAL_ERROR  0x02

/*目前最多八种woring 一个bit对应一种woring*/
#define UPMOVE_KEY_WORING    0x01
#define DOWNMOVE_KEY_WORING    0x02

/*目前最多八种error 一个bit对应一种error*/
#define ESTOP_KEY_ERROR     0x01

enum key_id{
    START_KEY,        //使能电机
    STOP_KEY,       //失能电机
    ACCELERATE_KEY,          //加速按钮
    SLOWDOWN_KEY,          //减速按钮
    FORWORD_KEY,       //正转按钮
    REVERSAL_KEY,     //反转按钮
    LOCATION_UP_KEY,  //位置增加按钮
    LOCATION_DOWN_KEY, //位置减少按钮
    KEY_ID_MAX,
};

typedef struct
{
 	uint8_t key_logic;
	uint8_t key_physic;
 	uint8_t keyon_counts;
 	uint8_t keyoff_counts;
}key_stat_t;

/**
 * @brief 
 * 
 * @return bool_t 
 */
bool_t key_gpio_run(void);

/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t key_gpio_init(void);


#endif