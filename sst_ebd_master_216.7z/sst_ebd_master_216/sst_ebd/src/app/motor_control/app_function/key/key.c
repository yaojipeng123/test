#include "types.h"
#include "stdio.h"
#include "dev.h"
#include "os_queue.h"

#include "iomap.h"
#include "gpio_id.h"
#include "key.h"
#include "gpio_dev.h"
#include "sm.h"
dev_t *key_gpio_dev;

extern iomap_iomap_cfg_t iomap_cfg[IOMAP_CFG_MAX];

key_stat_t key[8] =
	{
        {0, 0, 0, 0},
        {0, 0, 0, 0},
	    {0, 0, 0, 0},
        {0, 0, 0, 0},
        {0, 0, 0, 0},
	    {0, 0, 0, 0},
        {0, 0, 0, 0},
        {0, 0, 0, 0}
    };
uint8_t key_count[8] = {0};
gpio_config_t key_input[] = {
    {HAL_GPIO_130,GPIO_IO_INPUT_PU,NULL,NULL,0},
    {HAL_GPIO_131,GPIO_IO_INPUT_PU,NULL,NULL,0},
    {HAL_GPIO_122,GPIO_IO_INPUT_PU,NULL,NULL,0},
    {HAL_GPIO_123,GPIO_IO_INPUT_PU,NULL,NULL,0},
    {HAL_GPIO_124,GPIO_IO_INPUT_PU,NULL,NULL,0},
    {HAL_GPIO_125,GPIO_IO_INPUT_PU,NULL,NULL,0},
    {HAL_GPIO_126,GPIO_IO_INPUT_PU,NULL,NULL,0},
    {HAL_GPIO_127,GPIO_IO_INPUT_PU,NULL,NULL,0},
    
};
// gpio_config_t key_input_config[] = {
//     {HAL_GPIO_130, GPIO_IRQ_EDGE_BOTH, upmove_key_isr, NULL,0},
//     {HAL_GPIO_131, GPIO_IRQ_EDGE_BOTH, downmove_key_isr, NULL,0},
//     // {HAL_GPIO_122, GPIO_IRQ_EDGE_BOTH, onoff_button_isr, NULL,0},
// };
// void key_gpio_iomap_get()
// {
//     key_input_config[UPMOVE_KEY_PIN].id = (iomap_cfg[GPIO_UPMOVE_KEY].group<<4)+iomap_cfg[GPIO_UPMOVE_KEY].gpio;
//     key_input_config[DOWNMOVE_KEY_PIN].id = (iomap_cfg[GPIO_DOWNMOVE_KEY].group<<4)+iomap_cfg[GPIO_DOWNMOVE_KEY].gpio;
// }
void check_key(uint8_t key_id)
{
    if(key_id>8)
        return ;
    dev_control(key_gpio_dev, IOC_GPIO_GET, (unsigned long)&key_input[key_id]);
    key[key_id].key_physic = key_input[key_id].data;
    if(key[key_id].key_physic)
    {
        key[key_id].keyoff_counts = 0;
        key[key_id].keyon_counts++;
        if(key[key_id].keyon_counts>=10)
        {
            key[key_id].keyon_counts = 0;
            key[key_id].key_logic = KEY_LOGIC_PUSHUP;
        }
    }else{
        key[key_id].keyon_counts = 0;
        key[key_id].keyoff_counts++;
        if(key[key_id].keyoff_counts>=10)
        {
            key[key_id].keyoff_counts = 0;
            key[key_id].key_logic = KEY_LOGIC_PUSHDOWN;
        }
    }
}
void key_read_task(void *arg)
{
    while(1)
    {
        for(int i=0;i<KEY_ID_MAX;i++)
        {
            check_key(i);
        }

        os_delay(10);
    }
}
int32_t key_gpio_init(void)
{
    int32_t ret = ERR_OK;
    // struct breakdown abnormal_type = {0};

    // key_gpio_iomap_get();
    // gpio_device_init();
    key_gpio_dev = dev_find("gpio");

    if (!key_gpio_dev) {
        return  ERR_FAIL;
    }
    ret = dev_init(key_gpio_dev);

    return ret;
}



bool_t key_gpio_run(void)
{

    os_create_task_ext(key_read_task, NULL, 7, 1024, "key_read_task");

    return true;
}