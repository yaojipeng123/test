#ifndef _UNIT_TEST_H
#define _UNIT_TEST_H

#include "types.h"

#define TEST_MODULE_NAME_LEN      16
#define TEST_MODULE_SECTION(name) __attribute__((section(".testmodule." #name)))
#define TEST_MODULE_SINGLE_SECTION(name) \
    __attribute__((section(".singletestmodule." #name)))

#define TEST_MODULE_DEF(name, init, run, clean, loop, section) \
    section test_module_t name = {                             \
        .magic = 0x0202,                                       \
        .name_str = #name,                                     \
        .init_func = init,                                     \
        .run_func = run,                                       \
        .clean_func = clean,                                   \
        .loop_time = loop,                                     \
    }

#define TEST_MODULE(name, init, run, clean, loop) \
    TEST_MODULE_DEF(name, init, run, clean, loop, TEST_MODULE_SECTION(name))

#define TEST_MODULE_SINGLE(name, init, run, clean, loop) \
    TEST_MODULE_DEF(name, init, run, clean, loop,        \
                    TEST_MODULE_SINGLE_SECTION(name))

typedef bool_t (*unit_test_init_func)(void);
typedef bool_t (*unit_test_run_func)(void);
typedef bool_t (*unit_test_clean_func)(void);

typedef struct test_module {
    uint32_t magic;
    char *name_str;
    unit_test_init_func init_func;   /**< Pointer to the test init function. */
    unit_test_run_func run_func;     /**< Pointer to the test run function. */
    unit_test_clean_func clean_func; /**< Pointer to the test clean function. */
    uint32_t loop_time;
} test_module_t;

int putchar(int c);
void run_test(void *arg);
void stop_test(void);

#endif /* _UNIT_TEST_H */
