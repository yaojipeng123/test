#include "types.h"
#include "stdio.h"
#include "unit_test.h"

#include "os_task.h"
#include "os_utils.h"
#include "modules.h"
#include "log.h"

static void log_test_func(void *arg)
{
    UNUSED(arg);

    while (1) {
        LOG_INFO(LIB_MID, "hello world\n");

        os_delay(1000);
    }
}
static bool_t log_test_init(void)
{
    return true;
}

static bool_t log_test_run(void)
{
    os_create_task_ext(log_test_func, NULL, 5, 128, "log_test");

    return true;
}

//TEST_MODULE_SINGLE(log_test, log_test_init, log_test_run, NULL, 1);
