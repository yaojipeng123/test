#include "types.h"
#include "stdio.h"
#include "unit_test.h"

#include "share_task.h"
#include "os_utils.h"

char str[16];

static void hello_world(void *arg)
{
    printf("event %s\n", arg);
}

static void print_msg(void *arg)
{
    printf("msg %s\n", arg);
}

static bool_t share_task_test_init(void)
{
    return true;
}

static bool_t share_task_test_run(void)
{
    int j, msg_id;

    share_task_event_register(SHARE_TASK_QUEUE_HP,
                                SHARE_EVENT_START,
                                hello_world, "hello");

    msg_id = share_task_msg_register(print_msg);

    for (j = 0; j < 5; j++) {
        share_task_post_event(SHARE_TASK_QUEUE_HP,
                                SHARE_EVENT_START);

        snprintf(str, sizeof(str), "HP: msg %d", j);
        share_task_post_msg(SHARE_TASK_QUEUE_HP, msg_id, str);

        snprintf(str, sizeof(str), "LP: msg %d", j);
        share_task_post_msg(SHARE_TASK_QUEUE_LP, msg_id, str);

        os_delay(1000);
    }

    return 1;
}

// TEST_MODULE(share_task_test, share_task_test_init,
//             share_task_test_run, NULL, 1);
