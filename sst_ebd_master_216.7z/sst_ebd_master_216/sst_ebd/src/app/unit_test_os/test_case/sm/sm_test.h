#ifndef _TEST_SM_H
#define _TEST_SM_H

bool_t test_sm_init(void);
bool_t test_sm_run(void);

#endif /* _TEST_SM_H */
