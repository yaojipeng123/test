#include "types.h"
#include "unit_test.h"

#include "os_utils.h"

#include "sm.h"

#include "sm_test.h"

bool_t sm_test_init(void)
{
    return true;
}

bool_t sm_test_run(void)
{
    return true;
}

// TEST_MODULE(sm_test, sm_test_init, sm_test_run, NULL, 1);
