#include "types.h"
#include "stdio.h"

#include "hal_pwm.h"
#include "pwm_dev.h"
#include "unit_test.h"
#include "dev.h"
#include "pwm_test.h"

dev_t *test_pwm;


bool_t test_pwm_init(void)
{
    int32_t ret = ERR_OK;
    test_pwm = dev_find("pwm1");
    if (!test_pwm) {
        return ERR_FAIL;
    }
    ret = dev_init(test_pwm);
    return ret;
}

bool_t test_pwm_run(void)
{
    uint32_t cycle = 1000;
    pwm_set_config_t test_config = {PWM1_MODE, cycle,OCPOLARITY_HIGH,PWM_CHANNEL_1};
    dev_control(test_pwm,IOC_PWM_START,(unsigned long)&test_config);//使用初始化参数开启PWM，如需修改pwm配置参数
    dev_control(test_pwm,IOC_PWM_DUTY_CYCLE,cycle);//修改周期

    return true;
}

bool_t test_pwm_clean(void)
{
    return true;
}

// TEST_MODULE(pwm_test, test_pwm_init, test_pwm_run, test_pwm_clean, 1);
