#ifndef TEST_PWM_H
#define TEST_PWM_H

#define PWM1_MODE       0
#define PWM2_MODE       1

#define OCPOLARITY_HIGH 0
#define OCPOLARITY_LOW  1
#define PWM_CHANNEL_0   0 
#define PWM_CHANNEL_1   1

#define PWM_CHANNEL_2   2
#define PWM_CHANNEL_3   3
bool_t test_pwm_init(void);

bool_t test_pwm_run(void);

#endif /* TEST_TIMER_H */
