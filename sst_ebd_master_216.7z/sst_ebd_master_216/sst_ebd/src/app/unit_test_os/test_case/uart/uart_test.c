#include "types.h"
#include "stdio.h"
#include "string.h"
#include "unit_test.h"
#include "log.h"
#include "os_utils.h"
#include "os_task.h"

#include "dev.h"
#include "uart_dev.h"

#include "uart_test.h"

dev_t *uart_dev = NULL;

uint8_t uart_buffer[]="UART in unit_test_os transmission\r\n";

bool_t test_uart_init(void)
{
    uart_device_init();

    // memset(uart_buffer, 0xaa, 256);

    return true;
}

bool_t test_uart_run(void)
{
    uart_dev = dev_find("uart2");

    if (!uart_dev) {
        return false;
    }

    dev_open(uart_dev,RX_INT|TX_POLLING|RS_232);

    dev_write(uart_dev, uart_buffer, sizeof(uart_buffer));

    uint8_t * rx_buffer[25];
    uint8_t * rx =rx_buffer;
    // dev_read(uart_dev, rx_buffer, 255);
    // dev_close(uart_dev);
    uint32_t count;
    while(1){
        count = dev_read(uart_dev, rx, 25);

        LOG_INFO(1,"rec:%s", rx);
        os_delay(100);
        
    }

    return true;
}

bool_t test_uart_clean(void)
{
    return true;
}

// TEST_MODULE(uart_test, test_uart_init, test_uart_run, test_uart_clean, 1);
