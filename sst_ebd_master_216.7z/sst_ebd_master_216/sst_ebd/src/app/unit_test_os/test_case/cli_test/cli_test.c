#include "types.h"
#include "stdio.h"
#include "unit_test.h"

#include "os_task.h"
#include "os_utils.h"
#include "modules.h"
#include "cli.h"

static void cli_test_func(void *arg)
{
    UNUSED(arg);

    cli();
}
static bool_t cli_test_init(void)
{
    return true;
}

static bool_t cli_test_run(void)
{
    os_create_task_ext(cli_test_func, NULL, 5, 128, "cli_test");

    return true;
}

// TEST_MODULE_SINGLE(cli_test, cli_test_init, cli_test_run, NULL, 1);
