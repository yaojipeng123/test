#include "types.h"
#include "stdio.h"
#include "unit_test.h"

#include "os_utils.h"
#include "os_task.h"

#include "hal_gpio.h"
#include "hal_timer.h"
#include "gpio_dev.h"
#include "dev.h"
#include "gpio_test.h"

#define TEST_GPIO_INPUT  HAL_GPIO_115   //(GPIOH, 3)
#define TEST_GPIO_OUTPUT HAL_GPIO_17    //(GPIOB, 1)
#define INT_ESC_PIN      HAL_GPIO_8
#define RUN_LED          HAL_GPIO_51
dev_t *gpio_dev = NULL;
// void test_callback();

uint32_t test_gpio_int_count = 0;

static void test_gpio_callback(void *arg)
{
    UNUSED(arg);

    printf("[GPIO%d] int done\n", RUN_LED);
    test_gpio_int_count++;
}

bool_t test_gpio_run(void)
{
    uint8_t val;
    int i;
    gpio_config_t test = {RUN_LED, GPIO_IO_OUTPUT_PP,NULL,NULL, 0};

    // dev_control(gpio_dev,IOC_GPIO_SET,(unsigned long)&test);
    // test.data = 1;
    // dev_control(gpio_dev,IOC_GPIO_SET,(unsigned long)&test);
    // gpio_io_config_t test1 = {GPIO_IO_INPUT_PU, 0};
    // gpio_device_ctl(RUN_LED, IOC_GPIO_GET, &test1);
    // val = test1.data;
    // printf("val is %d\n", val);

    // gpio_io_config_t test={GPIO_IO_OUTPUT_PP,0};
    // gpio_device_ctl(RUN_LED,IOC_GPIO_SET,&test);
    // test.data = 1;
    // gpio_device_ctl(RUN_LED,IOC_GPIO_SET,&test);
    // test.data = 0;
    // gpio_device_ctl(RUN_LED,IOC_GPIO_SET,&test);
    // val = test.data;
    // gpio_irq_config_t test2 = {GPIO_IRQ_EDGE_FALLING | GPIO_IRQ_ENABLE, test_gpio_callback, NULL};
    // gpio_device_ctl(RUN_LED, IOC_GPIO_SET_IRQ, &test2);
    return true;
}

bool_t test_gpio_init(void)
{
    // gpio_device_init();
    gpio_device_init();
    dev_init(gpio_dev);
    return true;
}

bool_t test_gpio_clean(void)
{
    return true;
}

// void test_callback()
// {
//     printf("enter irq\n");
// }

// TEST_MODULE(os_gpio_test, test_gpio_init, test_gpio_run, test_gpio_clean, 1);
