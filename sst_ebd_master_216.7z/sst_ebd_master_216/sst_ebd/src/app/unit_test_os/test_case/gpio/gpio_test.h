#ifndef _TEST_GPIO_H
#define _TEST_GPIO_H

bool_t test_gpio_run(void);
bool_t test_gpio_init(void);
bool_t test_gpio_clean(void);

#endif /* _TEST_GPIO_H */
