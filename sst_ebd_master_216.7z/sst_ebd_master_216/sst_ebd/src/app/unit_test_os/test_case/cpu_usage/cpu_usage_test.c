#include "types.h"
#include "unit_test.h"
#include "cpu_usage.h"
#include "os_utils.h"
#include "share_task.h"

#include "cpu_usage_test.h"

bool_t test_cpu_usage_init(void)
{
    cpu_usage_util_init();
    return 1;
}

bool_t test_cpu_usage_run(void)
{
    cpu_usage_util_start(5000);
    return 1;
}

// TEST_MODULE(cpu_usage_test, test_cpu_usage_init, test_cpu_usage_run, NULL, 1);
