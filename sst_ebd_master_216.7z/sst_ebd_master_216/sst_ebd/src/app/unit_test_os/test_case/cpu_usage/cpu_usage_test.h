#ifndef _TEST_CPU_USAGE_H
#define _TEST_CPU_USAGE_H

bool_t test_cpu_usage_init(void);
bool_t test_cpu_usage_run(void);

#endif /* _TEST_CPU_USAGE_H */
