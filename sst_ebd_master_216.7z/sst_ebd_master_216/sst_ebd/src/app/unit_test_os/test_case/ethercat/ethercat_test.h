#ifndef _ECAT_TEST_H
#define _ECAT_TEST_H

bool_t ethercat_init(void);
bool_t ethercat_run(void);
bool_t ethercat_clean(void);

#endif /* _ECAT_TEST_H */