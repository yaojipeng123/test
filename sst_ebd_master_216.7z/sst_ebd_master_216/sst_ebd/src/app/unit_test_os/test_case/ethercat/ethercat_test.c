#include "types.h"
#include "stdio.h"

#include "ethercat_test.h"
#include "el9800appl.h"
#include "hal_Fmc.h"
#include "hal_timer.h"
#include "unit_test.h"
#include "os_task.h"
#include "dev.h" 
#include "gpio_dev.h"
#include "timer_dev.h"
extern dev_t *gpio_dev;
dev_t *ecat_timer;
bool_t ethercat_init(void)
{
    gpio_device_init();
    timer_device_init();
    dev_init(gpio_dev);
    hal_fmc_nor_init();
    
    return true;
}

bool_t ethercat_run(void)
{
    ecat_timer = dev_find("timer1");
    if(!ecat_timer)
    {
        return false;
    }
    gpio_dev = dev_find("gpio");

    if (!gpio_dev) {
        return false;
    }
    os_create_task_ext(ethcat_task, NULL, 8, 512, "ethcat_task");   //开始ecat通信task
    // hal_timer_create(1,5000,0,ethercat_init,NULL);
    // hal_timer_start(1);
    return true;
}

bool_t ethercat_clean(void)
{

}

// TEST_MODULE(ethercat, ethercat_init, ethercat_run, ethercat_clean, 1);
