#ifndef ACTUATOR_CTL_H
#define ACTUATOR_CTL_H


#define QUEUE_LOCATION_ID 0
#define MAX_ACTUATOR_NUM    4
#define MAX_BUF_LEN     1024
#define ACTUATOR_ID_1   1
#define ACTUATOR_ID_2   2
#define ACTUATOR_ID_3   3
#define ACTUATOR_ID_4   4

#define INIT_TARGET_LOCATION    0
#define INIT_CURRENT_LOCATION    0
#define INIT_ACTUAL_TORQUE    0
#define TEMPERATURE    0
#define ERROR_VAL    0

struct set_location_cf
{
   uint8_t id;
   uint16_t location_val;
};

typedef struct actuator_info {
    uint8_t id;
    uint16_t target_location;
    uint16_t current_location;
    uint16_t actual_torque;
    uint16_t temperature;
    uint8_t error;
    struct actuator_info *next;
}actuator_info_t;

/**
 * @brief set target location value
 * 
 * @param id 
 * @param target_location 
 * @return int32_t 
 */
int32_t change_target_location(uint8_t id,uint16_t target_location);

/**
 * @brief init actuator
 * 
 * @return int32_t 
 */
int32_t actuator_ctl_init();

/**
 * @brief creat a task to control actuator
 * 
 * @return int32_t 
 */
int32_t actuator_ctl_run();

#endif // !ACTUATOR_CTL_H



