#include "types.h"
#include "stdio.h"

#include "hal_timer.h"
#include "timer_dev.h"
#include "unit_test.h"
#include "modules.h"
#include "timer_test.h"
#include "string.h"

dev_t *test_timer;
static int32_t test_timer_cb(void *data)
{
    return ERR_OK;
}

bool_t test_timer_init(void)
{
    int32_t ret = ERR_OK;
    timer_alarm_t *test_timer_config = os_mem_malloc(LIB_MID, sizeof(timer_alarm_t));
    if (!test_timer_config) {
        os_mem_free(test_timer_config);
        return ERR_FAIL;
    }
    memset(test_timer_config, 0x0, sizeof(timer_alarm_t));
    test_timer_config->period = 0x0a;
    test_timer_config->repeat = true;
    test_timer_config->cb = test_timer_cb;
    test_timer = dev_find("timer1");
    if (!test_timer) {
        return ERR_FAIL;
    }
    test_timer->user_data = (void *)test_timer_config;
    return ret;
}

bool_t test_timer_run(void)
{
    dev_open(test_timer,TIM_NORMAL);
    dev_control(test_timer, IOC_TIMER_CONTROL, IO_TIMER_START);
    return true;
}

bool_t test_timer_clean(void)
{
    return true;
}

// TEST_MODULE(timer_test, test_timer_init, test_timer_run, test_timer_clean, 1);
