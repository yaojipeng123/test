#include "types.h"
#include "stdio.h"
#include "unit_test.h"

#include "os_task.h"
#include "os_utils.h"

static void hello_test(void *arg)
{
    UNUSED(arg);

    while (1) {
        printf("hello world\n");

        os_delay(1000);
    }
}
static bool_t hello_test_init(void)
{
    return true;
}

static bool_t hello_test_run(void)
{
    os_create_task_ext(hello_test, NULL, 5, 128, "hello_test");

    return true;
}

// TEST_MODULE(helloworld_test, hello_test_init, hello_test_run, NULL, 1);
