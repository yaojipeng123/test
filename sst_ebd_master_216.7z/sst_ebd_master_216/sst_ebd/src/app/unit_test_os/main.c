#include "types.h"
#include "string.h"
#include "unit_test.h"
#include "hal_irq.h"
#include "hal_uart.h"
#include "hal_timer.h"

#include "os_utils.h"
#include "os_task.h"
#include "os_hook.h"

#include "share_task.h"
#include "log.h"
#include "cli.h"

#include "hal.h"

int putchar(int c);
int putchar(int c)
{
    hal_uart_putc(HAL_UART_PORT1, c);
    return c;
}

static void debug_uart_init(void)
{
    hal_uart_open(HAL_UART_PORT1, 115200, HAL_UART_DATA_BITS_8, HAL_UART_STOP_BITS_1,
                  HAL_UART_PARITY_NONE);
}

static void idle_hook_cb(void)
{
    cli();
}

int main(void)
{
    hal_bsp_init();

    hal_timer_init();
    uart_device_init();
    // debug_uart_init();
    log_init();
    actuator_ctl_init();
    actuator_ctl_run();
    // printf("debug_uart_init finished\r\n");
    // os_hook_idle_register_callback(idle_hook_cb);
    
    // share_task_init();

    os_create_task_ext(run_test, NULL, 10, 512, "run_test");

    os_start_kernel();

    return 0;
}
