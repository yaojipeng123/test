#ifndef TIM_ENCODE_H
#define TIM_ENCODE_H

/* 编码器定时器溢出值 */		
#define ENCODER_TIM_PERIOD                     65535

/* 编码器定时器预分频值 */
#define ENCODER_TIM_PRESCALER                  0

/* 编码器物理分辨率 一圈的脉冲数*/
#define ENCODER_RESOLUTION                     16

#define ENCODER_TOTAL_RESOLUTION             (ENCODER_RESOLUTION * 4)  /* 4倍频后的总分辨率 不考虑电机减速比*/

/**
 * @brief 
 * 
 * @param tim_name 
 * @return int32_t 
 */
int32_t tim_encode_init(const char *tim_name);

/**
 * @brief Get the speed from encode object
 * 
 * @return int16_t 
 */
int32_t get_speed_from_encode();

/**
 * @brief Get the direction from encode object
 * 
 * @return int8_t 
 */
int8_t get_direction_from_encode();

/**
 * @brief clean the encode count
 * 
 * @return int32_t 
 */
int32_t clean_encode_count();

#endif // !TIM_ENCODE_H