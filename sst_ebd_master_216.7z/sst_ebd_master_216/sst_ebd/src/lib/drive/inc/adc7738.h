#ifndef _ADC7738_H_
#define _ADC7738_H_

#define CMD_GET_ADC_VALUE     0x48
#define REG_AD_CONVERSION_END 0x44

#define MODE_SET_REGISTER 0x38

#define INPUT_MODE_DOUBLE 0x60   //差分信号输入
#define INPUT_MODE_SINGLE 0x00   //单信号输入

#define CHANNEL_ENABLE  0x08
#define CHANNEL_DISABLE 0x00

#define INPUT_RANGE0 0x04   //-2.5v~2.5v
#define INPUT_RANGE1 0x05   //0v~2.5v
#define INPUT_RANGE2 0x00   //-1.25v~1.25v
#define INPUT_RANGE3 0x01   //0v~1.25v
#define INPUT_RANGE4 0x02   //-0.625v~0.625v
#define INPUT_RANGE5 0x03   //0v~0.625v
#define CHANNEL0     0x28
#define CHANNEL1     0x29
#define CHANNEL2     0x2a
#define CHANNEL3     0x2b
#define CHANNEL4     0x2c
#define CHANNEL5     0x2d
#define CHANNEL6     0x2e
#define CHANNEL7     0x2f

#define IDLE_MODE                  0x00
#define CONTINUOUS_CONVERSION_MODE 0x20   //连续转换模式
#define SINGLE_CONVERSION_MODE     0x40   //单次转换模式
#define STANDBY_MODE               0x60   //待机模式
#define ZERO_CALIBRATION           0x80   //零刻度校准模式

#define ADC_16_BIT 0x00
#define ADC_24_BIT 0x02
/**
 * @brief get the dac7738's register value
 * 
 * @param cmd
 * @return uint8_t
 */
uint8_t get_regvalue(uint8_t cmd);

/**
 * @brief init dac7738
 * @param spi_name
 * @param arg 
 * @return uint8_t
 */
int32_t spi_dac7738_init(const char *spi_name, unsigned long arg);

/**
 * @brief get the value of dac7738

 * @return uint32_t dac's value
 */
int32_t dac7738_get_adc_val();
#endif   //_ADC7738_H_