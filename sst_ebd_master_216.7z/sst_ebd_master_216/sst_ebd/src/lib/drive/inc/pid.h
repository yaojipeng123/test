#ifndef PID_H

#define PID_H

typedef struct
{
    float target_val;           //目标值
    float actual_val;        		//实际值
    float err;             			//定义偏差值
    float err_last;          		//定义上一个偏差值
    float Kp,Ki,Kd;          		//定义比例、积分、微分系数
    float integral;          		//定义积分值
}pid_config_t;

/**
 * @brief 
 * 
 */
void dc_brush_pid_init();

/**
 * @brief Set the p i d value
 * 
 * @param p 
 * @param i 
 * @param d 
 */
void set_p_i_d(float p, float i, float d);

/**
 * @brief Set the pid target object
 * 
 * @param temp_val 
 */
void set_pid_target(float temp_val);

/**
 * @brief Set the pid target plus object
 * 
 * @param pid 
 * @param temp_val 
 */
void set_pid_target_plus(pid_config_t *pid, float temp_val);

/**
 * @brief Get the pid target object
 * 
 * @return float 
 */
float get_pid_target(void);

/**
 * @brief 
 * 
 * @param actual_val 
 * @return float 
 */
float pid_realize(float actual_val);

/**
 * @brief 
 * 
 * @param actual_val 
 * @return float 
 */
float location_pid_realize(float actual_val);//位置环pid算法

/**
 * @brief 
 * 
 * @param actual_val 
 * @return float 
 */
float speed_pid_realize(float actual_val);//速度环pid算法
#endif // !PID_H
