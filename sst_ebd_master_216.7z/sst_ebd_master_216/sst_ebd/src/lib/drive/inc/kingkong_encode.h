#ifndef _KINGKONG_ENCODE_H
#define _KINGKONG_ENCODE_H


/**
 * @brief init the gpio uart about 485 communication
 * @param uart_name
 * @return uint8_t
 */
uint8_t kingkong_485_init(const char *uart_name,uint8_t re_pin);

/**
 * @brief get the encode value
 * 
 * @param rcv_buf 
 * @param addr
 */
void kingkong_get_info(uint8_t *rcv_buf, uint8_t addr,uint8_t re_pin);

/**
 * @brief set the 485 communication's address about kingkong enconde
 * 
 * @param addr
 */
void kingkong_set_addr(uint8_t addr);

/**
 * @brief check the encode value
 * 
 * @param buf 
 * @param length
 * @return uint8_t
 */
uint8_t kingkong_value_check(uint8_t *buf, uint8_t length);//BCC校验

#endif