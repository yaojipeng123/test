#ifndef _DC_MOTOR_MOTOR_H_
#define _DC_MOTOR_MOTOR_H_

#define PWM_CH1     1
#define PWM_CH2     2
#define PWM_CH3     3

#define MOTOR_FWD   0
#define MOTOR_REV   1

#define NO_FAULT    1
#define HAS_FAULT   0



/**
 * @brief init pwm
 * 
 * @param pwm_name 
 * @param set_config_addr
 * @return bool_t 
 */
int32_t dc_brush_motor_pwm_init(const char *pwm_name,unsigned long set_config_addr);

/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t dc_brush_adc_init();

/**
 * @brief 
 * 
 * @param channel 
 * @param value 
 */
void dc_brush_get_adc_value(uint32_t channel, uint32_t *value);


/**
 * @brief set the pwm duty to set motor speed
 * 
 * @param speed 
 * @return int32_t 
 */
int32_t dc_brush_motor_set_speed(uint16_t speed);

/**
 * @brief set the motor direction
 * 
 * @param dir 
 * @return int32_t 
 */
int32_t dc_brush_motor_set_direction(bool_t dir);

/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t dc_brush_motor_gpio_init();

/**
 * @brief 
 * 
 * @param id 
 * @param enable 
 * @return bool_t 
 */
bool_t dc_brush_motor_enable(uint8_t id,bool_t enable);

/**
 * @brief 
 * 
 * @param id 
 * @return bool_t 
 */
bool_t dc_brush_motor_get_fault(uint8_t id);

/**
 * @brief 
 * 
 */
void dc_brush_pid_init();

/**
 * @brief Set the pid target object
 * 
 * @param temp_val 
 */
void set_pid_target(float temp_val);

/**
 * @brief Get the pid target object
 * 
 * @return float 
 */
float get_pid_target(void);

/**
 * @brief 
 * 
 * @param actual_val 
 * @return float 
 */
float pid_realize(float actual_val);
#endif