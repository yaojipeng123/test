#ifndef MIC_LINEAR_ACTUATOR
#define MIC_LINEAR_ACTUATOR

#define SINGLE_CTL_LEN          0x03    

#define SINGLE_CTL_MOVE         0x04    //启动控制
#define SINGLE_CTL_ESTOP        0x23    //急停控制
#define SINGLE_CTL_SAVE         0x20    //保存参数
#define SINGLE_CTL_QUERY        0x22    //查询
#define SINGLE_CTL_CLEAN        0x1e    //清除故障

#define CMD_RD                  0x01    //读命令
#define CMD_WR                  0x02    //写命令
#define CMD_WR_NR               0x03    //无应答写命令
#define CMD_WR_LOCATION         0x21    //写定位模式命令有反馈
#define CMD_WR_LOCATION_NR      0x03    //写定位模式命令无反馈
#define CMD_WR_LOCATION_RADIO   0xf2    //广播写定位模式
#define CMD_WR_FOLLOW           0x20    //写随动模式命令有反馈
#define CMD_WR_FOLLOW_NR        0x19    //写随动模式命令无反馈
#define CMD_WR_FOLLOW_RADIO     0xf3    //广播写随动模式
#define CMD_WR_FUNCTION_CONTROL 0x04    //功能控制 单控

#define INDEX_ID_INFO                       0x02        //设备ID号 1~254
#define INDEX_BAUD_INFO                     0x0c        //串口波特率  0-19200 1-115200 2-57600 3-921600   默认3
#define INDEX_FORCE_ZERO_SET                0x1f        //力传感器零位校准
#define INDEX_PROTECTION_CURRENT_INFO       0x20        //过流保护，范围300~1500mA   addr:0x20~0x21
#define INDEX_TARGET_LOCATION_INFO          0x37        //目标位置设定信息
#define INDEX_FORCE_SENSOR_INFO             0x4c        //力传感器的值-32767~32768 单位：克
#define INDEX_FORCE_SENSOR_ORIGINAL_INFO    0x4e        //力传感器的原始值 0-65535 12bitADC值
#define INDEX_PROTECTION_TEMP_INFO          0x62        //过温保护 范围：回温启动温度+5 ~ 80 摄氏度  输入值为温度*10
#define INDEX_TEMP_RETURN_START_INFO        0x64        //回温启动  范围：20 ~ 过温保护温度-5 摄氏度  输入值为温度*10

/**
 * @brief get the motor info
 * 
 * @param id 
 */
void mic_linear_query(uint8_t id);
/**
 * @brief change id
 * 
 * @param old_id 
 * @param new_id 
 */
void mic_linear_set_id(uint8_t old_id,uint8_t new_id);

/**
 * @brief control actuator to work
 * 
 * @param id 
 */
void mic_linear_work(uint8_t id);

/**
 * @brief control actuator to estop
 * 
 */
void mic_linear_estop(uint8_t id);

/**
 * @brief Set the motor to move to the target location
 * 
 * @param id 
 * @param location_data 
 */
void mic_linear_write_location(uint8_t id,uint16_t location_data);

/**
 * @brief start uart read
 * 
 * @param buf 
 * @return int32_t 
 */
int32_t uart_start_read_buf(uint8_t *buf);

/**
 * @brief 
 * 
 * @param uart_name 
 * @return int32_t 
 */
int32_t mic_linear_init(const char *uart_name);

#endif // !MIC_LINEAR_ACTUATOR