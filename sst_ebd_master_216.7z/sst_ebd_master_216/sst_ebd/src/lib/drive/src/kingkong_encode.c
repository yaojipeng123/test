//角度环 位置反馈 金刚编码器
#include "types.h"
#include "stdio.h"

#include "hal_gpio.h"
#include "gpio_dev.h"
#include "dev.h"
#include "uart_dev.h"
#include "os_utils.h"
#include "os_task.h"
#include "os_queue.h"


#define TX_MODE      1
#define RX_MODE      0

#define CMD_GET_INFO 0x00
#define CMD_SET_ZERO 0x20
#define CMD_SET_ADDR 0x40
#define INITIAL_ADDR 0x1f
#define ENCODE1_ADDR    0x06
#define ENCODE2_ADDR    0x07
dev_t *mbs_485_uart;
dev_t *rs485_enable_pin;
uint32_t angle_value = 0;
os_queue_h tx_finish;
gpio_config_t rs485_re ;//= {HAL_GPIO_7, GPIO_IO_OUTPUT_PP, NULL, NULL, 0};

int32_t kingkong_485_init(const char *uart_name,uint8_t re_pin)
{
    int32_t ret = ERR_OK;
    rs485_enable_pin = dev_find("gpio");
    if (!rs485_enable_pin) {
        return ERR_FAIL;
    }
    ret = dev_init(rs485_enable_pin);

    mbs_485_uart = dev_find(uart_name);
    if (!mbs_485_uart) {
        return ERR_FAIL;
    }
    ret = dev_open(mbs_485_uart,RX_INT|TX_INT|RS_485);
    if(ret)
        return ret;
    // dev_control(mbs_485_uart,IOC_485_SET_RE_PIN,re_pin);//使用RS485
    // dev_control(mbs_485_uart,IOC_UART_PROTOCOL_MASK,RS485);//使用RS485
    // dev_control(mbs_485_uart,IOC_UART_MODE_SET,RX_TX_INT);//使能发送接收中断
    
    return ret;
}

void rs485_rx_tx_set(uint8_t mode,uint8_t re_pin)
{
    rs485_re.data = mode;
    rs485_re.id = re_pin;
    rs485_re.config = GPIO_IO_OUTPUT_PP;
    rs485_re.cb = NULL;
    rs485_re.arg = NULL;
    dev_control(rs485_enable_pin, IOC_GPIO_SET, (unsigned long)&rs485_re);
}

void kingkong_get_info(uint8_t *rcv_buf, uint8_t addr,uint8_t re_pin)
{
    uint8_t tx_buf = 0;
    uint8_t send_buf[5] = {0};
    int i = 0;
    int odd_check = 1;
    tx_buf = addr | CMD_GET_INFO;
    for (i = 0; i < 7; i++) {
        if ((0x01 << i) & tx_buf) {
            odd_check = ~odd_check;
        }
    }
    tx_buf = (odd_check << 7) | tx_buf;
    // tx_buf = 0x11;
    send_buf[0] = tx_buf;
    rs485_rx_tx_set(TX_MODE,re_pin);
    dev_write(mbs_485_uart, send_buf, 1);
    // os_delay(1);
    dev_read(mbs_485_uart, rcv_buf, 6);
}

void mbs_485_send(uint8_t cmd,uint8_t addr,uint8_t re_pin)
{
    uint8_t tx_buf = 0;
    uint8_t send_buf[5] = {0};
    int i = 0;
    int odd_check = 1;
    tx_buf = addr | cmd;
    for (i = 0; i < 7; i++) {
        if ((0x01 << i) & tx_buf) {
            odd_check = ~odd_check;
        }
    }
    tx_buf = (odd_check << 7) | tx_buf;
    // tx_buf = 0x11;
    send_buf[0] = tx_buf;
    rs485_rx_tx_set(TX_MODE,re_pin);
    dev_write(mbs_485_uart, send_buf, 1);
}
void kingkong_set_addr(uint8_t addr,uint8_t re_pin)
{

    mbs_485_send(CMD_SET_ADDR, INITIAL_ADDR,re_pin);
    os_delay(1);


    mbs_485_send(CMD_SET_ADDR, 0x02,re_pin);
    os_delay(1);

    mbs_485_send(CMD_SET_ADDR, 0x04,re_pin);
    os_delay(1);

    mbs_485_send(CMD_SET_ADDR, 0x06,re_pin);
    os_delay(1);

    mbs_485_send(CMD_SET_ADDR, 0x08,re_pin);
    os_delay(1);

    mbs_485_send(CMD_SET_ADDR, 0x0a,re_pin);
    os_delay(1);

    mbs_485_send(CMD_SET_ADDR, 0x0c,re_pin);
    os_delay(1);

    mbs_485_send(CMD_SET_ADDR, 0x0e,re_pin);
    os_delay(1);

    mbs_485_send(CMD_SET_ADDR, 0x10,re_pin);
    os_delay(1);

    mbs_485_send(CMD_SET_ADDR, addr,re_pin);
    os_delay(1);
}
uint8_t temp = 0;
uint8_t kingkong_value_check(uint8_t *buf, uint8_t length)//BCC校验
{
    temp = *buf++;
    length = length-1;
    if(length<=1)
    {
        return 0;
    }
    while (--length) {
        temp = (*buf++) ^ temp;
    }
    if (temp == *buf) {
        return 1;
    } else {
        return 0;
    }
}




