#include "types.h"
#include "os_utils.h"

#include "sm.h"
#include "dev.h"
#include "dc_brush_motor_control.h"
#include "pwm_dev.h"
#include "gpio_dev.h"

dev_t *dc_brush_motor_dev;
dev_t *sleep_enable_pin;
dev_t *get_fault_pin;

static bool_t direction = 0;//方向
static uint16_t dutyfactor = 0;//占空比
gpio_config_t sleep_pin;
gpio_config_t fault_pin;

int32_t dc_brush_motor_pwm_init(const char *pwm_name,unsigned long set_config_addr)
{//pwm   gpio_out 
    int32_t ret = ERR_OK;

    dc_brush_motor_dev = dev_find(pwm_name);
    if(!dc_brush_motor_dev)
    {
        return ERR_FAIL;
    }
    dev_init(dc_brush_motor_dev);
    dev_control(dc_brush_motor_dev,IOC_PWM_START,set_config_addr);
    return ret;
}

int32_t dc_brush_motor_gpio_init()
{
    sleep_enable_pin = dev_find("gpio");
    if(!sleep_enable_pin)
    {
        return ERR_FAIL;
    }
    dev_init(sleep_enable_pin);
    get_fault_pin = dev_find("gpio");
    if(!get_fault_pin)
    {
        return ERR_FAIL;
    }
    dev_init(get_fault_pin);
}

int32_t dc_brush_motor_set_speed(uint16_t speed)
{
    int32_t ret = ERR_OK;
    pwm_config_t speed_set;
    dutyfactor = speed;
    if (direction == MOTOR_FWD)
    {
        speed_set.channel = PWM_CH1;
    }
    else
    {
        speed_set.channel = PWM_CH2;
    }
    speed_set.pulse = speed;
    if(!dc_brush_motor_dev)
    {
        return ERR_FAIL;
    }
    ret = dev_control(dc_brush_motor_dev,IOC_PWM_FREQ,(unsigned long)&speed_set);
    return ret;
}

int32_t dc_brush_motor_set_direction(bool_t dir)
{
    int32_t ret = ERR_OK;
    pwm_config_t speed_set;
    direction = dir;
    if(!dc_brush_motor_dev)
    {
        return ERR_FAIL;
    }
    if(direction == MOTOR_FWD)
    {
        speed_set.channel = PWM_CH2;
        speed_set.pulse = 0;
        dev_control(dc_brush_motor_dev,IOC_PWM_FREQ,(unsigned long)&speed_set);
        speed_set.channel = PWM_CH1;
        speed_set.pulse = dutyfactor;
        dev_control(dc_brush_motor_dev,IOC_PWM_FREQ,(unsigned long)&speed_set);
    }else{
        speed_set.channel = PWM_CH1;
        speed_set.pulse = 0;
        dev_control(dc_brush_motor_dev,IOC_PWM_FREQ,(unsigned long)&speed_set);
        speed_set.channel = PWM_CH2;
        speed_set.pulse = dutyfactor;
        dev_control(dc_brush_motor_dev,IOC_PWM_FREQ,(unsigned long)&speed_set);
    }
    return ret;
}


bool_t dc_brush_motor_enable(uint8_t id,bool_t enable)//Enable or disable motor
{
    sleep_pin.id = id;
    sleep_pin.data = enable;
    sleep_pin.config = GPIO_IO_OUTPUT_PP;
    sleep_pin.arg = NULL;
    sleep_pin.cb = NULL;
    dev_control(sleep_enable_pin, IOC_GPIO_SET, (unsigned long)&sleep_pin);
}

bool_t dc_brush_motor_get_fault(uint8_t id)
{
    bool_t ret = NO_FAULT;
    fault_pin.id = id;
    fault_pin.config = GPIO_IO_INPUT_PU;
    fault_pin.arg = NULL;
    fault_pin.cb = NULL;
    fault_pin.data = 0;
    dev_control(get_fault_pin, IOC_GPIO_GET, (unsigned long)&fault_pin);
    ret = fault_pin.data;
    return ret;
}



