#include "types.h"
#include "stdio.h"

#include "dev.h"
#include "hal_timer.h"
#include "timer_dev.h"
#include "tim_encode.h"
dev_t *tim_encode_dev;
extern int16_t encoder_overflow_count;
int32_t tim_encode_init(const char *tim_name)
{
    int32_t ret = ERR_OK;
    tim_encode_dev = dev_find(tim_name);
    if(!tim_encode_dev)
    {
        return ERR_FAIL;
    }
    ret = dev_open(tim_encode_dev,TIM_ENCODE);
    return ret;
}

int32_t get_speed_from_encode()//100ms调用一次
{
    int32_t tim_count = 0;
    static int32_t capture_count = 0;
    static int32_t last_count = 0;
    int32_t actual_speed = 0;

    if(!tim_encode_dev)
    {
        return ERR_FAIL;
    }
    tim_count = dev_control(tim_encode_dev,IOC_TIMER_GET_COUNTER_ID,NULL);
    
    /* 转轴转速 = 单位时间内的计数值 / 编码器总分辨率 * 时间系数  */
    actual_speed = tim_count * 10 / ENCODER_TOTAL_RESOLUTION  ;
    
    return actual_speed;
}

int8_t get_direction_from_encode()
{
    int8_t encode_direction;
    if(!tim_encode_dev)
    {
        return ERR_FAIL;
    }
    encode_direction = dev_control(tim_encode_dev,IOC_ENCODER_GET_DIRECTION,NULL);

    return encode_direction;
}

int32_t clean_encode_count()
{
    int32_t ret = ERR_OK;
    if(!tim_encode_dev)
    {
        return ERR_FAIL;
    }
    ret = dev_control(tim_encode_dev,IOC_TIMER_SET_COUNTER_ID,0);
    return ret;
}
