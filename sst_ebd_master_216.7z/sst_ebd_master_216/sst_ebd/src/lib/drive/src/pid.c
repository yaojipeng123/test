#include "pid.h"

pid_config_t pid;
pid_config_t pid_location;//位置环所用pid参数
pid_config_t pid_speed;//速度环所用pid参数

void dc_brush_pid_init()
{
	  /* 初始化参数 */
  pid.target_val=100.0;				
  pid.actual_val=0.0;
  pid.err=0.0;
  pid.err_last=0.0;
  pid.integral=0.0;

	pid.Kp = 5.0;
	pid.Ki = 2.0;
	pid.Kd = 0.0;
    /* 位置环相关初始化参数 具体pid值需要实测修改 */
  pid_location.target_val = 100.0;
  pid_location.actual_val=0.0;
  pid_location.err=0.0;
  pid_location.err_last=0.0;
  pid_location.integral=0.0;
  
	pid_location.Kp = 0.158;
	pid_location.Ki = 0.0;
	pid_location.Kd = 0.0;
  
  	/* 速度相关初始化参数 具体pid值需要实测修改*/
  pid_speed.target_val=100.0;				
  pid_speed.actual_val=0.0;
  pid_speed.err=0.0;
  pid_speed.err_last=0.0;
  pid_speed.integral=0.0;
  
	pid_speed.Kp = 30;
	pid_speed.Ki = 8;
	pid_speed.Kd = 0.04;
}


void set_p_i_d(float p, float i, float d)//单环控制使用
{
  pid.Kp = p;    // 设置比例系数 P
  pid.Ki = i;    // 设置积分系数 I
  pid.Kd = d;    // 设置微分系数 D
}

void set_p_i_d_plus(pid_config_t *pid ,float p,float i,float d)//多环控制使用 
{
  pid->Kp = p;    // 设置比例系数 P
  pid->Ki = i;    // 设置积分系数 I
  pid->Kd = d;    // 设置微分系数 D
}
void set_pid_target(float temp_val)//暂时保留
{
  pid.target_val = temp_val;    // 设置当前的目标值
}

void set_pid_target_plus(pid_config_t *pid, float temp_val)//多环控制使用 // 设置当前的目标值
{
  pid->target_val = temp_val;
}

float get_pid_target(void)//单环控制使用
{
  return pid.target_val;    // 获取当前的目标值
}

float get_pid_target_plus(pid_config_t *pid)//多环控制使用
{
  return pid->target_val;    // 获取当前的目标值
}

float pid_realize(float actual_val)//pid算法 需使用定时器周期调用该函数
{
    pid.err=pid.target_val-actual_val;
    pid.integral+=pid.err;
    pid.actual_val=pid.Kp*pid.err+pid.Ki*pid.integral+pid.Kd*(pid.err-pid.err_last);
    pid.err_last=pid.err;
    return pid.actual_val;
}

float location_pid_realize(float actual_val)//位置环pid算法
{
    pid_location.err=pid_location.target_val-actual_val;
    if((pid_location.err >= -20) && (pid_location.err <= 20))
    {
      pid_location.err = 0;
      pid_location.integral = 0;
    }
    
    pid_location.integral += pid_location.err;    // 误差累积
    pid_location.actual_val = pid_location.Kp*pid_location.err+pid_location.Ki*pid_location.integral+pid_location.Kd*(pid_location.err-pid_location.err_last);
    pid_location.err_last=pid_location.err;
    
    return pid_location.actual_val;
}

float speed_pid_realize(float actual_val)//速度环pid算法
{
    pid_speed.err=pid_speed.target_val-actual_val;

    if((pid_speed.err<0.2f )&& (pid_speed.err>-0.2f))
      pid_speed.err = 0.0f;

    pid_speed.integral += pid_speed.err;    // 误差累积

    pid_speed.actual_val = pid_speed.Kp*pid_speed.err+pid_speed.Ki*pid_speed.integral+pid_speed.Kd*(pid_speed.err-pid_speed.err_last);

    pid_speed.err_last=pid_speed.err;

    return pid_speed.actual_val;
}