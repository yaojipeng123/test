#include "types.h"
#include "stdio.h"

#include "hal_gpio.h"
#include "gpio_dev.h"
#include "dev.h"
#include "uart_dev.h"
#include "os_utils.h"
#include "os_task.h"
#include "os_queue.h"
#include "mic_linear_actuator.h"

#define MAX_BUF_LEN  32
dev_t *mic_linear_dev;

static uint8_t bcc_checksum(uint8_t *buf,uint8_t buf_led);
void uart_send(uint8_t len,uint8_t id,uint8_t cmd,uint8_t index,uint16_t data);
static void uart_send_single_ctl(uint8_t id,uint8_t para);
void uart_rcv(uint8_t *rcv_buf,uint8_t len);

int32_t mic_linear_init(const char *uart_name)
{
    int32_t ret = ERR_OK;
    mic_linear_dev = dev_find(uart_name);
    // mic_linear_dev = dev_find("uart0");
    if (!mic_linear_dev) {
        return ERR_FAIL;
    }
    ret = dev_open(mic_linear_dev,RX_INT|TX_POLLING|RS_232);
    return ret;
}

void mic_linear_set_id(uint8_t old_id,uint8_t new_id)//设置ID
{
    uart_send(0x03,old_id,CMD_WR_NR,INDEX_ID_INFO,new_id);//修改ID
    uart_send_single_ctl(new_id,SINGLE_CTL_SAVE);//新的ID存入flash
}
void mic_linear_work(uint8_t id)//启动控制
{
    uart_send_single_ctl(id,SINGLE_CTL_MOVE);
}
void mic_linear_estop(uint8_t id)//急停控制
{
    uart_send_single_ctl(id,SINGLE_CTL_ESTOP);
}
void mic_linear_query(uint8_t id)//查询信息
{
    uart_send_single_ctl(id,SINGLE_CTL_QUERY);
}
void mic_linear_clean(uint8_t id)//清除故障信息
{
    uart_send_single_ctl(id,SINGLE_CTL_CLEAN);
}


void mic_linear_write_location(uint8_t id,uint16_t location_data)//设定位置
{
    uart_send(0x04,id,CMD_WR_LOCATION,INDEX_TARGET_LOCATION_INFO,location_data);
}

// void mic_linear_read(uint8_t len,uint8_t id,uint8_t index,uint16_t data,uint8_t *rcv_buf)
// {
//     uart_send(len,id,CMD_RD,index,data);
//     uart_rcv(rcv_buf,len);
// }

// void mic_linear_write_location(uint8_t len,uint8_t id,uint8_t cmd,uint8_t index,uint16_t data)
// {
//     uart_send(len,id,cmd,index,data);
// }

// void mic_linear_write_follow(uint8_t len,uint8_t id,uint8_t cmd,uint8_t index,uint16_t data)
// {
//     uart_send(len,id,cmd,index,data);
// }


void uart_send(uint8_t len,uint8_t id,uint8_t cmd,uint8_t index,uint16_t data)
{
    uint8_t send_buf[MAX_BUF_LEN] = {0};
    uint8_t temp = 0;
    uint8_t data_len = len-2;
    uint8_t buf_len = 0;
    send_buf[buf_len++] = 0x55;
    send_buf[buf_len++] = 0xAA;
    send_buf[buf_len++] = len;
    send_buf[buf_len++] = id;
    send_buf[buf_len++] = cmd;
    send_buf[buf_len++] = index;
    for(int i=0;i<data_len;i++)
    {
        temp = data;
        send_buf[buf_len++] = temp;
        data = data>>8;
    }

    send_buf[buf_len] = bcc_checksum(send_buf,buf_len);

    dev_write(mic_linear_dev, send_buf, buf_len+1);
}

static void uart_send_single_ctl(uint8_t id,uint8_t para)//单控指令
{
    uint8_t send_buf[MAX_BUF_LEN] = {0};
    uint8_t temp = 0;
    uint8_t buf_len = 0;
    send_buf[buf_len++] = 0x55;
    send_buf[buf_len++] = 0xAA;
    send_buf[buf_len++] = SINGLE_CTL_LEN;
    send_buf[buf_len++] = id;
    send_buf[buf_len++] = CMD_WR_FUNCTION_CONTROL;
    send_buf[buf_len++] = 0x00;//参数1 默认0
    send_buf[buf_len++] = para;//参数2

    send_buf[buf_len++] = bcc_checksum(send_buf,buf_len);

    dev_write(mic_linear_dev, send_buf, buf_len);
}

int32_t uart_start_read_buf(uint8_t *buf)
{
    int32_t ret = ERR_OK;
    if (!mic_linear_dev) {
        return ERR_FAIL;
    }
    ret = dev_read(mic_linear_dev, buf, 22);
    return ret;
}

static uint8_t bcc_checksum(uint8_t *buf,uint8_t buf_len)
{
    uint8_t i = 0;
    uint8_t *temp;
    uint8_t bcc = 0;
    uint8_t len = buf_len;
    if(buf_len <= 2)
    {
        return 0;
    }

    for(int i=2;i<len;i++)
    {
        bcc = buf[i] + bcc;
    }
    return bcc;
}



