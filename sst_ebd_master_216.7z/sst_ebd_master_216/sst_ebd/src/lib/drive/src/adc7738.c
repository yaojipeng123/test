#include "types.h"
#include "cpu.h"
#include "stdio.h"
#include "adc7738.h"

// #include "sst_device.h"
// #include "vfsdev/spi_dev.h"
// #include "ddkc_log.h"
#include "errno.h"
#include "hal_spi.h"
#include "spi_dev.h"
#include "dev.h"
#include "hal_gpio.h"
#define SPI_MASTER 1
#define SPI_SLAVER 0

dev_t *spi_7738_handler;

static void ad7738_reset()
{
    uint8_t send_buf[4] = { 0xff, 0xff, 0xff, 0xff };
    uint8_t rcv_buf[4]  = { 0, 0, 0, 0 };
    spi_transfer_t spi_arg;
    spi_arg.port     = HAL_SPI_PORT0;
    spi_arg.tx_buf   = send_buf;
    spi_arg.rx_buf   = rcv_buf;
    spi_arg.buf_size = 4;
    dev_control(spi_7738_handler, IOC_SPI_SEND_RECV,
                (unsigned long)&spi_arg);
}

static void ad7738_set_value(uint8_t cmd, uint8_t val)
{
    uint8_t send_buf[2] = { 0, 0 };
    uint8_t rcv_buf[2]  = { 0, 0 };
    spi_transfer_t spi_arg;
    send_buf[0]      = cmd;
    send_buf[1]      = val;
    spi_arg.port     = HAL_SPI_PORT0;
    spi_arg.tx_buf   = send_buf;
    spi_arg.rx_buf   = rcv_buf;
    spi_arg.buf_size = 2;
    dev_control(spi_7738_handler, IOC_SPI_SEND_RECV,
                (unsigned long)&spi_arg);
}

uint8_t get_regvalue(uint8_t cmd)
{
    uint8_t send_buf[2] = { 0, 0 };
    uint8_t rcv_buf[2]  = { 0, 0 };
    spi_transfer_t spi_arg;
    send_buf[0]      = cmd;
    spi_arg.port     = HAL_SPI_PORT0;
    spi_arg.tx_buf   = send_buf;
    spi_arg.rx_buf   = rcv_buf;
    spi_arg.buf_size = 2;
    dev_control(spi_7738_handler, IOC_SPI_SEND_RECV,
                (unsigned long)&spi_arg);
    return rcv_buf[1];
}
int8_t adc7738_value_flag = 0;
int32_t dac7738_get_adc_val()
{
    int32_t value       = 0;
    uint8_t send_buf[6] = { 0, 0, 0, 0, 0, 0 };
    uint8_t rcv_buf[6]  = { 0, 0, 0, 0, 0, 0 };

    spi_transfer_t spi_arg;
    send_buf[0]      = CMD_GET_ADC_VALUE;
    spi_arg.port     = HAL_SPI_PORT0;
    spi_arg.tx_buf   = send_buf;
    spi_arg.rx_buf   = rcv_buf;
    spi_arg.buf_size = 6;
    hal_gpio_output_low(HAL_GPIO_136);
    dev_control(spi_7738_handler, IOC_SPI_SEND_RECV, (unsigned long)&spi_arg);
    hal_gpio_output_high(HAL_GPIO_136);
    // if(rcv_buf[1] & 0x80) {
    //     adc7738_value_flag = 1;
    //     value              = rcv_buf[3] + (rcv_buf[2] << 8) + (rcv_buf[1] << 16);
    // } else {
    //     adc7738_value_flag = -1;
    //     value              = rcv_buf[3] + (rcv_buf[2] << 8) + (rcv_buf[1] << 16);
    //     value              = 0x800000 - value;
    // }
    value = rcv_buf[3] + (rcv_buf[2] << 8) + (rcv_buf[1] << 16);
    // printf("voltage_value is %ld\n",voltage_value);
    return value;
}

int32_t spi_dac7738_init(const char *spi_name, unsigned long arg)
{
    int32_t ret       = ERR_OK;
    uint8_t rcv       = 0;
    uint8_t set_value = 0;
    spi_7738_handler  = dev_find(spi_name);
    if(!spi_7738_handler) {
        return ERR_FAIL;
    }
    dev_control(spi_7738_handler, IOC_SPI_SET_CONFIG, arg);
    ad7738_reset();
    // get_regvalue(0x78);
    rcv = get_regvalue(0x42);

    if((rcv & 0x0f) != 0x01) {
        return ERR_FAIL;
    }
    set_value = INPUT_MODE_DOUBLE | CHANNEL_ENABLE | INPUT_RANGE1;   //0x6D
    ad7738_set_value(CHANNEL0, set_value);
    set_value = CONTINUOUS_CONVERSION_MODE | ADC_24_BIT;   //0x22
    ad7738_set_value(MODE_SET_REGISTER, set_value);
    return ret;
}
