#include <types.h>
#include <stdio.h>
#include <stdarg.h>
#include <syscall.h>

static void putch(int ch, void *cnt)
{
    putchar(ch);
    ++(*(int*)cnt);
}

int vprintf(const char *fmt, va_list ap)
{
    int cnt = 0;
    vprintfmt(putch, &cnt, fmt, ap);
    return cnt;
}

int printf(const char *fmt, ...)
{
    va_list ap;
    int cnt;

    /* set ap as (&fmt + 1) */
    va_start(ap, fmt);
    cnt = vprintf(fmt, ap);
    /* set ap as NULL */
    va_end(ap);

    return cnt;
}
