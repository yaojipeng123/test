#include "stdio.h"
#include "stdlib.h"

typedef unsigned long __kernel_size_t;
typedef __kernel_size_t size_t1;

typedef int s32;
typedef s32 acpi_native_int;
//typedef char *va_list1;
#define _U      0x01 /* upper */
#define _L      0x02 /* lower */
#define _D      0x04 /* digit */
#define _C      0x08 /* cntrl */
#define _P      0x10 /* punct */
#define _S      0x20 /* white space (space/lf/tab) */
#define _X      0x40 /* hex digit */
#define _SP     0x80 /* hard space (0x20) */
#define INT_MAX ((int)(~0U >> 1))
unsigned char _ctype[] = {_C,       _C,      _C,      _C,      _C,      _C,
                          _C,       _C, /* 0-7 */
                          _C,       _C | _S, _C | _S, _C | _S, _C | _S, _C | _S,
                          _C,       _C, /* 8-15 */
                          _C,       _C,      _C,      _C,      _C,      _C,
                          _C,       _C, /* 16-23 */
                          _C,       _C,      _C,      _C,      _C,      _C,
                          _C,       _C, /* 24-31 */
                          _S | _SP, _P,      _P,      _P,      _P,      _P,
                          _P,       _P, /* 32-39 */
                          _P,       _P,      _P,      _P,      _P,      _P,
                          _P,       _P, /* 40-47 */
                          _D,       _D,      _D,      _D,      _D,      _D,
                          _D,       _D, /* 48-55 */
                          _D,       _D,      _P,      _P,      _P,      _P,
                          _P,       _P, /* 56-63 */
                          _P,       _U | _X, _U | _X, _U | _X, _U | _X, _U | _X,
                          _U | _X,  _U, /* 64-71 */
                          _U,       _U,      _U,      _U,      _U,      _U,
                          _U,       _U, /* 72-79 */
                          _U,       _U,      _U,      _U,      _U,      _U,
                          _U,       _U, /* 80-87 */
                          _U,       _U,      _U,      _P,      _P,      _P,
                          _P,       _P, /* 88-95 */
                          _P,       _L | _X, _L | _X, _L | _X, _L | _X, _L | _X,
                          _L | _X,  _L, /* 96-103 */
                          _L,       _L,      _L,      _L,      _L,      _L,
                          _L,       _L, /* 104-111 */
                          _L,       _L,      _L,      _L,      _L,      _L,
                          _L,       _L, /* 112-119 */
                          _L,       _L,      _L,      _P,      _P,      _P,
                          _P,       _C, /* 120-127 */
                          0,        0,       0,       0,       0,       0,
                          0,        0,       0,       0,       0,       0,
                          0,        0,       0,       0, /* 128-143 */
                          0,        0,       0,       0,       0,       0,
                          0,        0,       0,       0,       0,       0,
                          0,        0,       0,       0, /* 144-159 */
                          _S | _SP, _P,      _P,      _P,      _P,      _P,
                          _P,       _P,      _P,      _P,      _P,      _P,
                          _P,       _P,      _P,      _P, /* 160-175 */
                          _P,       _P,      _P,      _P,      _P,      _P,
                          _P,       _P,      _P,      _P,      _P,      _P,
                          _P,       _P,      _P,      _P, /* 176-191 */
                          _U,       _U,      _U,      _U,      _U,      _U,
                          _U,       _U,      _U,      _U,      _U,      _U,
                          _U,       _U,      _U,      _U, /* 192-207 */
                          _U,       _U,      _U,      _U,      _U,      _U,
                          _U,       _P,      _U,      _U,      _U,      _U,
                          _U,       _U,      _U,      _L, /* 208-223 */
                          _L,       _L,      _L,      _L,      _L,      _L,
                          _L,       _L,      _L,      _L,      _L,      _L,
                          _L,       _L,      _L,      _L, /* 224-239 */
                          _L,       _L,      _L,      _L,      _L,      _L,
                          _L,       _P,      _L,      _L,      _L,      _L,
                          _L,       _L,      _L,      _L}; /* 240-255 */
#define __ismask(x) (_ctype[(int)(unsigned char)(x)])
#define isspace(c)  ((__ismask(c) & (_S)) != 0)
#define isxdigit(c)                                           \
    (('0' <= (c) && (c) <= '9') || ('a' <= (c) && (c) <= 'f') \
     || ('A' <= (c) && (c) <= 'F'))

#define isdigit(c) ((__ismask(c) & (_D)) != 0)
#define islower(c) ((__ismask(c) & (_L)) != 0)
#define _AUPBND    (sizeof(acpi_native_int) - 1)
#define _ADNBND    (sizeof(acpi_native_int) - 1)

static long simple_strtol(const char *cp, char **endp, unsigned int base);
static unsigned long simple_strtoul(const char *cp, char **endp,
                                    unsigned int base);
static unsigned long long simple_strtoull(const char *cp, char **endp,
                                          unsigned int base);
static unsigned char __toupper(unsigned char c);
static int vsscanf1(const char *buf, const char *fmt, va_list args);
static unsigned char __toupper(unsigned char c)
{
    if (islower(c))
        c -= 'a' - 'A';
    return c;
}
#define toupper(c) __toupper(c)

static unsigned long simple_strtoul(const char *cp, char **endp,
                                    unsigned int base)
{
    unsigned long result = 0, value;

    if (!base) {
        base = 10;
        if (*cp == '0') {
            base = 8;
            cp++;
            if ((*cp == 'x') && isxdigit(cp[1])) {
                cp++;
                base = 16;
            }
        }
    }
    while (isxdigit(*cp)
           && (value = isdigit(*cp) ? *cp - '0' : toupper(*cp) - 'A' + 10)
               < base) {
        result = result * base + value;
        cp++;
    }
    if (endp)
        *endp = (char *)cp;
    return result;
}
static long long int simple_strtoll(const char *cp, char **endp,
                                    unsigned int base)
{
    //long long Temp = 0;
    if (*cp == '-') {
        //Temp = Temp - simple_strtoull(cp + 1, endp, base);
        return 0 - simple_strtoull(cp + 1, endp, base);
    }
    return simple_strtoull(cp, endp, base);
}

static long simple_strtol(const char *cp, char **endp, unsigned int base)
{
    //long int Temp = 0;
    if (*cp == '-') {
        //Temp = Temp - simple_strtoul(cp + 1, endp, base);
        return 0 - simple_strtoul(cp + 1, endp, base);
    }
    return simple_strtoul(cp, endp, base);
}
static int skip_atoi(const char **s)
{
    int i = 0;

    while (isdigit(**s))
        i = i * 10 + *((*s)++) - '0';
    return i;
}
static unsigned long long simple_strtoull(const char *cp, char **endp,
                                          unsigned int base)
{
    unsigned long long result = 0, value;

    if (!base) {
        base = 10;
        if (*cp == '0') {
            base = 8;
            cp++;
            if ((*cp == 'x') && isxdigit(cp[1])) {
                cp++;
                base = 16;
            }
        }
    }
    while (isxdigit(*cp)
           && (value = isdigit(*cp)
                   ? *cp - '0'
                   : (islower(*cp) ? toupper(*cp) : *cp) - 'A' + 10)
               < base) {
        result = result * base + value;
        cp++;
    }
    if (endp)
        *endp = (char *)cp;
    return result;
}

static int vsscanf1(const char *buf, const char *fmt, va_list args)
{
    const char *str = buf;
    char *next;
    char digit;
    int num = 0;
    int qualifier;
    int base;
    int field_width;
    int is_sign = 0;

    while (*fmt && *str) {
        /* skip any white space in format */
        /* white space in format matchs any amount of
		* white space, including none, in the input.
		*/
        if (isspace(*fmt)) {
            while (isspace(*fmt))
                ++fmt;
            while (isspace(*str))
                ++str;
        }

        /* anything that is not a conversion must match exactly */
        if (*fmt != '%' && *fmt) {
            if (*fmt++ != *str++)
                break;
            continue;
        }

        if (!*fmt)
            break;
        ++fmt;

        /* skip this conversion.
		* advance both strings to next white space
		*/
        if (*fmt == '*') {
            while (!isspace(*fmt) && *fmt)
                fmt++;
            while (!isspace(*str) && *str)
                str++;
            continue;
        }

        /* get field width */
        field_width = -1;
        if (isdigit(*fmt))
            field_width = skip_atoi(&fmt);

        /* get conversion qualifier */
        qualifier = -1;
        if (*fmt == 'h' || *fmt == 'l' || *fmt == 'L' || *fmt == 'Z'
            || *fmt == 'z') {
            qualifier = *fmt;
            fmt++;
        }
        base = 10;
        is_sign = 0;

        if (!*fmt || !*str)
            break;

        switch (*fmt++) {
            case 'c': {
                char *s = (char *)va_arg(args, char *);
                if (field_width == -1)
                    field_width = 1;
                do {
                    *s++ = *str++;
                } while (field_width-- > 0 && *str);
                num++;
            }
                continue;
            case 's': {
                char *s = (char *)va_arg(args, char *);
                if (field_width == -1)
                    field_width = INT_MAX;
                /* first, skip leading white space in buffer */
                while (isspace(*str))
                    str++;

                /* now copy until next white space */
                while (*str && !isspace(*str) && field_width--) {
                    *s++ = *str++;
                }
                *s = '\0';
                num++;
            }
                continue;
            case 'n':
                /* return number of characters read so far */
                {
                    int *i = (int *)va_arg(args, int *);
                    *i = str - buf;
                }
                continue;
            case 'o':
                base = 8;
                break;
            case 'x':
            case 'X':
                base = 16;
                break;
            case 'i':
                base = 0;
                break;
            case 'd':
                is_sign = 1;
                break;
            case 'u':
                break;
            case '%':
                /* looking for '%' in str */
                if (*str++ != '%')
                    return num;
                continue;
                break;
            default:
                /* invalid format; stop here */
                return num;
                break;
        }

        /* have some sort of integer conversion.
		* first, skip white space in buffer.
		*/
        while (isspace(*str))
            str++;

        digit = *str;
        if (is_sign && digit == '-')
            digit = *(str + 1);

        if (!digit || (base == 16 && !isxdigit(digit))
            || (base == 10 && !isdigit(digit))
            || (base == 8 && (!isdigit(digit) || digit > '7'))
            || (base == 0 && !isdigit(digit)))
            break;

        switch (qualifier) {
            case 'h':
                if (is_sign) {
                    short *s = (short *)va_arg(args, short *);
                    *s = (short)simple_strtol(str, &next, base);
                } else {
                    unsigned short *s =
                        (unsigned short *)va_arg(args, unsigned short *);
                    *s = (unsigned short)simple_strtoul(str, &next, base);
                }
                break;
            case 'l':
                if (is_sign) {
                    long *l = (long *)va_arg(args, long *);
                    *l = simple_strtol(str, &next, base);
                } else {
                    unsigned long *l =
                        (unsigned long *)va_arg(args, unsigned long *);
                    *l = simple_strtoul(str, &next, base);
                }
                break;
            case 'L':
                if (is_sign) {
                    long long *l = (long long *)va_arg(args, long long *);
                    *l = simple_strtoll(str, &next, base);
                } else {
                    unsigned long long *l = (unsigned long long *)va_arg(
                        args, unsigned long long *);
                    *l = simple_strtoull(str, &next, base);
                }
                break;
            case 'Z':
            case 'z': {
                size_t1 *s = (size_t1 *)va_arg(args, size_t1 *);
                *s = (size_t1)simple_strtoul(str, &next, base);
            } break;
            default:
                if (is_sign) {
                    int *i = (int *)va_arg(args, int *);
                    *i = (int)simple_strtol(str, &next, base);
                } else {
                    unsigned int *i =
                        (unsigned int *)va_arg(args, unsigned int *);
                    *i = (unsigned int)simple_strtoul(str, &next, base);
                }
                break;
        }
        num++;

        if (!next)
            break;
        str = next;
    }
    return num;
}

int sscanf(const char *buf, const char *fmt, ...)
{
    va_list args;
    int i;

    va_start(args, fmt);
    i = vsscanf1(buf, fmt, args);
    va_end(args);
    return i;
}
