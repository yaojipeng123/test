#include <strings.h>
#include <ctype.h>

int strncasecmp(const char *s1, const char *s2, size_t n)
{
    int d = 0;
    for (; n != 0; n--) {
        const int c1 = tolower(*s1++);
        const int c2 = tolower(*s2++);
        if (((d = c1 - c2) != 0) || (c2 == '\0'))
            break;
    }
    return d;
}