#include <syscall.h>

int __attribute__((weak)) putchar(int c)
{
    return c;
}
