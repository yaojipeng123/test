/*
 * Andy Wilson, 2-Oct-89.
 */

#include <stdlib.h>
#include <string.h>

int atoi(const char *s)
{
    return (int)strtol(s, NULL, 10);
}
