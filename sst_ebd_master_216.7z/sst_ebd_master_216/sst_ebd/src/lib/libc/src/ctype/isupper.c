#include <ctype.h>

#define UC(c) ((unsigned char)(c))

char isupper(unsigned char c)
{
    if (c >= UC('A') && c <= UC('Z'))
        return 1;
    return 0;
}