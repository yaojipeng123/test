#include <ctype.h>

int tolower(int c)
{
    if ((unsigned char)c <= 0x7f)
        return isupper(c) ? c - 'A' + 'a' : c;
    else
        return c;
}