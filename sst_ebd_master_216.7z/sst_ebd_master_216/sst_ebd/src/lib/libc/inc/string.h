#ifndef _STRING_H
#define _STRING_H

#include <types.h>

size_t strlen(const char *s);
size_t strnlen(const char *s, size_t size);
char *strcpy(char *dst, const char *src);
char *strncpy(char *dst, const char *src, size_t size);
char *strcat(char *dst, const char *src);
size_t strlcpy(char *dst, const char *src, size_t size);
int strcmp(const char *s1, const char *s2);
int strncmp(const char *s1, const char *s2, size_t size);
int stricmp(const char *s1, const char *s2);
char *strchr(const char *s, int c);
char *strfind(const char *s, char c);

void *memset(void *dst, int c, size_t len);
void *memcpy(void *dst, const void *src, size_t len);
void *memmove(void *dst, const void *src, size_t len);
int memcmp(const void *s1, const void *s2, size_t len);
void *memfind(const void *s, int c, size_t len);

long strtol(const char *s, char **endptr, int base);

//strstr.c
char *strstr(const char *, const char *);
char *strrchr(const char *, int);

//strtok.c
char *strtok(char *s, const char *delim);
char *strtok_r(char *s, const char *delim, char **last);

//strcspn.c
size_t strcspn(const char *s1, const char *s2);

//strncasecmp.c
int strncasecmp(const char *s1, const char *s2, size_t n);
char *strncat(char *s1, const char *s2, size_t n);
#endif //_STRING_H
