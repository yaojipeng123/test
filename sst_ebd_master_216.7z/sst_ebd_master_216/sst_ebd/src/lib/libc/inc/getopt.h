#ifndef _GETOPT_H
#define _GETOPT_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stdio.h"
#include "stdlib.h"
#include "assert.h"
#include "string.h"

extern int opterr;   /* if error message should be printed */
extern int optind;   /* index into parent argv vector */
extern int optopt;   /* character checked for validity */
extern int optreset; /* reset getopt */
extern char *optarg; /* argument associated with option */

#define __P(x)         x
#define _DIAGASSERT(x) assert(x)

#define BADCH  (int)'?'
#define BADARG (int)':'
#define EMSG   ""

struct option {
    const char *name;
    int has_arg;
    int *flag;
    int val;
};

#define no_argument       0
#define required_argument 1
#define optional_argument 2

void getopt_reset(void);
int getopt(int argc, char *const argv[], const char *opts);
int getopt_long(int, char **, const char *, const struct option *, int *);

#ifdef __cplusplus
}
#endif

#endif /* _GETOPT_H */