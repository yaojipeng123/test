#ifndef _CTYPE_H
#define _CTYPE_H

int tolower(int c);
char isupper(unsigned char c);
int isspace(int c);
char isdigit(unsigned char c);
int isalpha(int c);
int toupper(int c);

#endif /* ctype.h  */