#ifndef _STDLIB_H
#define _STDLIB_H

#include <stddef.h>
typedef int cmp_t(const void *, const void *); /* must needed for qsort */

int rand(void);
void srand(unsigned int i);

long atol(const char *s);
int atoi(const char *s);
void qsort(void *a, size_t n, size_t es, cmp_t *cmp);

long strtol(const char *nptr, char **endptr, int base);
double atof(const char *s);
char *__itoa(int value, char *str, int base);
char *itoa(int value, char *str, int base);
char *__utoa(unsigned value, char *str, int base);
char *utoa(unsigned value, char *str, int base);
long strtol(const char *nptr, char **endptr, register int base);
long long strtoll(const char *nptr, char **endptr, register int base);
#endif /* !_STDLIB_H */
