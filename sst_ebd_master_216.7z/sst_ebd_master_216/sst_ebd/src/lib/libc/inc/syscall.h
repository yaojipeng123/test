/* POSIX-like interface */

#ifndef _SYSCALL_H
#define _SYSCALL_H

int putchar(int c);

#endif //_SYSCALL_H
