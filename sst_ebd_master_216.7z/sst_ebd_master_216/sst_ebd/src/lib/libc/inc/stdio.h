#ifndef _STDIO_H
#define _STDIO_H

#include <stdarg.h>

#define EOF              (-1)
#define fprintf(fd, ...) printf(__VA_ARGS__)

// printfmt.c
void printfmt(void (*putch)(int, void *), void *putdat, const char *fmt, ...);
void vprintfmt(void (*putch)(int, void *), void *putdat, const char *fmt,
               va_list);
int snprintf(char *str, int size, const char *fmt, ...);
int vsnprintf(char *str, int size, const char *fmt, va_list);

// printf.c
int printf(const char *fmt, ...);
int vprintf(const char *fmt, va_list);

//sscanf.c
int sscanf(const char *buf, const char *fmt, ...);

#endif /* !_STDIO_H */
