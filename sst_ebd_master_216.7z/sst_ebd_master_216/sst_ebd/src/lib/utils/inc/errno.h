#ifndef ERRNO_H
#define ERRNO_H

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    /* successful */
    ERR_OK,
    /* invalid parameters */
    ERR_INVAL,
    /* out of memory */
    ERR_NOMEM,
    /* not supported */
    ERR_NOSUPP,
    /* not exist */
    ERR_NOT_EXIST,
    /* again */
    ERR_AGAIN,
    /* dev not ready */
    ERR_NOT_READY,
    /* already exist */
    ERR_EXIST,
    /* busy */
    ERR_BUSY,
    /* pending */
    ERR_PENDING,
    /* failed */
    ERR_FAIL,
    /* timeout */
    ERR_TIMEOUT,
} ERR_TYPE;

#ifdef __cplusplus
}
#endif

#endif /* ERRNO_H */
