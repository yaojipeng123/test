#ifndef _UTILS_H
#define _UTILS_H

#define likely(x)   __builtin_expect((x), 1)
#define unlikely(x) __builtin_expect((x), 0)

// Rounding operations (efficient when n is a power of 2)
// Round down to the nearest multiple of n
#ifndef ROUNDDOWN
#define ROUNDDOWN(a, n)               \
    ({                                \
        uint32_t __a = (uint32_t)(a); \
        (typeof(a))(__a - __a % (n)); \
    })
#endif

// Round up to the nearest multiple of n
#ifndef ROUNDUP
#define ROUNDUP(a, n)                                         \
    ({                                                        \
        uint32_t __n = (uint32_t)(n);                         \
        (typeof(a))(ROUNDDOWN((uint32_t)(a) + __n - 1, __n)); \
    })
#endif

// Efficient min and max operations
#ifndef MIN
#define MIN(_a, _b)             \
    ({                          \
        typeof(_a) __a = (_a);  \
        typeof(_b) __b = (_b);  \
        __a <= __b ? __a : __b; \
    })
#endif

#ifndef MAX
#define MAX(_a, _b)             \
    ({                          \
        typeof(_a) __a = (_a);  \
        typeof(_b) __b = (_b);  \
        __a >= __b ? __a : __b; \
    })
#endif

#ifndef CLAMP
#define CLAMP(a, lo, hi) MIN(MAX(a, lo), hi)
#endif

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(a) (sizeof(a) / sizeof(a[0]))
#endif

#ifndef EXTRACT_FIELD
#define EXTRACT_FIELD(val, which) (((val) & (which)) / ((which) & ~((which)-1)))
#endif

#ifndef INSERT_FIELD
#define INSERT_FIELD(val, which, fieldval) \
    (((val) & ~(which)) | ((fieldval) * ((which) & ~((which)-1))))
#endif

#ifndef STR
#define STR(x) XSTR(x)
#endif
#ifndef XSTR
#define XSTR(x) #x
#endif

#ifndef UNUSED
#define UNUSED(x) (void)x
#endif

#ifndef BIT
#define BIT(x) (1u << (x))
#endif

#ifndef NTOHL
#define NTOHL(x)                                                      \
    (((x & 0xff) << 24) | ((x & 0xff00) << 8) | ((x & 0xff0000) >> 8) \
     | ((x & 0xff000000) >> 24))
#endif

#ifndef NTOHS
#define NTOHS(x) (((x & 0xff) << 8) | ((x & 0xff00) >> 8))
#endif

#ifndef HTONL
#define HTONL NTOHL
#endif

#ifndef HTONS
#define HTONS NTOHS
#endif

/// endian int32/uint32 reverse uint8 point
#ifndef END32_REVS_P8
#define END32_REVS_P8(p8_o,p8_i) \
    do { \
        p8_o[0] = p8_i[3]; \
        p8_o[1] = p8_i[2]; \
        p8_o[2] = p8_i[1]; \
        p8_o[3] = p8_i[0]; \
    } while(0)
#endif

/* TBD. need to define this macro to force crash function of gcc */

/// Macro to get a structure from one of its structure field
#define CONTAINER_OF(ptr, type, member)    \
    ((type *)( (char *)ptr - offsetof(type,member) ))

#endif /* _UTILS_H */
