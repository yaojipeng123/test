#ifndef RING_FIFO_H
#define RING_FIFO_H

struct ring_fifo {
    uint32_t capacity;
    uint8_t *data;
    uint32_t reader;
    uint32_t writer;
};

int32_t ring_fifo_init(struct ring_fifo *r, uint8_t *data, uint32_t len);

int32_t ring_fifo_enqueue(struct ring_fifo *r, const void *data, uint32_t sz);


int32_t ring_fifo_dequeue(struct ring_fifo *r, void *data, uint32_t sz);

bool ring_fifo_is_full(struct ring_fifo *r);

bool ring_fifo_is_empty(struct ring_fifo *r);

#endif //RING_FIFO_H
