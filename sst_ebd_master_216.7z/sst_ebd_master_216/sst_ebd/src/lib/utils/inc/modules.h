#ifndef _LIB_UTILS_MODULES_H
#define _LIB_UTILS_MODULES_H

#include "types.h"

#ifdef __cplusplus
extern "C" {
#endif

/* define module id for each module
 */
enum MODULE_ID_E {
    
    OS_MID,
    LIB_MID,
    MAX_MID_NUM = 0xFF,
};

typedef uint16_t module_id_t;

const char *modules_string(module_id_t mid);

#ifdef __cplusplus
}
#endif

#endif   // _LIB_UTILS_MODULES_H
