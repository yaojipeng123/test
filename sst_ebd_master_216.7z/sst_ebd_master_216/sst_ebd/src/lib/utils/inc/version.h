#ifndef _VERSION_H
#define _VERSION_H

/* The major version 5 bits: 0~31*/
#ifndef FIRMWARE_VERSION_MAJOR
#define FIRMWARE_VERSION_MAJOR (0)
#endif

/* The minor version 7 bits: 0~127*/
#ifndef FIRMWARE_VERSION_MINOR
#define FIRMWARE_VERSION_MINOR (0)
#endif

/* The micro version 4 bits: 0~15*/
#ifndef FIRMWARE_VERSION_MICRO
#define FIRMWARE_VERSION_MICRO (0)
#endif

/* The build version 16 bits: 0~65535*/
#ifndef FIRMWARE_VERSION_BUILD
#define FIRMWARE_VERSION_BUILD (0)
#endif

/* Numerically encoded version */
#define FIRMWARE_VERSION_HEX ((FIRMWARE_VERSION_MAJOR << 27) |  \
                                  (FIRMWARE_VERSION_MINOR << 20) |  \
                                  (FIRMWARE_VERSION_MICRO << 16) |  \
                                  (FIRMWARE_VERSION_BUILD ))

#endif /* _VERSION_H */
