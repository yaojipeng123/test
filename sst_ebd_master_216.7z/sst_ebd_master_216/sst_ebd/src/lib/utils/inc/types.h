#ifndef _TYPES_H
#define _TYPES_H

#include "utils.h"
#include "errno.h"

/* Get bool, true and false.
 * If using GCC then get stdbool, otherwise create definitions here,
 */
#if defined(__GNUC__) || defined(C99)
#include <stdbool.h>
#elif defined(__cplusplus)
/* bool is already defined in C++ */
#else
enum { false, true };
typedef _Bool bool;
#endif

typedef bool bool_t;

// Use meaningful names when bool used for success/failure, e.g. for function returns.
// #define SUCCESS true
// #define FAILURE false

#if defined(__GNUC__) || defined(C99)
#include <stdint.h>
#include <stddef.h>
#else
typedef signed char int8_t;
typedef short       int16_t;
typedef int         int32_t;
typedef long long   int64_t;

typedef unsigned char      uint8_t;
typedef unsigned short     uint16_t;
typedef unsigned int       uint32_t;
typedef unsigned long long uint64_t;

#define NULL ((void*)0)
#endif

#define MAX_UINT8  0xFF
#define MAX_UINT16 0xFFFF
#define MAX_UINT32 0xFFFFFFFF
#define MAX_UINT64 0xFFFFFFFFFFFFFFFFULL
#define MIN_INT16  (-0x8000)
#define MAX_INT16  (0x7FFF)

#endif /* _TYPES_H */
