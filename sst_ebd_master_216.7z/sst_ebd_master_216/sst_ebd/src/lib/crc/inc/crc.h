#ifndef LIB_CRC_H
#define LIB_CRC_H

#ifdef __cplusplus
extern "C" {
#endif

uint32_t getcrc32_update(uint32_t init_vect, uint8_t *buffer, uint32_t len);
uint32_t getcrc32(uint8_t *buffer, uint32_t len);
uint32_t getcrc24_update(uint32_t init_vect, uint8_t *buffer, uint32_t len);
uint32_t getcrc24(uint8_t *buffer, uint32_t len);
uint16_t getcrc16_update(uint16_t init_vect, uint8_t *buffer, uint32_t len);
uint16_t getcrc32_h16(uint8_t *buffer, uint32_t len);
uint16_t getcrc16(uint8_t *buffer, uint32_t len);
uint16_t getcrc16_ccitt_update(uint16_t init_vect, uint8_t *buffer,
                               uint32_t len);
uint16_t getcrc16_ccitt(uint8_t *buffer, uint32_t len);
uint8_t getcrc8_update(uint8_t init_vect, uint8_t *buffer, uint32_t len);
uint8_t getcrc8(uint8_t *buffer, uint32_t len);

#ifdef __cplusplus
}
#endif

#endif /* LIB_CRC_H */
