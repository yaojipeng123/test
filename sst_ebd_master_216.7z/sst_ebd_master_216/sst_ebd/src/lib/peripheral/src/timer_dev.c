#include "types.h"
#include "stdio.h"
#include "string.h"

#include "cpu.h"
#include "log.h"

#include "timer_dev.h"
#include "hal_timer.h"
#include "modules.h"
#include "dev.h"

#include "os_lock.h"
#include "os_mem.h"

#define TIM_NUM                  4
#define TIMER_DEVICE_NUMBER      4
#define TIMER_DEVICE_NAME_FORMAT "timer%d"

typedef struct timer_status {
    int8_t port;
    bool_t inited;
    bool_t started;
    timer_alarm_t config;
} timer_status_t;

static timer_status_t timer_status_info[TIM_NUM];
// static int32_t timer_cb(void *data)
// {
//     printf("************timer cb************\n");
//     return 0;
// }

int32_t timer_device_close(dev_t *dev)
{
    int ret = ERR_OK;
    timer_alarm_t *alarm = (timer_alarm_t *)dev->user_data;
    timer_status_t *alarm_status = CONTAINER_OF(alarm, timer_status_t, config);
    if (alarm_status->started) {
        hal_timer_stop(alarm_status->port);
    }
    ret = hal_timer_delete(alarm_status->port);
    return ret;
}

int32_t timer_ctl_device(dev_t *dev, int cmd, unsigned long arg)
{
    int32_t ret = ERR_OK;

    timer_alarm_t *alarm = (timer_alarm_t *)dev->user_data;
    timer_status_t *alarm_status = CONTAINER_OF(alarm, timer_status_t, config);

    if (!alarm || !alarm_status) {
        return ERR_INVAL;
    }
    // os_acquire_mutex(timer_priv->m);
    switch (cmd) {
        case IOC_TIMER_CONTROL:
            if (arg == IO_TIMER_START) {
                if (!alarm_status->started) {
                    ret = hal_timer_start(alarm_status->port);
                    alarm_status->started = ret ? false : true;
                } else {
                    //log
                }
            } else {
                if (alarm_status->started) {
                    ret = hal_timer_stop(alarm_status->port);
                    alarm_status->started = ret ? true : false;

                }
            }
            // if (ret) {
            //     // printf("timer control[%ld] failed, ret:%d\r\n", arg, ret);
            // }
            break;
        case IOC_TIMER_GET_TIMER:
            ret = hal_timer_get_time();
            break;
        case IOC_TIMER_GET_COUNTER_ID:
            ret = hal_timer_get_counter_id(alarm_status->port);
            break;
        case IOC_ENCODER_GET_DIRECTION:
            ret = hal_encoder_get_direction(alarm_status->port);
            break;
        case IOC_TIMER_SET_COUNTER_ID:
            ret = hal_timer_set_counter_id(alarm_status->port,arg);
            break;
        case IOC_HW_TIMER_DELAY_US:
            hal_timer_delay_us(arg);
            break;
        default:
            LOG_INFO(LOG_ID,"invalid cmd:%d\r\n",cmd);
            break;
    }
    // os_release_mutex(timer_priv->m);
    return ret;
}

static int32_t timer_device_open(dev_t *dev,uint32_t flags)
{
    int32_t ret = ERR_OK;

    timer_alarm_t *alarm = (timer_alarm_t *)dev->user_data;
    timer_status_t *alarm_status = CONTAINER_OF(alarm, timer_status_t, config);

    if (!alarm || !alarm_status) {
        return ERR_INVAL;
    }
    // os_acquire_mutex(timer_priv->m);//暂时不需要使用

    if (alarm_status->inited) {
        return ERR_INVAL;
    }
    if(flags == TIM_NORMAL)
    {
        ret = hal_timer_create(&alarm_status->port, alarm->period, alarm->repeat,
                           alarm->cb, alarm->data);
    }else if(flags == TIM_ENCODE)
    {
        ret = hal_timer_encode_init(&alarm_status->port);
    }
    

    if (ret) {
        LOG_INFO(LOG_ID,"hal_uart_init failed,ret:%d\r\n",ret);
        // os_release_mutex(uart_priv->m);
        return ERR_FAIL;
    }
    alarm_status->inited = true;

    // os_release_mutex(uart_priv->m);

    return ERR_OK;
}

static dev_ops_t timer_device_ops = {
    .init = NULL,
    .open = timer_device_open,
    .close = NULL,
    .read = NULL,
    .write = NULL,
    .control = timer_ctl_device,
};

int32_t timer_device_init(void)
{
    int32_t ret = ERR_OK;

    for (uint32_t i = 0; i < TIMER_DEVICE_NUMBER; i++) {
        dev_t *dev = os_mem_malloc(LIB_MID, sizeof(dev_t));
        if (!dev) {
            goto out;
        }
        timer_status_t *timer_priv = os_mem_malloc(LIB_MID, sizeof(timer_status_t));

        if (!timer_priv) {
            os_mem_free(dev);
            ret = ERR_FAIL;
            goto out;
        }

        os_mutex_h m = os_create_mutex(LIB_MID);

        if (!m) {
            os_mem_free(timer_priv);
            os_mem_free(dev);
            goto out;
        }

        memset(timer_priv, 0x0, sizeof(timer_status_t));
        timer_alarm_t alarm = timer_priv->config;
        // timer_priv->port = (HAL_TIMER_PORT0 + i);
        // timer_priv->period = 0;;
        // timer_priv->repeat = 0;
        // timer_priv->started = 0;

        snprintf(dev->node_name, DEV_NAME_MAX_LEN, TIMER_DEVICE_NAME_FORMAT, i);

        dev->ops = &timer_device_ops;
        dev->user_data = (void *)&alarm;

        dev_register(dev);

    }

out:
    return ret;
}
