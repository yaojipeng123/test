#include "types.h"
#include "stdio.h"
#include "string.h"
#include "log.h"
#include "modules.h"
#include "dev.h"

#include "os_lock.h"
#include "os_mem.h"

#include "hal_uart.h"
#include "uart_dev.h"
#include "hal_gpio.h"
#include "gpio_dev.h"

#include "ring_fifo.h"

#define UART_DEVICE_NUMBER      3
#define UART_DEVICE_NAME_FORMAT "uart%d"

#define UART_DEVICE_RX_BUF_SZ 1024

// typedef struct serial_fifo {
//     uint32_t buf_sz;
//     uint8_t *buffer;
//     uint16_t put_index, get_index;
//     bool_t is_full;
// } serial_fifo_t;
typedef struct uart_ctxt_t {

    HAL_UART_PORT port;
    os_mutex_h m;
    os_sem_h sem_tx;
    os_sem_h sem_rx;
    uint32_t ref_cnt;
    bool_t enable_rx_it;
    bool_t enable_tx_it;
    HAL_UART_TYPE type;
    // void *serial_rx;
    struct ring_fifo rb;
} uart_ctxt_t;

// uint8_t rs485_re_pin[UART_DEVICE_NUMBER] = {0};
static uart_ctxt_t *uart_ctxt[UART_DEVICE_NUMBER];

/**
 * Calculate fifo data length.
 *
 * @param fifo the data fifo of serial device
 *
 * @return length
 */
// static inline uint32_t _serial_fifo_calc_data_len(serial_fifo_t *fifo)
// {
//     uint32_t size;
//     if (fifo->put_index == fifo->get_index) {
//         size = (fifo->is_full == false) ? 0 : fifo->buf_sz;
//     } else if (fifo->put_index > fifo->get_index) {
//         size = fifo->put_index - fifo->get_index;
//     } else {
//         size = fifo->buf_sz - (fifo->get_index - fifo->put_index);
//     }

//     return size;
// }

// static inline void _serial_fifo_push_data(serial_fifo_t *fifo, uint8_t ch)
// {
//     fifo->buffer[fifo->put_index] = ch;
//     fifo->put_index += 1;
//     if (fifo->put_index >= fifo->buf_sz)
//         fifo->put_index = 0;
// }

// static inline uint8_t _serial_fifo_pop_data(serial_fifo_t *fifo)
// {
//     uint8_t ch;

//     ch = fifo->buffer[fifo->get_index];
//     fifo->get_index += 1;
//     if (fifo->get_index >= fifo->buf_sz)
//         fifo->get_index = 0;

//     return ch;
// }

static uart_ctxt_t *uart_device_get_ctxt(HAL_UART_PORT port)
{
    for (uint32_t i = 0; i < ARRAY_SIZE(uart_ctxt); i++) {
        if (uart_ctxt[i] != NULL && uart_ctxt[i]->port == port) {
            return uart_ctxt[i];
        }
    }

    return NULL;
}

void rs485_receive_callback(HAL_UART_PORT port)
{

    uart_ctxt_t *ctxt = uart_device_get_ctxt(port);
    os_post_semaphore_from_isr(ctxt->sem_rx);
}

void receive_callback(HAL_UART_PORT port)
{

    uart_ctxt_t *ctxt = uart_device_get_ctxt(port);
    int ch = -1;
    // struct serial_fifo* rx_fifo;
    // rx_fifo = (serial_fifo_t*)ctxt->serial_rx;

    while (1) {
        ch = hal_uart_getc(port);

        if (ch == -1)
            break;

        // /* if fifo is full, discard one byte first */
        // if (rx_fifo->is_full == true) {
        //     rx_fifo->get_index += 1;
        //     if (rx_fifo->get_index >= rx_fifo->buf_sz)
        //         rx_fifo->get_index = 0;
        // }
        // /* push a new data */
        // _serial_fifo_push_data(rx_fifo, ch);

        // /* if put index equal to read index, fifo is full */
        // if (rx_fifo->put_index == rx_fifo->get_index) {
        //     rx_fifo->is_full = true;
        // }
        ring_fifo_enqueue(&ctxt->rb,&ch,1);
    }

    os_post_semaphore_from_isr(ctxt->sem_rx);
}

// static void uart_device_transmit_callback(HAL_UART_PORT port)
// {
//     uart_ctxt_t *uart_priv = uart_device_get_ctxt(port);

//     os_post_semaphore_from_isr(uart_priv->sem_tx);
// }

static void uart_device_receive_callback(HAL_UART_PORT port)
{
    uart_ctxt_t *uart_priv = uart_device_get_ctxt(port);

    os_post_semaphore_from_isr(uart_priv->sem_rx);
}

static int32_t uart_device_read(dev_t *dev, void *buffer, size_t size)
{
    int32_t ret = ERR_OK;
    uint32_t len, count;
    struct serial_fifo *rx_fifo;
    uint32_t level;
    uart_ctxt_t *uart_priv = (uart_ctxt_t *)dev->user_data;

    if (!uart_priv || !buffer || !size) {
        LOG_INFO(LOG_ID, "invalid uart_ctxt_t:%p, buffer:%p or size:%d\r\n", uart_priv, buffer,
                 size);
        return ERR_INVAL;
    }

    os_acquire_mutex(uart_priv->m);
    ret = ring_fifo_dequeue(&uart_priv->rb, buffer, size);
    if (ret == ERR_NOMEM) {
        LOG_INFO(LOG_ID, "not enough space\r\n");
    }
    // rx_fifo = (struct serial_fifo *)uart_priv->serial_rx;
    // level = hw_interrupt_disable();
    // len = _serial_fifo_calc_data_len(rx_fifo);
    // if ((len == 0)) {
    //     do {
    //         /* enable interrupt */
    //         hw_interrupt_enable(level);
    //         ret = os_pend_semaphore(uart_priv->sem_rx, 0xffffffff);
    //         level = hw_interrupt_disable();
    //         len = _serial_fifo_calc_data_len(rx_fifo);
    //     } while (len == 0);
    // }
    // if (len > size) {
    //     len = size;
    // }
    // uint8_t *new_buffer = (uint8_t *)buffer;
    // /* read from software FIFO */
    // for (count = 0; count < len; count++) {
    //     /* otherwise there's the data: */
    //     *new_buffer= _serial_fifo_pop_data(rx_fifo);
    //     new_buffer++;
    // }

    // rx_fifo->is_full = false;

    // /* enable interrupt */
    // hw_interrupt_enable(level);
    //    serial->ops->enable_interrupt(serial);

    
    // ret = hal_uart_receive(uart_priv->port, buffer, size, NULL);
    // ret = hal_uart_receive_buffer(uart_priv->port, buffer, size,
    //                               &i);   // ret =0 finished reading, -1: error 1: not enough data
    // if (ret > 0)                         // means not get enough data from buffer
    //     if (true == os_pend_semaphore(uart_priv->sem_rx, 100))
    //         ret = hal_uart_receive_it(uart_priv->port, buffer, size - i);
    //     else
    //         ret = -1;   //not take semaphore in specified time.

    os_release_mutex(uart_priv->m);

    // printf("%s, uart:%p, ret:%d\r\n", __func__, uart_priv, ret);

    // os_pend_semaphore(uart_priv->sem_tx, 0xFFFFFFFF);

    return count;
}

void transmit_callback(HAL_UART_PORT port)
{

    uart_ctxt_t *ctxt = uart_device_get_ctxt(port);
    os_post_semaphore_from_isr(ctxt->sem_tx);
}

void rs485_transmit_callback(HAL_UART_PORT port)
{

    // uint8_t cmd = 0x1f;
    uart_ctxt_t *ctxt = uart_device_get_ctxt(port);
    // hal_gpio_output_low(rs485_re_pin[port]);
    hal_gpio_output_low(HAL_GPIO_7);
    // os_queue_send_from_isr(tx_finish, &cmd);
    os_post_semaphore_from_isr(ctxt->sem_tx);
}

static int32_t uart_device_write(dev_t *dev, const void *buffer, size_t size)
{
    int ret = ERR_OK;
    char *ptr = (char *)buffer;

    uart_ctxt_t *uart_priv = (uart_ctxt_t *)dev->user_data;

    if (!buffer || !size) {
        return ERR_INVAL;
    }

    if (!uart_priv) {
        return ERR_INVAL;
    }

    os_acquire_mutex(uart_priv->m);

    ret = hal_uart_transmit(uart_priv->port, buffer, size);

    if(uart_priv->enable_tx_it)
    {
        os_pend_semaphore(uart_priv->sem_tx, 1000);
    }
    os_release_mutex(uart_priv->m);

    LOG_INFO(LOG_ID, "%s,uart:%p,ret:%d\r\n", __func__, uart_priv, ret);
    // printf("%s, uart:%p, ret:%d\r\n", __func__, uart_priv, ret);
    return ret;
}

static int32_t uart_device_ioctl(dev_t *dev, int cmd, unsigned long arg)
{
    int32_t ret = ERR_OK;
    uart_ctxt_t *uart_priv = (uart_ctxt_t *)dev->user_data;

    if (!uart_priv) {
        LOG_INFO(LOG_ID, "uart is NULL,invalid and ignore\r\n");
        // printf("uart is NULL,invalid and ignore\r\n");
        return ERR_INVAL;
    }

    os_acquire_mutex(uart_priv->m);
    // int bits = 0;
    // switch (cmd) {
    //     case IOC_UART_MODE_SET:
    //         bits = arg & UARTMODE_MASK;
    //         switch (bits) {
    //             case RX_TX_POLLING:
    //                 uart_priv->enable_rx_it = false;
    //                 uart_priv->enable_tx_it = false;

    //                 break;
    //             case RX_POLLING_TX_INT:
    //                 uart_priv->enable_rx_it = false;
    //                 uart_priv->enable_tx_it = true;

    //                 break;
    //             case RX_TX_INT:
    //                 uart_priv->enable_rx_it = true;
    //                 uart_priv->enable_tx_it = true;
    //                 break;
    //             default:
    //                 uart_priv->enable_rx_it = false;
    //                 uart_priv->enable_tx_it = false;
    //                 break;
    //         }
    //     break;
    //     case IOC_UART_PROTOCOL_MASK:
    //         bits = arg & UARTPROTOCOL_MASK;
    //         switch (bits) {
    //             case RS232:
    //                 uart_priv->type = RS_232;
    //                 break;
    //             case RS485:
    //                 uart_priv-> type = RS_485;
    //                 break;
    //             default:
    //                 uart_priv->type = RS_232;
    //                 break;
    //         }
    //     break;
    //     case IOC_485_SET_RE_PIN:
    //         rs485_re_pin[uart_priv->port] = arg;
    //     break;
    // }
    // if (uart_priv->enable_rx_it) {
    //     if (uart_priv->type == RS_232 )  {
    //         hal_uart_register_rx_callback(uart_priv->port, receive_callback);
    //     } else if (uart_priv->type == RS_485 ) {
    //         hal_uart_register_rx_callback(uart_priv->port, rs485_receive_callback);
    //     }

    //     hal_uart_start_receive_it(uart_priv->port);
    // }
    // if (uart_priv->enable_tx_it) {
    //     if (uart_priv->type == RS_232 ) {
    //         hal_uart_register_tx_callback(uart_priv->port, transmit_callback);
    //     } else if(uart_priv->type == RS_485) {
    //         hal_uart_register_tx_callback(uart_priv->port, rs485_transmit_callback);
    //     }
    // }

    os_release_mutex(uart_priv->m);

    return ret;
}

static int32_t uart_device_open(dev_t *dev, uint32_t flags)
{
    int32_t ret = ERR_OK;
    uart_ctxt_t *uart_priv = (uart_ctxt_t *)dev->user_data;

    if (!uart_priv) {
        return ERR_INVAL;
    }
    switch (flags & UART_TX_MASK) {
        case TX_POLLING:
            uart_priv->enable_tx_it = false;
            break;
        case TX_INT:
            uart_priv->enable_tx_it = true;
            break;
        default:
            uart_priv->enable_tx_it = false;
            break;
    }
    switch (flags & UART_RX_MASK) {
        case RX_POLLING:
            uart_priv->enable_rx_it = false;
            break;
        case RX_INT:
            uart_priv->enable_rx_it = true;
            break;
        default:
            uart_priv->enable_rx_it = false;
            break;
    }

    switch (flags & UART_PROTOCOL_MASK) {
        case RS_232:
            uart_priv->type = RS_232_PROTOCOL;
            break;
        case RS_485:
            uart_priv->type = RS_485_PROTOCOL;
            break;
        default:
            uart_priv->type = RS_232_PROTOCOL;
            break;
    }
    os_acquire_mutex(uart_priv->m);

    if (uart_priv->ref_cnt) {
        os_release_mutex(uart_priv->m);
        return ERR_OK;
    }

    // if (uart_priv->serial_rx == NULL) {
    //     serial_fifo_t *rx_fifo =
    //         os_mem_malloc(LIB_MID, sizeof(serial_fifo_t) + UART_DEVICE_RX_BUF_SZ);
    //     if (!rx_fifo) {
    //         return ERR_NOMEM;
    //     }
    //     rx_fifo->buf_sz = UART_DEVICE_RX_BUF_SZ;
    //     rx_fifo->buffer = (uint8_t *)(rx_fifo + 1);
    //     memset(rx_fifo->buffer, 0, rx_fifo->buf_sz);
    //     rx_fifo->put_index = 0;
    //     rx_fifo->get_index = 0;
    //     rx_fifo->is_full = false;

    //     uart_priv->serial_rx = rx_fifo;
    // }
    ret = hal_uart_open(uart_priv->port, 115200, HAL_UART_DATA_BITS_8, HAL_UART_STOP_BITS_1,
                        HAL_UART_PARITY_NONE);
    if (ret) {
        LOG_INFO(LOG_ID, "hal_uart_init failed,ret:%d\r\n", ret);
        // printf("hal_uart_init failed, ret:%d\r\n", ret);
        os_release_mutex(uart_priv->m);
        return ERR_FAIL;
    }
        if (uart_priv->enable_rx_it) {
        if (uart_priv->type == RS_232_PROTOCOL) {
            hal_uart_register_rx_callback(uart_priv->port, receive_callback);
        } else if (uart_priv->type == RS_485_PROTOCOL) {
            hal_uart_register_rx_callback(uart_priv->port, rs485_receive_callback);
        }

        // hal_uart_start_receive_it(uart_priv->port);
    }
    if (uart_priv->enable_tx_it) {
        if (uart_priv->type == RS_232_PROTOCOL) {
            hal_uart_register_tx_callback(uart_priv->port, transmit_callback);
        } else if (uart_priv->type == RS_485_PROTOCOL) {
            hal_uart_register_tx_callback(uart_priv->port, rs485_transmit_callback);
        }
    }
    hal_uart_start_receive_it(uart_priv->port);
    uart_priv->ref_cnt++;
    os_release_mutex(uart_priv->m);

    return ERR_OK;
}

static int32_t uart_device_close(dev_t *dev)
{
    int ret = 0;
    uart_ctxt_t *uart_priv = (uart_ctxt_t *)dev->user_data;

    if (!uart_priv) {
        LOG_INFO(LOG_ID, "uart_ctxt_t is NULL,invalid and ignore\r\n");
        // printf("uart_ctxt_t is NULL,invalid and ignore\r\n");
        return ERR_INVAL;
    }

    os_acquire_mutex(uart_priv->m);

    uart_priv->ref_cnt--;

    if (uart_priv->ref_cnt != 0) {
        os_release_mutex(uart_priv->m);
        return ERR_OK;
    }
    os_release_mutex(uart_priv->m);

    // serial_fifo_t *rx_fifo = (serial_fifo_t *)uart_priv->serial_rx;
    // os_mem_free(rx_fifo);
    os_mem_free(&uart_priv->rb.data);

    return ERR_OK;
}

static dev_ops_t uart_device_ops = {
    .init = NULL,
    .open = uart_device_open,
    .close = uart_device_close,
    .read = uart_device_read,
    .write = uart_device_write,
    .control = uart_device_ioctl,
};

int32_t uart_device_init(void)
{
    int32_t ret = ERR_OK;

    for (uint32_t i = 0; i < UART_DEVICE_NUMBER; i++) {
        dev_t *dev = os_mem_malloc(LIB_MID, sizeof(dev_t));
        if (!dev) {
            goto out;
        }
        uart_ctxt_t *uart_priv = os_mem_malloc(LIB_MID, sizeof(uart_ctxt_t));

        os_mutex_h m = os_create_mutex(LIB_MID);
        os_sem_h sem_tx = os_create_semaphore(LIB_MID, 2, 0);
        os_sem_h sem_rx = os_create_semaphore(LIB_MID, 2, 0);
        uint8_t *rx_buffer = os_mem_malloc(LIB_MID, UART_DEVICE_RX_BUF_SZ);

        if (!m || !sem_tx || !sem_rx ||!rx_buffer ) {
            os_mem_free(uart_priv);
            os_mem_free(dev);
            goto out;
        }

        memset(uart_priv, 0x0, sizeof(uart_ctxt_t));

        uart_priv->port = (HAL_UART_PORT0 + i);
        uart_priv->m = m;
        uart_priv->sem_tx = sem_tx;
        uart_priv->sem_rx = sem_rx;
        uart_priv->ref_cnt = 0;
        // uart_priv->sem_tx = tx;
        // uart_priv->sem_rx = rx;
        uart_priv->enable_tx_it = 0;
        uart_priv->enable_rx_it = 0;
        uart_priv->type = RS_232_PROTOCOL;
        // uart_priv->serial_rx = 0;
        snprintf(dev->node_name, DEV_NAME_MAX_LEN, UART_DEVICE_NAME_FORMAT, i);
        ring_fifo_init(&(uart_priv->rb), rx_buffer, UART_DEVICE_RX_BUF_SZ);

        dev->ops = &uart_device_ops;
        dev->user_data = (void *)uart_priv;
        uart_ctxt[i] = uart_priv;

        dev_register(dev);
    }

out:
    return ret;
}
