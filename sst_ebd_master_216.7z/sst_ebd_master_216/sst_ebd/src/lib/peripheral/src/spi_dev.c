
#include "types.h"
#include "stdio.h"
#include "string.h"

#include "cpu.h"

#include "spi_dev.h"
#include "hal_spi.h"
#include "modules.h"
#include "dev.h"

#include "os_lock.h"
#include "os_mem.h"

#define SPI_DEVICE_NUMBER 2
#define SPI_DEVICE_NAME_FORMAT "spi%d"
// static spi_info_t spi_map[TIM_NUM];
typedef struct spi_ctxt_t {
    HAL_SPI_PORT port;
    os_mutex_h m;
    uint32_t ref_cnt;
} spi_ctxt_t;

int32_t spi_ctl_device(dev_t *dev, int cmd, unsigned long arg)
{
    int ret = -1;
    spi_config_t config ;
    spi_transfer_t *transfer;

    spi_ctxt_t *vs = (spi_ctxt_t *)dev->user_data;

    if (!vs) {
        //ddkc_dbg("spi is NULL,invalid and ignore\r\n");
        return -2;
    }
   os_acquire_mutex(vs->m);

    switch (cmd) {
        case IOC_SPI_SET_CONFIG:
            memcpy(&config, (void *)arg, sizeof(spi_config_t));
            ret = hal_spi_close(config.port);
            if (ret) {
                //ddkc_warn("hal_spi_finalize failed, ret:%d\r\n", ret);
                break;
            }
            ret = hal_spi_open(config.port, config.prescaler, config.role,
                     config.mode, config.polarity, config.delay,
                     config.length);
            if (ret) {
                //ddkc_warn("hal_spi_init failed, ret:%d\r\n", ret);
            }
            break;
        case IOC_SPI_SEND_RECV:
            transfer = (spi_transfer_t *)arg;
            if(NULL == transfer){
                //ddkc_warn("tranptr is null, ret:%d\r\n", ret);
                break;
            }
            //ret = hal_spi_send(vs, tranptr->tx_buf, tranptr->rx_size, 1000);
            ret = hal_spi_send_recv(transfer->port, transfer->tx_buf, transfer->rx_buf, transfer->buf_size);
            if (ret) {
                //ddkc_warn("hal_spi_send_recv failed, ret:%d\r\n", ret);
            }

            break;
        case IOC_SPI_SEND:
            transfer = (spi_transfer_t *)arg;
            if(NULL == transfer){
                //ddkc_warn("tranptr is null, ret:%d\r\n", ret);
                break;
            }
            ret = hal_spi_send(transfer->port, transfer->tx_buf, transfer->buf_size);
            if (ret) {
                //ddkc_warn("hal_spi_send_and_recv failed, ret:%d\r\n", ret);
            }

            break;
        case IOC_SPI_RECV:
            transfer = (spi_transfer_t *)arg;
            if(NULL == transfer){
                //ddkc_warn("tranptr is null, ret:%d\r\n", ret);
                break;
            }
            ret = hal_spi_receive(transfer->port, transfer->rx_buf, transfer->buf_size);
            if (ret) {
                //ddkc_warn("hal_spi_send_and_send failed, ret:%d\r\n", ret);
            }
            break;
        default:
            break;
    }
    os_release_mutex(vs->m);
    return ret;
}
static dev_ops_t spi_device_ops = {
    .init = NULL,
    .open = NULL,
    .close = NULL,
    .read = NULL,
    .write = NULL,
    .control = spi_ctl_device,
};

int32_t spi_device_init(void)
{
    int32_t ret = ERR_OK;

    for (uint32_t i = 0; i < SPI_DEVICE_NUMBER; i++) {
        dev_t *dev = os_mem_malloc(LIB_MID, sizeof(dev_t));
        if(!dev){
            goto out;
        }
        spi_ctxt_t *spi_priv = os_mem_malloc(LIB_MID, sizeof(spi_ctxt_t));

        if(!spi_priv){
            os_mem_free(dev);
            ret = ERR_FAIL;
            goto out;
        }

        os_mutex_h m = os_create_mutex(LIB_MID);

        if(!m){
            os_mem_free(spi_priv);
            os_mem_free(dev);
            goto out;
        }

        memset(spi_priv, 0x0, sizeof(spi_ctxt_t));  

        spi_priv->port = (HAL_SPI_PORT0 + i);
        spi_priv->m = m;
        spi_priv->ref_cnt = 0;

        snprintf(dev->node_name, DEV_NAME_MAX_LEN, SPI_DEVICE_NAME_FORMAT, i);

        dev->ops = &spi_device_ops;
        dev->user_data = (void*)spi_priv;

        dev_register(dev);
    }

out:
    return ret;
}
