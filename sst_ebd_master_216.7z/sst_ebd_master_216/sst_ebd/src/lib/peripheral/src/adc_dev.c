// #include "types.h"
// #include "stdio.h"
// #include "string.h"

// #include "cpu.h"
// #include "log.h"

// #include "hal_adc.h"
// #include "modules.h"
// #include "dev.h"

// #include "os_lock.h"
// #include "os_mem.h"

// #include "adc_dev.h"

// #define ADC_NUM                  3
// #define ADC_DEVICE_NUMBER      3
// #define ADC_DEVICE_NAME_FORMAT "adc%d"

// #define DISABLE 0
// #define ENABLE  1
// typedef struct adc_status {
//     int8_t port;
//     bool_t inited;
//     bool_t started;
//     adc_alarm_t config;
// } adc_status_t;

// static adc_status_t adc_status_info[ADC_NUM];


// int32_t adc_device_close(dev_t *dev)
// {
//     int ret = ERR_OK;
//     adc_alarm_t *alarm = (adc_alarm_t *)dev->user_data;
//     adc_status_t *alarm_status = CONTAINER_OF(alarm, adc_status_t, config);
//     if (alarm_status->started) {
//         hal_adc_deinit();
//     }
//     return ret;
// }

// int32_t adc_ctl_device(dev_t *dev, int cmd, unsigned long arg)
// {
//     int32_t ret = ERR_OK;

//     adc_alarm_t *alarm = (adc_alarm_t *)dev->user_data;
//     adc_status_t *alarm_status = CONTAINER_OF(alarm, adc_status_t, config);
//     adc_config_t ad_config;
//     if (!alarm || !alarm_status) {
//         return ERR_INVAL;
//     }
//     // os_acquire_mutex(adc_priv->m);
//     switch (cmd) {
//         case IOC_ADC_CONTROL:
//             if (arg == IO_ADC_START) {
//                 if (!alarm_status->started) {
//                     ret = hal_adc_init();
//                     alarm_status->started = ret ? false : true;
//                 } else {
//                     //log
//                 }
//             } else {
//                 if (alarm_status->started) {
//                     hal_adc_deinit();
//                 }
//             }
//             break;
//         case IOC_ADC_GET_VALUE:
//             memcpy(&ad_config, (void *)arg, sizeof(adc_config_t));
//             arg = hal_adc_get_value(ad_config.channel,ad_config.value);
//             break;
//         default:
//             LOG_INFO(LOG_ID,"invalid cmd:%d\r\n",cmd);
//             break;
//     }
//     // os_release_mutex(adc_priv->m);
//     return ret;
// }

// static int32_t adc_init_device(dev_t *dev)
// {
//     int32_t ret = ERR_OK;

//     adc_alarm_t *alarm = (adc_alarm_t *)dev->user_data;
//     adc_status_t *alarm_status = CONTAINER_OF(alarm,adc_status_t,config);

//     if(!alarm || !alarm_status)
//     {
//         return ERR_INVAL;
//     }
//     if(alarm_status->inited)
//     {
//         return ERR_INVAL;
//     }
//     ret = hal_adc_init();
//     if(ret)
//     {
//         return ERR_FAIL;
//     }
//     alarm_status->inited = true;
//     return ERR_OK;
// }

// static dev_ops_t adc_device_ops = {
//     .init = adc_init_device,
//     .open = NULL,
//     .close = NULL,
//     .read = NULL,
//     .write = NULL,
//     .control = adc_ctl_device,
// };

// int32_t adc_device_init(void)
// {
//     int32_t ret = ERR_OK;

//     for (uint32_t i = 0; i < ADC_DEVICE_NUMBER; i++) {
//         dev_t *dev = os_mem_malloc(LIB_MID, sizeof(dev_t));
//         if (!dev) {
//             goto out;
//         }
//         adc_status_t *adc_priv = os_mem_malloc(LIB_MID, sizeof(adc_status_t));

//         if (!adc_priv) {
//             os_mem_free(dev);
//             ret = ERR_FAIL;
//             goto out;
//         }

//         os_mutex_h m = os_create_mutex(LIB_MID);

//         if (!m) {
//             os_mem_free(adc_priv);
//             os_mem_free(dev);
//             goto out;
//         }

//         memset(adc_priv, 0x0, sizeof(adc_status_t));
//         adc_alarm_t alarm = adc_priv->config;
//         // timer_priv->port = (HAL_TIMER_PORT0 + i);
//         // timer_priv->period = 0;;
//         // timer_priv->repeat = 0;
//         // timer_priv->started = 0;

//         snprintf(dev->node_name, DEV_NAME_MAX_LEN, ADC_DEVICE_NAME_FORMAT, i);

//         dev->ops = &adc_device_ops;
//         dev->user_data = (void *)&alarm;

//         dev_register(dev);
//     }

// out:
//     return ret;
// }
