#include "types.h"
#include "string.h"

#include "dev.h"

struct dev *dev_list = NULL;

/*
    find driver exist or not
*/
static bool_t dev_is_exists(dev_t *dev)
{
    dev_t *cur = dev_list;

    while (cur != NULL) {
        if (!strncmp(cur->node_name, dev->node_name, DEV_NAME_MAX_LEN)) {
            return true;
        }
        cur = cur->next;
    }

    return false;
}

static int32_t dev_list_insert(dev_t *dev)
{
    dev_t *cur = dev_list;

    if (NULL == dev_list) {
        dev_list = dev;
        dev->next = NULL;
    } else {
        while (NULL != cur->next) {
            cur = cur->next;
        }
        cur->next = dev;
        dev->next = NULL;
    }

    return ERR_OK;
}

int32_t dev_register(dev_t *dev)
{
    if ((NULL == dev) || (dev_is_exists(dev))) {
        return ERR_INVAL;
    }

    if ((NULL == dev->node_name) || (NULL == dev->ops)) {
        return ERR_INVAL;
    }

    return dev_list_insert(dev);
}

dev_t *dev_find(const char *name)
{
    dev_t *cur = dev_list;
    while (cur != NULL) {
        if (!strncmp(cur->node_name, name, DEV_NAME_MAX_LEN)) {
            return cur;
        }
        cur = cur->next;
    }
    return NULL;
}

int32_t dev_read(dev_t *dev, void *buffer, int size)
{
    if (dev && dev->ops->read) {
        return dev->ops->read(dev, buffer, size);
    }

    return ERR_INVAL;
}

int32_t dev_write(dev_t *dev, const void *buffer, int size)
{
    if (dev && dev->ops->write) {
        return dev->ops->write(dev, buffer, size);
    }

    return ERR_INVAL;
}

int32_t dev_control(dev_t *dev, uint32_t cmd, uint32_t arg)
{
    if (dev && dev->ops->control) {
        return dev->ops->control(dev, cmd, arg);
    }

    return ERR_INVAL;
}

int32_t dev_open(dev_t *dev,uint32_t flags)
{
    if (dev && dev->ops->open) {
        return dev->ops->open(dev,flags);
    }

    return ERR_INVAL;
}

int32_t dev_close(dev_t *dev)
{
    if (dev && dev->ops->close) {
        return dev->ops->close(dev);
    }

    return ERR_INVAL;
}

int32_t dev_init(dev_t *dev)
{
    if (dev && dev->ops->init) {
        return dev->ops->init(dev);
    }

    return ERR_INVAL;
}
