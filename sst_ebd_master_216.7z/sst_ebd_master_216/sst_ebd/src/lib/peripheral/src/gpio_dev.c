#include <stdio.h>
#include "types.h"
#include "cpu.h"
#include "modules.h"
#include "dev.h"

#include "log.h"

#include "hal_gpio.h"

#include "os_lock.h"
#include "os_mem.h"
#include <string.h>
#include "gpio_dev.h"

#define MUTEX_GPIO_ID 1
#define GPIO_DEVICE_NAME "gpio"
#define INITED      1 
os_mutex_h gpio_mutex;

bool_t init_flag = 0;
typedef struct gpio_ctxt_t {
    // HAL_GPIO_PORT port;
    os_mutex_h m;
    uint32_t ref_cnt;
} gpio_ctxt_t;

HAL_GPIO_DIRECTION gpio_hal_configs[HAL_GPIO_MAX];

// int gpio_device_init()
// {
//     int i;
//     for (i = 0; i < HAL_GPIO_MAX; i++)
//         gpio_hal_configs[i] = 255;
//     gpio_mutex = os_create_mutex(MUTEX_GPIO_ID);
//     hal_gpio_init();   //使能时钟
// }
static int32_t gpio_init_dev(dev_t *dev)
{
    gpio_ctxt_t *gpio_priv = (gpio_ctxt_t *)dev->user_data;
    int i;
    if (!gpio_priv) {
        return ERR_INVAL;
    }
    if(init_flag)
    {
        return ERR_OK;
    }
    init_flag = INITED;
    os_acquire_mutex(gpio_priv->m);
    for (i = 0; i < HAL_GPIO_MAX; i++)
        gpio_hal_configs[i] = 255;
    hal_gpio_init();   //使能时钟

    os_release_mutex(gpio_priv->m);

    return ERR_OK;
}
static void prepare_gpio_hal(HAL_GPIO_ID id, HAL_GPIO_DIRECTION dir)
{
    if (dir == gpio_hal_configs[id])
        return;

    if (gpio_hal_configs[id] != 255)
        hal_gpio_close(id);

    hal_gpio_open(id, dir);
    gpio_hal_configs[id] = dir;
}

int gpio_io_set(gpio_config_t *config)
{
    int ret = 0;
    HAL_GPIO_DIRECTION dir;

    if (config->config & GPIO_IO_OUTPUT_MASK) {
        /* check if */
        if ((config->config & GPIO_IO_OUTPUT_MASK) == GPIO_IO_OUTPUT_TOGGLE) {
            dir = HAL_GPIO_OUTPUT;
            prepare_gpio_hal(config->id, dir);
            ret = hal_gpio_output_toggle(config->id);
            return 0;
        }

        switch (config->config & GPIO_IO_OUTPUT_MASK) {
            case GPIO_IO_OUTPUT_PP:
                dir = HAL_GPIO_OUTPUT;
                break;
            case GPIO_IO_OUTPUT_ODNP:
                dir = HAL_GPIO_OUTPUT_OD;
                break;
            // case GPIO_IO_OUTPUT_ODPU:
            //     gpio_dev.config = OUTPUT_OPEN_DRAIN_PULL_UP;
            //     break;
            default:
                dir = HAL_GPIO_OUTPUT;
                break;
        }

        prepare_gpio_hal(config->id, dir);

        if (config->data) {
            ret = hal_gpio_output_high(config->id);
        } else
            ret = hal_gpio_output_low(config->id);

        return ret;
    }
    return ret;
}

int gpio_io_get(gpio_config_t *config)
{
    int ret = 0;
    HAL_GPIO_DIRECTION dir;

    if (config->config & GPIO_IO_INPUT_MASK) {
        uint32_t value = 0;
        switch (config->config & GPIO_IO_INPUT_MASK) {
            // case GPIO_IO_INPUT_HI:
            //     gpio_dev.config = INPUT_HIGH_IMPEDANCE;
            //     break;
            case GPIO_IO_INPUT_PU:
                dir = HAL_GPIO_INPUT_PULLUP;
                break;
            case GPIO_IO_INPUT_PD:
                dir = HAL_GPIO_INPUT_PULLDOWN;
                break;
            default:
                dir = HAL_GPIO_INPUT;
                break;
        }
        prepare_gpio_hal(config->id, dir);
        ret = hal_gpio_input_get(config->id, &value);
        if(!ret)
        {
            config->data = value;
        }
        // return !ret ? value : ret;
    }

        return ret;
}

static int gpio_irq_set(gpio_config_t *config)
{
    int ret = 0;
    HAL_GPIO_INT_MODE irq_type;
    HAL_GPIO_DIRECTION dir;
    // dir = HAL_GPIO_IRQ;
    if (config->config == gpio_hal_configs[config->id])//相同的配置
        return 0;

    if (gpio_hal_configs[config->id] != 255)//之前做过其他配置
    {
        hal_gpio_close(config->id);
        hal_gpio_dettach_irq(config->id);
    }
        
    // prepare_gpio_hal(id, dir);

    if (config->config & GPIO_IRQ_ENABLE) {

        switch (config->config & GPIO_IRQ_MODE_MASK) {
            case GPIO_IRQ_LEVEL_LOW:
                LOG_INFO(LOG_ID,"not implemented yet\r\n");
                return ERR_NOSUPP;
            case GPIO_IRQ_LEVEL_HIGH:
                LOG_INFO(LOG_ID,"not implemented yet\r\n");
                return ERR_NOSUPP;
            case GPIO_IRQ_EDGE_FALLING:
                irq_type = HAL_GPIO_INT_EDGE_FALLING;
                break;
            case GPIO_IRQ_EDGE_RISING:
                irq_type = HAL_GPIO_INT_EDGE_RISING;
                break;
            case GPIO_IRQ_EDGE_BOTH:
                irq_type = HAL_GPIO_INT_EDGE_BOTH;
                break;
            default:
                return ERR_NOSUPP;
        }
        hal_gpio_attach_irq(config->id,irq_type,config->cb,config->arg);
        ret = hal_gpio_enable_irq(config->id,true);

    } else if (config->config & GPIO_IRQ_DISABLE) {
        ret = hal_gpio_enable_irq(config->id,false);
    // } else if (config->config & GPIO_IRQ_CLEAR) {
    //     ret = hal_gpio_clear_irq(&gpio_dev);
    }
    gpio_hal_configs[config->id] = config->config;
    return ret;
}

static int32_t gpio_ctl_dev(dev_t *dev, int cmd, unsigned long arg)
{
    int ret = ERR_OK;
    // gpio_io_config_t config;
    // gpio_irq_config_t irq_config;
    gpio_ctxt_t *gpio_priv = (gpio_ctxt_t *)dev->user_data;
    gpio_config_t io_config;
    if (!gpio_priv) {
        LOG_INFO(LOG_ID,"gpio is NULL,invalid and ignore\r\n");
        return ERR_INVAL;
    }
    os_acquire_mutex(gpio_priv->m);
    switch (cmd) {
        case IOC_GPIO_SET:
            // memcpy(&io_config, (void *)arg, sizeof(gpio_config_t));
            ret = gpio_io_set(arg);
            break;
        case IOC_GPIO_GET:
            memcpy(&io_config, (void *)arg, sizeof(gpio_config_t));
            ret = gpio_io_get(&io_config);
            memcpy((void *)arg, &io_config, sizeof(gpio_config_t));
            break;
        case IOC_GPIO_SET_IRQ:
            memcpy(&io_config, (void *)arg, sizeof(gpio_config_t));
            ret = gpio_irq_set(&io_config);
            break;

        default:
            LOG_INFO(LOG_ID,"invalid command : %d\r\n",cmd);
            break;
    }
    os_release_mutex(gpio_priv->m);
    return ret;
}

static dev_ops_t gpio_device_ops = {
    .init = gpio_init_dev,
    .open = NULL,
    .close = NULL,
    .read = NULL,
    .write = NULL,
    .control = gpio_ctl_dev,
};

int32_t gpio_device_init(void)
{
    int32_t ret = ERR_OK;

    dev_t *dev = os_mem_malloc(LIB_MID, sizeof(dev_t));
    if(!dev){
        goto out;
    }
    gpio_ctxt_t *gpio_priv = os_mem_malloc(LIB_MID, sizeof(gpio_ctxt_t));

    if(!gpio_priv){
        os_mem_free(dev);
        ret = ERR_FAIL;
        goto out;
    }

    os_mutex_h m = os_create_mutex(LIB_MID);

    if(!m){
        os_mem_free(gpio_priv);
        os_mem_free(dev);
        goto out;
    }

    memset(gpio_priv, 0x0, sizeof(gpio_ctxt_t));  

    gpio_priv->m = m;
    gpio_priv->ref_cnt = 0;
    // dev->node_name = GPIO_DEVICE_NAME;
    memset(dev->node_name,0x0,DEV_NAME_MAX_LEN);
    memcpy(dev->node_name,GPIO_DEVICE_NAME,sizeof(GPIO_DEVICE_NAME));
    // snprintf(dev->node_name, DEV_NAME_MAX_LEN, GPIO_DEVICE_NAME, i);

    dev->ops = &gpio_device_ops;
    dev->user_data = (void*)gpio_priv;

    dev_register(dev);

out:
    return ret;
}