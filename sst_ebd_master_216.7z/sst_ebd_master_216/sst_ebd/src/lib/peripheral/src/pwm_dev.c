#include <stdio.h>
#include "types.h"
#include "cpu.h"
#include "modules.h"
#include "dev.h"

#include "hal_pwm.h"

#include "os_lock.h"
#include "os_mem.h"
#include <string.h>
#include "pwm_dev.h"

#define PWM_DEVICE_NUMBER 4
#define PWM_DEVICE_NAME "pwm%d"
#define INIT_PULSE period/2
uint32_t period = 50000-1;
uint32_t psc = 9000-1;
typedef struct pwm_ctxt_t {
    HAL_PWM_PORT port;
    os_mutex_h m;
    uint32_t ref_cnt;
    bool on;
    bool start;
} pwm_ctxt_t;

static int32_t pwm_init_dev(dev_t *dev)
{
    int32_t ret = ERR_OK;
    pwm_ctxt_t *pwm_priv = (pwm_ctxt_t *)dev->user_data;
    if (!pwm_priv->on) {
        ret = hal_pwm_init(pwm_priv->port, period,psc) ;  //初始化时钟配置周期
    }
    pwm_priv->on = ret ? false : true;
    return ret ;
}
static int32_t pwm_ctl_dev(dev_t *dev, int cmd, unsigned long arg)
{
    int32_t ret = ERR_OK;
    pwm_ctxt_t *pwm_priv = (pwm_ctxt_t *)dev->user_data;
    pwm_config_t pwm_set;
    uint32_t channel = 0;
    uint32_t cycle = 0;
    uint32_t freq = 0;
    uint32_t period = 0;
    pwm_set_config_t pwm_config;
    if (!pwm_priv) {
        return ERR_INVAL;
    }

    os_acquire_mutex(pwm_priv->m);
    switch (cmd) {
        case IOC_PWM_START:
            if (pwm_priv->on && !pwm_priv->start) {
                // ret = hal_pwm_start(pwm);
                memcpy(&pwm_config, (void *)arg, sizeof(pwm_set_config_t));
                ret = hal_pwm_start(pwm_priv->port, pwm_config.pwm_mode, pwm_config.pulse, pwm_config.ocpolarity,pwm_config.channel);
                pwm_priv->start = ret ? false : true;
            }
            break;
        case IOC_PWM_STOP:
            if (pwm_priv->start){
                channel = arg;
                hal_pwm_stop(pwm_priv->port, channel);
            }
            pwm_priv->start = false;
            break;
        case IOC_PWM_FREQ:

            memcpy(&pwm_set, (void *)arg, sizeof(pwm_config_t));

            if (pwm_priv->start) {
                hal_pwm_freq_chg(pwm_priv->port, pwm_set.pulse, pwm_set.channel);   //修改占空比
            }
            break;
        case IOC_PWM_DUTY_CYCLE:
            cycle = arg;
            if (!pwm_priv->start)
                ret = hal_pwm_cycle_chg(pwm_priv->port, cycle);   //修改周期
            break;
        default:
            break;
    }
    os_release_mutex(pwm_priv->m);
    return ret;
}
static dev_ops_t pwm_device_ops = {
    .init = pwm_init_dev,
    .open = NULL,
    .close = NULL,
    .read = NULL,
    .write = NULL,
    .control = pwm_ctl_dev,
};

int32_t pwm_device_init(void)
{
    int32_t ret = ERR_OK;
    for (uint32_t i = 0; i < PWM_DEVICE_NUMBER; i++) {
        dev_t *dev = os_mem_malloc(LIB_MID, sizeof(dev_t));
        if(!dev){
            goto out;
        }
        pwm_ctxt_t *pwm_priv = os_mem_malloc(LIB_MID, sizeof(pwm_ctxt_t));

        if(!pwm_priv){
            os_mem_free(dev);
            ret = ERR_FAIL;
            goto out;
        }

        os_mutex_h m = os_create_mutex(LIB_MID);

        if(!m){
            os_mem_free(pwm_priv);
            os_mem_free(dev);
            goto out;
        }

        memset(pwm_priv, 0x0, sizeof(pwm_ctxt_t));  
        pwm_priv->port = (HAL_PWM_PORT0+i);
        pwm_priv->m = m;
        pwm_priv->ref_cnt = 0;
        pwm_priv->on = 0;
        pwm_priv->start = 0;
        // dev->node_name = pwm_DEVICE_NAME;
        memset(dev->node_name,0x0,DEV_NAME_MAX_LEN);
        // memcpy(dev->node_name,PWM_DEVICE_NAME,sizeof(PWM_DEVICE_NAME));
        snprintf(dev->node_name, DEV_NAME_MAX_LEN, PWM_DEVICE_NAME, i);
        // snprintf(dev->node_name, DEV_NAME_MAX_LEN, pwm_DEVICE_NAME, i);

        dev->ops = &pwm_device_ops;
        dev->user_data = (void*)pwm_priv;

        dev_register(dev);
    }
    

out:
    return ret;
}

