#ifndef UART_DEV_H_
#define UART_DEV_H_

typedef enum{
    RS_232_PROTOCOL = 0,
    RS_485_PROTOCOL,
} HAL_UART_TYPE;

/* argument definition */
#define IOC_UART_MODE_SET 'U'+1
#define IOC_UART_PROTOCOL_MASK 'U'+2
#define IOC_485_SET_RE_PIN 'U'+3
/* UART MODE meaning */
#define UART_TX_MASK  0x0000003
#define TX_POLLING    0x0000001
#define TX_INT    0x0000002
#define UART_RX_MASK 0x00000030
#define RX_POLLING 0x00000010
#define RX_INT   0x00000020


#define UART_PROTOCOL_MASK 0x0000300
#define RS_232   0x0000100
#define RS_485   0x0000200



/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t uart_device_init(void);

#endif   //UART_DEV_H_
