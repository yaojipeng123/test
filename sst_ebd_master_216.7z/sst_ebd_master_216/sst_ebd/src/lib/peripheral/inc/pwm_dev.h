#ifndef _PWM_DEV_H_
#define _PWM_DEV_H_


#define IOC_PWM_BASE 'T'
#define IOC_PWM_START IOC_PWM_BASE + 1         /**< 使能PWM的输出功能 */
#define IOC_PWM_STOP IOC_PWM_BASE + 2        /**< 关闭PWM的输出功能 */
#define IOC_PWM_FREQ IOC_PWM_BASE + 3       /**< 设置PWM的输出频率 */
#define IOC_PWM_DUTY_CYCLE IOC_PWM_BASE + 4 /**< 设置PWM的输出占空比 */


#define OCPOLARITY_HIGH 0
#define OCPOLARITY_LOW  1
typedef enum{
    OCMODE_PWM1,
    OCMODE_PWM2,

}PWM_TIM_OCMODE;

typedef enum{
    PWM_TIM_CHANNEL_ALL,
    PWM_TIM_CHANNEL_1,
    PWM_TIM_CHANNEL_2,
    PWM_TIM_CHANNEL_3,
    PWM_TIM_CHANNEL_4,

}PWM_TIM_CHANNEL;

typedef struct pwm_config {
    uint32_t pulse;
    uint32_t channel;
} pwm_config_t;

typedef struct pwm_set_config{
    bool pwm_mode;
    uint32_t pulse;
    bool ocpolarity;
    uint32_t channel;
}pwm_set_config_t;

/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t pwm_device_init(void);

#endif   //_PWM_DEV_H_