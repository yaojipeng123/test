/*
 * Copyright (C) 2022 Sustao Medical Company
 */

#ifndef _TIMER_DEV_H_
#define _TIMER_DEV_H_

#include <stdbool.h>
#include <stddef.h>
#include "hal_timer.h"
#include "dev.h"


#define IOC_TIMER_BASE 'T'
// #define IOC_TIMER_IRQP_SET IOC_TIMER_BASE + 1 // set timer parameters
// #define IOC_TIMER_IRQP_GET IOC_TIMER_BASE + 2 // get timer parameters
#define IOC_TIMER_CONTROL           IOC_TIMER_BASE + 3 // start/stop timer
#define IOC_TIMER_CREATE            IOC_TIMER_BASE + 4 //  create timer
#define IOC_TIMER_GET_TIMER         IOC_TIMER_BASE + 5 // get freerun timer value
#define IOC_HW_TIMER_DELAY_US       IOC_TIMER_BASE + 6 // hw timer delay us
#define IOC_TIMER_GET_COUNTER_ID      IOC_TIMER_BASE + 7
#define IOC_ENCODER_GET_DIRECTION   IOC_TIMER_BASE + 8
#define IOC_TIMER_SET_COUNTER_ID   IOC_TIMER_BASE + 9
#define IO_TIMER_START 1
#define IO_TIMER_STOP 0


#define TIM_NORMAL  0
#define TIM_ENCODE  1
// typedef struct {
//     uint32_t        period;         /**< timer period, us */
//     uint8_t         reload_mode;    /**< auto reload or not */
//     uint8_t         int_flag;       /** disable interrupt or enable */
//     hal_timer_cb_t  cb;             /**< timer handle when expired */
//     void           *arg;            /**< timer handle args */
// } timer_config_t;

// /* Define timer dev handle */
// typedef struct {
//     int8_t          port;   /**< timer port */
//     timer_config_t  config; /**< timer config */
//     void           *priv;   /**< priv data */
// } timer_dev_t;

typedef struct timer_alarm{

    unsigned long period;
    bool repeat;
    timer_callback_t *cb;
    void *data;
} timer_alarm_t;


// int vfs_timer_drv_init (void);
// int32_t timer_device_init(void);
// int32_t timer_device_open(void);
// int32_t timer_device_close(uint8_t index);
// int32_t timer_ctl_device(dev_t *dev, int cmd, unsigned long arg);
/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t timer_device_init(void);

#endif   //_TIMER_DEV_H_
