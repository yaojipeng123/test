#ifndef _DEV_H_
#define _DEV_H_

#define DEV_NAME_MAX_LEN 32

struct dev {
    char node_name[DEV_NAME_MAX_LEN];
    struct dev_ops *ops;
    void *user_data;
    struct dev *next;
};

typedef struct dev dev_t;

struct dev_ops {
    int32_t (*init)(dev_t *dev);
    int32_t (*open)(dev_t *dev,uint32_t flags);
    int32_t (*close)(dev_t *dev);
    int32_t (*read)(dev_t *dev, void *buffer, size_t size);
    int32_t (*write)(dev_t *dev, const void *buffer, size_t size);
    int32_t (*control)(dev_t *dev, int cmd, uint32_t args);
};

typedef struct dev_ops dev_ops_t;

/**
 * @brief 
 * 
 * @param dev 
 * @return int32_t 
 */
int32_t dev_register(dev_t *dev);

/**
 * @brief 
 * 
 * @param name 
 * @return dev_t* 
 */
dev_t *dev_find(const char *name);

/**
 * @brief 
 * 
 * @param dev 
 * @param buffer 
 * @param size 
 * @return int32_t 
 */
int32_t dev_read(dev_t *dev, void *buffer, int size);

/**
 * @brief 
 * 
 * @param dev 
 * @param buffer 
 * @param size 
 * @return int32_t 
 */
int32_t dev_write(dev_t *dev, const void *buffer, int size);

/**
 * @brief 
 * 
 * @param dev 
 * @param cmd 
 * @param arg 
 * @return int32_t 
 */
int32_t dev_control(dev_t *dev, uint32_t cmd, uint32_t arg);

/**
 * @brief 
 * 
 * @param dev 
 * @return int32_t 
 */
int32_t dev_open(dev_t *dev, uint32_t flags);

/**
 * @brief 
 * 
 * @param dev 
 * @return int32_t 
 */
int32_t dev_close(dev_t *dev);

/**
 * @brief 
 * 
 * @param dev 
 * @return int32_t 
 */
int32_t dev_init(dev_t *dev);

#endif   //_DEV_H_
