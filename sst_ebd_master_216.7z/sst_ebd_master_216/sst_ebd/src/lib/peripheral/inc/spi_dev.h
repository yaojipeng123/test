#ifndef _SPI_DEV_H
#define _SPI_DEV_H


#define IOC_SPI_BASE 'S'
#define IOC_SPI_SET_CONFIG IOC_SPI_BASE + 1
#define IOC_SPI_SET_FREQ  IOC_SPI_BASE + 2
#define IOC_SPI_SEND_RECV  IOC_SPI_BASE + 3
#define IOC_SPI_SEND  IOC_SPI_BASE + 4
#define IOC_SPI_RECV  IOC_SPI_BASE + 5

typedef struct spi_config{
    uint8_t     port; 
    uint8_t     prescaler;
    uint8_t     role;
    uint8_t     mode;
    uint8_t     polarity;
    uint8_t     delay;
    uint8_t     length;
} spi_config_t;

typedef struct spi_transfer{
    uint8_t     port; 
	uint8_t *	tx_buf;
	uint8_t *	rx_buf;
	uint16_t buf_size;
} spi_transfer_t;




/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t spi_device_init(void);

#endif //_SPI_DEV_H