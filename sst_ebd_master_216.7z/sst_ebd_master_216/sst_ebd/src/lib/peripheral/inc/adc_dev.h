/*
 * Copyright (C) 2022 Sustao Medical Company
 */

#ifndef _ADC_DEV_H_
#define _ADC_DEV_H_

#include <stdbool.h>
#include <stddef.h>
#include "hal_adc.h"
#include "dev.h"


#define IOC_ADC_BASE 'A'
#define IOC_ADC_CONTROL IOC_ADC_BASE + 3 
// #define IOC_ADC_CREATE IOC_ADC_BASE + 4 //
#define IOC_ADC_GET_VALUE IOC_ADC_BASE + 5 // get freerun timer value
// #define IOC_HW_ADC_DELAY_US IOC_ADC_BASE + 6 // hw timer delay us
#define IO_ADC_START 1
#define IO_ADC_STOP 0


typedef struct adc_alarm{

    unsigned long period;
    bool repeat;
    // adc_callback_t *cb;
    void *data;
} adc_alarm_t;


typedef struct adc_config{
    uint32_t channel;
    uint32_t *value;
}adc_config_t;

/**
 * @brief 
 * 
 * @return int32_t 
 */
int32_t adc_device_init(void);

#endif   //_ADC_DEV_H_
