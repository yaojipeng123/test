#ifndef LIB_CLI_H
#define LIB_CLI_H

#ifdef __cplusplus
extern "C" {
#endif

void cli(void);

#ifdef __cplusplus
}
#endif

#endif /* LIB_CLI_H */
