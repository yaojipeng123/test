#include "types.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"

#include "hal_uart.h"
#include "pid.h"

struct cli_command {
    const char *name;
    const char *desc;
    // return -1 to force CLI to exit
    int (*func)(int argc, char **argv);
};

int cli_help(int argc, char **argv);
int cli_mem_read(int argc, char **argv);
int cli_mem_write(int argc, char **argv);
// int cli_pid_set(int argc,char **argv);

static struct cli_command commands[] = {
    {"help", "Display this list of commands", cli_help},
    {"read", "memory read", cli_mem_read},
    {"write", "memory write", cli_mem_write},
    // {"pidset","set pid value",cli_pid_set},
};

#define BUF_SZ 256
uint8_t buffer[BUF_SZ];

static void dump_hex(const uint8_t *buf, uint32_t buflen, uint32_t addr)
{
    int i, j;

    for (i = 0; i < buflen; i += 16)
    {
        printf("%08x: ", addr + i);

        for (j = 0; j < 16; j++)
            if (i + j < buflen)
                printf("%02x ", buf[i + j]);

        printf("\n");
    }
}


int cli_help(int argc, char **argv)
{
    for (int i = 0; i < ARRAY_SIZE(commands); i++)
        printf("%s\t- %s\n", commands[i].name, commands[i].desc);
    return 0;
}

int cli_mem_read(int argc, char **argv)
{
    uint32_t addr, size;

    //addr = strtol(argv[1], NULL, 0);
    //size = strtol(argv[2], NULL, 0);
    addr = 0x20000000;
    size = 256;

    if(size > BUF_SZ)
        return -1;

    memcpy(buffer, (void*)addr, size);
    dump_hex((void *)buffer, size, addr);

    return 0;
}

int cli_mem_write(int argc, char **argv)
{
    // uint32_t addr;
    // uint32_t val;
    // //addr = strtol(argv[1], NULL, 0);
    // //val = strtol(argv[2], NULL, 0);
    // addr = 0x10000000;
    // val = 0x12345678;

    // *(uint32_t*)addr = val;

    return 0;
}
static uint8_t exchange_to_number(char c)
{
    uint8_t num;
    if((c>='0')&&(c<='9'))
        num = c-0x30;
    else 
        num = 0;
    return num;
}
// static uint8_t get_pid_value()
// {
//     uint8_t value=0;
//     uint8_t temp;
//     char c;
//     while(1)
//     {
//         c = hal_uart_getc(HAL_UART_PORT0);
//         if (c > 0x7F) {
//             continue;
//         }else if((c>=0x30)&&(c<=0x39))
//         {
//             temp = exchange_to_number(c);
//             value = value*10+temp;
//         }
//         else if (c == '\n' || c == '\r') {
//             hal_uart_putc(HAL_UART_PORT0, '\n');
//             hal_uart_putc(HAL_UART_PORT0, '\r');
//             return value;
//         }
//     }
// }

// int cli_pid_set(int argc,char **argv)
// {
//     uint8_t p_val,i_val,d_val;
//     printf("please enter P value\n");
//     p_val = get_pid_value();
//     printf("please enter I value\n");
//     i_val = get_pid_value();
//     printf("please enter D value\n");
//     d_val = get_pid_value();
//     set_p_i_d(p_val,i_val,d_val);
    
// }

#define WHITESPACE "\t\r\n "
#define MAXARGS    8

static int runcmd(char *buf)
{
    int argc;
    char *argv[MAXARGS];
    int i;

    // Parse the command buffer into whitespace-separated arguments
    argc = 0;
    argv[argc] = 0;
    while (1) {
        // gobble whitespace
        while (*buf && strchr(WHITESPACE, *buf))
            *buf++ = 0;
        if (*buf == 0)
            break;

        // save and scan past next arg
        if (argc == MAXARGS - 1) {
            printf("Too many arguments (max %d)\n", MAXARGS);
            return 0;
        }
        argv[argc++] = buf;
        while (*buf && !strchr(WHITESPACE, *buf))
            buf++;
    }
    argv[argc] = 0;

    // Lookup and invoke the command
    if (argc == 0)
        return 0;
    for (i = 0; i < ARRAY_SIZE(commands); i++) {
        if (strcmp(argv[0], commands[i].name) == 0) {
            return commands[i].func(argc, argv);
        }
    }
    printf("Unknown command '%s'\n", argv[0]);
    return 0;
}

#define BUFLEN 1024
static char buf[BUFLEN];

char *readline(const char *prompt)
{
    int i;
    char c;

    if (prompt)
        printf("%s", prompt);

    i = 0;
    while (1) {
        c = hal_uart_getc(HAL_UART_PORT0);
        if (c > 0x7F) {
            continue;

        } else if ((c == '\b' || c == '\x7f') && i > 0) {
            hal_uart_putc(HAL_UART_PORT0, '\b');
            hal_uart_putc(HAL_UART_PORT0, ' ');
            hal_uart_putc(HAL_UART_PORT0, '\b');
            i--;

        } else if (c >= ' ' && i < BUFLEN-1) {
            hal_uart_putc(HAL_UART_PORT0, c);
            buf[i++] = c;

        } else if (c == '\n' || c == '\r') {
            hal_uart_putc(HAL_UART_PORT0, '\n');
            hal_uart_putc(HAL_UART_PORT0, '\r');
            buf[i] = 0;
            return buf;
        }
    }
}

void cli(void)
{
    char *buf;

    printf("Welcome to Command Line\n");
    printf("Type 'help' for a list of commands.\n");

    while (1) {
        buf = readline("Command > ");
        if (buf != NULL)
            if (runcmd(buf) < 0)
                break;
    }
}
