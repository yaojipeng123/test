#ifndef LIB_COMMON_LIB_DBGLOG_H
#define LIB_COMMON_LIB_DBGLOG_H

#ifdef __cplusplus
extern "C" {
#endif

#ifdef LIB_DBGLOG_ENABLE
#include "dbglog.h"
#include "modules.h"
#if (!defined LIB_LOGGER_ENABLE) && (!defined USE_LOGGER)
#define DBGLOG_LIB_RAW(fmt, arg...)      dbglog(1, 1, DBGLOG_LEVEL_VERBOSE, fmt, ##arg)
#define DBGLOG_LIB_LOG(lvl, fmt, arg...) dbglog(1, 1, lvl, fmt, ##arg)
#define DBGLOG_LIB_INFO(fmt, arg...)     dbglog(1, 1, DBGLOG_LEVEL_INFO, fmt, ##arg)
#define DBGLOG_LIB_WARNING(fmt, arg...)  dbglog(1, 1, DBGLOG_LEVEL_WARNING, fmt, ##arg)
#define DBGLOG_LIB_ERROR(fmt, arg...)    dbglog(1, 1, DBGLOG_LEVEL_ERROR, fmt, ##arg)
#else
#define DBGLOG_LIB_RAW(fmt, arg...)      dbglog_raw_log_write(1, fmt, ##arg)
#define DBGLOG_LIB_LOG(lvl, fmt, arg...) dbglog_raw_log_write(1, fmt, ##arg)
#define DBGLOG_LIB_INFO(fmt, arg...)     dbglog_raw_log_write(1, fmt, ##arg)
#define DBGLOG_LIB_WARNING(fmt, arg...)  dbglog_raw_log_write(1, fmt, ##arg)
#define DBGLOG_LIB_ERROR(fmt, arg...)    dbglog_raw_log_write(1, fmt, ##arg)
#endif
#else
#define DBGLOG_LIB_RAW(fmt, arg...)
#define DBGLOG_LIB_LOG(lvl, fmt, arg...)
#define DBGLOG_LIB_INFO(fmt, arg...)
#define DBGLOG_LIB_WARNING(fmt, arg...)
#define DBGLOG_LIB_ERROR(fmt, arg...)
#endif

#ifdef __cplusplus
}
#endif

#endif /* LIB_COMMON_LIB_DBGLOG_H */
