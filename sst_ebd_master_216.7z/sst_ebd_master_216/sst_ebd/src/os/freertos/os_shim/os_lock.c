/* common includes */
#include "types.h"

/* Free RTOS includes */
#include "FreeRTOS.h"
#include "semphr.h"
#include "task.h"

/* os shim includes */
#include "os_mem.h"
#include "os_lock.h"
#include "os_task.h"
#include "cpu.h"

typedef struct _os_mutex {
    SemaphoreHandle_t mutex;
} os_mutex_t;

typedef struct _os_sem {
    SemaphoreHandle_t sem;
} os_sem_t;

os_mutex_h os_create_mutex(module_id_t module_id)   //创建互斥锁
{
    os_mutex_t *tmp = NULL;

    tmp = os_mem_malloc(module_id, sizeof(tmp));
    if (tmp) {
        tmp->mutex = xSemaphoreCreateRecursiveMutex();
        if (tmp->mutex == NULL) {
            os_mem_free(tmp);
            tmp = NULL;
        }
    }

    return tmp;
}

void os_acquire_mutex(os_mutex_h mutex)   //获取互斥锁
{
    xSemaphoreTakeRecursive(((os_mutex_t *)mutex)->mutex, portMAX_DELAY);
}

void os_release_mutex(os_mutex_h mutex)   //释放互斥锁
{
    xSemaphoreGiveRecursive(((os_mutex_t *)mutex)->mutex);
}

bool_t os_try_acquire_mutex(os_mutex_h mutex)
{
    BaseType_t result;
    result = xSemaphoreTakeRecursive(((os_mutex_t *)mutex)->mutex, 0);

    return result == pdPASS ? true : false;
}

void os_delete_mutex(os_mutex_h mutex)
{
    vSemaphoreDelete(((os_mutex_t *)mutex)->mutex);
    os_mem_free(mutex);
}

os_sem_h os_create_semaphore(module_id_t module_id, uint32_t max_count, uint32_t init_count)
{
    os_sem_t *tmp = os_mem_malloc(module_id, sizeof(tmp));
    if (tmp) {
        tmp->sem = xSemaphoreCreateCounting(max_count, init_count);
        if (tmp->sem == NULL) {
            os_mem_free(tmp);
            tmp = NULL;
        }
    }
    return tmp;
}

bool_t os_pend_semaphore(os_sem_h semaphore, uint32_t timeout)
{
    if (timeout != portMAX_DELAY) {
        timeout = pdMS_TO_TICKS(timeout);
        if (timeout == portMAX_DELAY) {
            timeout--;
        }
    }
    BaseType_t result = xSemaphoreTake(((os_sem_t *)semaphore)->sem, timeout);
    return result == pdTRUE ? true : false;
}

bool_t os_post_semaphore(os_sem_h semaphore)
{
    BaseType_t result = pdFALSE;
    if (hw_in_isr()) {
        BaseType_t need_task_switch = pdFALSE;
        result = xSemaphoreGiveFromISR(((os_sem_t *)semaphore)->sem, &need_task_switch);
    } else
        result = xSemaphoreGive(((os_sem_t *)semaphore)->sem);
    return result == pdTRUE ? true : false;
}

bool_t os_post_semaphore_from_isr(os_sem_h semaphore)
{
    BaseType_t need_task_switch = pdFALSE;
    BaseType_t result = xSemaphoreGiveFromISR(((os_sem_t *)semaphore)->sem, &need_task_switch);

    // if (need_task_switch) {
    //     os_task_switch_context();
    // }

    return result == pdTRUE ? true : false;
}

void os_delete_semaphore(os_sem_h semaphore)
{
    vSemaphoreDelete(((os_sem_t *)semaphore)->sem);
    os_mem_free(semaphore);
}
