/* common includes */
#include "types.h"
#include "string.h"

/* Free RTOS includes */
#include "FreeRTOS.h"
#include "task.h"

/* os shim includes */
#include "os_task.h"
#include "os_mem.h"
#include "assert.h"
#define OS_TASK_DEFAULT_STACK_SZIE 512
#define OS_TASK_NAME_MAX_SIZE      16

typedef struct _os_task {
    TaskHandle_t h;
    os_task_func_t fn;
    void *arg;
} os_task_t;

static task_priority_t *task_priorirty_list_tbl = NULL;
static uint32_t task_priority_list_len = 0;

static void wrapper_task_func(void *arg)
{
    os_task_t *task = (os_task_t *)arg;
    (task->fn)(task->arg);
    /* free RTOS requires to call this function before exit the task */
    os_mem_free(task);
    vTaskDelete(NULL);
}

void os_task_init(const task_priority_t *list, uint32_t len)
{
    task_priorirty_list_tbl = (task_priority_t*)list;
    task_priority_list_len = len;
}

os_task_h os_create_task_ext(os_task_func_t fn, void *arg, uint8_t prio,
                             uint32_t stack_size, const char *name)
{
    os_task_t *handle = NULL;
    TaskHandle_t h = NULL;

    /* parameter check */
    if (fn == NULL)
        goto out;

    handle = os_mem_malloc(OS_MID, sizeof(*handle));
    if (handle == NULL)
        goto out;

    handle->arg = arg;
    handle->fn = fn;

    if (stack_size == 0) {
        stack_size = OS_TASK_DEFAULT_STACK_SZIE;
    }

    if (pdPASS
        != xTaskCreate(wrapper_task_func, name, (uint16_t)stack_size, handle,
                       prio, &h)) {
        os_mem_free(handle);
        handle = NULL;
    } else {
        handle->h = h;
    }

out:
    return handle;
}

void os_delete_task(os_task_h handle)
{
    assert(handle != NULL);

    TaskHandle_t h = ((os_task_t *)handle)->h;
    os_mem_free(handle);
    handle = NULL;

    vTaskDelete(h);
}

void os_set_task_prio(os_task_h handle, uint8_t prio)
{
    if (prio > OS_TASK_PRIO_HIGHEST || prio < OS_TASK_PRIO_LOWEST)
        return;

    vTaskPrioritySet(((os_task_t *)handle)->h, prio);
}

void os_set_task_event(os_task_h handle)
{
    xTaskNotify(((os_task_t *)handle)->h, 0, eNoAction);
}

void os_wait_task_event(void)
{
    uint32_t value;
    xTaskNotifyWait(0, 0, &value, portMAX_DELAY);
}

void os_set_task_event_with_v(os_task_h handle, uint32_t v)
{
    xTaskNotify(((os_task_t *)handle)->h, v, eSetBits);
}

void os_set_task_event_with_v_from_isr(os_task_h handle, uint32_t v)
{
    xTaskNotifyFromISR(((os_task_t *)handle)->h, v, eSetBits, NULL);
}

uint32_t os_wait_task_event_with_v(uint32_t time_to_wait)
{
    uint32_t value;
    xTaskNotifyWait(0, 0xFFFFFFFF, &value, time_to_wait);
    return value;
}

void os_start_kernel(void)
{
    vTaskStartScheduler();
}

void os_disable_irq(void)
{
    taskDISABLE_INTERRUPTS();
}

void os_enable_irq(void)
{
    taskENABLE_INTERRUPTS();
}

void os_task_switch_context(void)
{
    vTaskSwitchContext();
}

uint32_t os_get_total_task_cnt(void)
{
    volatile UBaseType_t task_cnt;

    task_cnt = uxTaskGetNumberOfTasks();

    /* sizeof(UBaseType_t) = 4 */

    return (uint32_t)task_cnt;
}

task_info_t *os_get_task_info(uint32_t *tasks_to_get, uint32_t *task_time)
{
    uint32_t task_cnt, i;
    TaskStatus_t *p_task;
    TaskStatus_t *p_task_array;
    task_info_t *p_task_buf;

    task_cnt = os_get_total_task_cnt();

    p_task_buf = os_mem_malloc(OS_MID, sizeof(task_info_t) * task_cnt);
    if (NULL == p_task_buf) {
        return NULL;
    }

    p_task_array = os_mem_malloc(OS_MID, sizeof(TaskStatus_t) * task_cnt);
    if (NULL == p_task_array) {
        os_mem_free(p_task_buf);
        return NULL;
    }

    task_cnt = uxTaskGetSystemState(p_task_array, task_cnt, task_time);

    for (i = 0; i < task_cnt; i++) {
        p_task = p_task_array + i;

        (p_task_buf + i)->id = (int)p_task->xTaskNumber;
        (p_task_buf + i)->name = p_task->pcTaskName;
        (p_task_buf + i)->cpu_ts = p_task->ulRunTimeCounter;
        (p_task_buf + i)->stack_size = p_task->usStackHighWaterMark;
    }

    os_mem_free(p_task_array);

    *tasks_to_get = task_cnt;
    return p_task_buf;
}

// void os_disable_irq_from_isr(void)
// {
//     taskENTER_CRITICAL_FROM_ISR();
// }

// void os_enable_irq_from_isr(void)
// {
//     taskEXIT_CRITICAL_FROM_ISR();
// }
