/* common includes */
#include "types.h"
#include "stdio.h"
#include "string.h"

/* Free RTOS includes */
#include "FreeRTOS.h"
#include "timers.h"

/* os shim includes */
#include "os_timer.h"
#include "os_mem.h"

#define MAX_TIMER_NAME_LEN 28

typedef struct _wrapper_timer_arg {
    os_timer_func_t fn;
    void *arg;
    uint8_t timer_name[MAX_TIMER_NAME_LEN];
} wrapper_timer_arg_t;

static void wrapper_timer_func(TimerHandle_t timer_id)
{
    wrapper_timer_arg_t *arg = pvTimerGetTimerID(timer_id);
    (arg->fn)((timer_id_t)timer_id, arg->arg);   // arg->fn won't be NULL.
}

timer_id_t os_create_timer(module_id_t module_id, bool_t auto_reload,
                           os_timer_func_t cb, void *arg)
{
    timer_id_t timer_id = (timer_id_t)NULL;
    wrapper_timer_arg_t *timer_arg_ptr = NULL;
    if (cb == NULL) {
        return timer_id;
    }

    timer_arg_ptr =
        (wrapper_timer_arg_t *)os_mem_malloc(module_id, sizeof(*timer_arg_ptr));
    if (timer_arg_ptr == NULL) {
        return timer_id;
    }

    memset(timer_arg_ptr, 0, sizeof(*timer_arg_ptr));
    timer_arg_ptr->fn = cb;
    timer_arg_ptr->arg = arg;
    snprintf((char *const)timer_arg_ptr->timer_name, MAX_TIMER_NAME_LEN - 1,
                 "%08X %08X", (unsigned int)cb, (unsigned int)arg);

    /* temporarily initialize the timer period to a known good one as the
     * real period must be specified in start timer function.
     */
    TimerHandle_t timer_handle = xTimerCreate(
        (char *)timer_arg_ptr->timer_name, 10000 / portTICK_PERIOD_MS,
        auto_reload, (void *)timer_arg_ptr, wrapper_timer_func);
    if (timer_handle) {
        timer_id = (timer_id_t)timer_handle;
    } else {
        os_mem_free(timer_arg_ptr);
    }

    return timer_id;
}

void os_start_timer(timer_id_t id, uint32_t period)
{
    if (period == 0) {
        /* avoid crash */
        period = 1;
    }
    xTimerChangePeriod((TimerHandle_t)id, period / portTICK_PERIOD_MS,
                       portMAX_DELAY);
}

void os_stop_timer(timer_id_t id)
{
    xTimerStop((TimerHandle_t)id, portMAX_DELAY);
}

void os_reset_timer(timer_id_t id)
{
    xTimerReset((TimerHandle_t)id, portMAX_DELAY);
}

void os_delete_timer(timer_id_t id)
{
    if (xTimerIsTimerActive((TimerHandle_t)id)) {
        os_stop_timer(id);
    }

    wrapper_timer_arg_t *arg =
        (wrapper_timer_arg_t *)pvTimerGetTimerID((TimerHandle_t)id);
    xTimerDelete((TimerHandle_t)id, portMAX_DELAY);
    os_mem_free(arg);
}

uint32_t os_is_timer_active(timer_id_t id)
{
    if (xTimerIsTimerActive((TimerHandle_t)id)) {
        return 1;
    }

    return 0;
}
void os_start_timer_from_isr(timer_id_t id, uint32_t period)
{
    if (period == 0) {
        /* avoid crash */
        period = 1;
    }
    xTimerChangePeriodFromISR((TimerHandle_t)id, period / portTICK_PERIOD_MS,
                       pdFALSE);
}


void os_stop_timer_from_isr(timer_id_t id)
{
     xTimerStop((TimerHandle_t)id, pdFALSE);
}