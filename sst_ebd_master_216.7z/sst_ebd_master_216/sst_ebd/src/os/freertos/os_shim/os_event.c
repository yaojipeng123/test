#include "types.h"
/* Free RTOS includes */
#include "FreeRTOS.h"
#include "semphr.h"
#include "event_groups.h"

/* os shim includes */
#include "os_event.h"
#include "os_mem.h"
#include "os_task.h"

typedef struct _os_event {
    EventGroupHandle_t event;
} os_event_t;

os_event_h os_create_event(module_id_t module_id)
{
    os_event_t *tmp = os_mem_malloc(module_id, sizeof(tmp));
    if (tmp) {
        tmp->event = xEventGroupCreate();
        if (tmp->event == NULL) {
            os_mem_free(tmp);
            tmp = NULL;
        }
    }

    return tmp;
}

bool_t os_wait_event(os_event_h event_id, uint32_t timeout, uint32_t *recv)
{
    EventBits_t ret;

    if (timeout != portMAX_DELAY) {
        timeout = pdMS_TO_TICKS(timeout);
        if (timeout == portMAX_DELAY) {
            timeout--;
        }
    }

    ret = xEventGroupWaitBits(((os_event_t *)event_id)->event,
                                ~0xFF000000UL, true, false, timeout);
    if (recv)
        *recv = ret;
    return true;
}

/* timeout: ms */
bool_t os_wait_event_with_v(os_event_h event_id, uint32_t set, uint8_t option,
                            uint32_t timeout, uint32_t *recv)
{
    EventBits_t ret;

    if (timeout != portMAX_DELAY) {
        timeout = pdMS_TO_TICKS(timeout);
        if (timeout == portMAX_DELAY) {
            timeout--;
        }
    }

    ret = xEventGroupWaitBits(((os_event_t *)event_id)->event, set,
                                option & EVENT_FLAG_CLEAR? true : false,
                                option & EVENT_FLAG_AND ? true : false, timeout);
    if (recv)
        *recv = ret;
    return true;
}

bool_t os_set_event(os_event_h event_id, uint32_t set)
{
    xEventGroupSetBits(((os_event_t *)event_id)->event, set);
    return true;
}

bool_t os_set_event_isr(os_event_h event_id, uint32_t set)
{
    xEventGroupSetBitsFromISR(((os_event_t *)event_id)->event, set, NULL);
    return true;
}

void os_delete_event(os_event_h event_id)
{
    vEventGroupDelete(((os_event_t *)event_id)->event);
    os_mem_free(event_id);
}
