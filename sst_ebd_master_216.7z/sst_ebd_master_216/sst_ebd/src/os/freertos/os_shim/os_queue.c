/* common includes */
#include "types.h"
#include "assert.h"
#include "cpu.h"

/* Free RTOS includes */
#include "FreeRTOS.h"
#include "queue.h"

/* os shim includes */
#include "os_mem.h"
#include "os_queue.h"

typedef struct _os_queue {
    QueueHandle_t queue;
} os_queue_t;

os_queue_h os_queue_create(module_id_t module_id, uint32_t queue_lenth, uint32_t item_size)
{
    os_queue_t *tmp = NULL;

    tmp = os_mem_malloc(module_id, sizeof(tmp));
    if (tmp) {
        tmp->queue = xQueueCreate(queue_lenth, item_size);
        if (tmp->queue == NULL) {
            os_mem_free(tmp);
            tmp = NULL;
        }
    }
    return tmp;
}

bool_t os_queue_send(os_queue_h queue, void *queue_tx_msg)
{
    BaseType_t result;

    if (queue_tx_msg == NULL) {
        assert(0);
    }
    if (hw_in_isr()) {
        BaseType_t xHigherPriorityTaskWoken;
        xHigherPriorityTaskWoken = pdFALSE;

        result = xQueueSendFromISR(((os_queue_t *)queue)->queue, queue_tx_msg,
                                   &xHigherPriorityTaskWoken);
    } else
        result = xQueueSend(((os_queue_t *)queue)->queue, queue_tx_msg, 0);

    return result == pdPASS ? true : false;
}

bool_t os_queue_send_from_isr(os_queue_h queue, void *queue_tx_msg)
{
    BaseType_t result;
    BaseType_t xHigherPriorityTaskWoken;

    if (queue_tx_msg == NULL) {
        assert(0);
    }

    // We have not woken a task at the start of the ISR.
    xHigherPriorityTaskWoken = pdFALSE;

    result =
        xQueueSendFromISR(((os_queue_t *)queue)->queue, queue_tx_msg, &xHigherPriorityTaskWoken);

    return result == pdPASS ? true : false;
}

bool_t os_queue_receive(os_queue_h queue, void *queue_rx_msg)
{
    BaseType_t result;

    if (queue_rx_msg == NULL) {
        assert(0);
    }
    if (hw_in_isr()) {
        BaseType_t xTaskWokenByReceive = pdFALSE;
        result =
            xQueueReceiveFromISR(((os_queue_t *)queue)->queue, queue_rx_msg, &xTaskWokenByReceive);

    } else
        result = xQueueReceive(((os_queue_t *)queue)->queue, queue_rx_msg, portMAX_DELAY);
    return result == pdPASS ? true : false;
}

bool_t os_queue_receive_timeout(os_queue_h queue, void *queue_rx_msg, uint32_t timeout)
{
    BaseType_t result;

    if (queue_rx_msg == NULL) {
        assert(0);
    }

    if (timeout != portMAX_DELAY) {
        timeout = pdMS_TO_TICKS(timeout);
        if (timeout == portMAX_DELAY) {
            timeout--;
        }
    }

    result = xQueueReceive(((os_queue_t *)queue)->queue, queue_rx_msg, timeout);

    return result == pdPASS ? true : false;
}

bool_t os_queue_peek(os_queue_h queue, void *queue_rx_msg)
{
    BaseType_t result;

    if (queue_rx_msg == NULL) {
        assert(0);
    }

    result = xQueueReceive(((os_queue_t *)queue)->queue, queue_rx_msg, 0);

    return result == pdPASS ? true : false;
}

bool_t os_queue_receive_from_isr(os_queue_h queue, void *queue_rx_msg)
{
    BaseType_t result;
    BaseType_t xTaskWokenByReceive = pdFALSE;

    if (queue_rx_msg == NULL) {
        assert(0);
    }

    result = xQueueReceiveFromISR(((os_queue_t *)queue)->queue, queue_rx_msg, &xTaskWokenByReceive);

    return result == pdPASS ? true : false;
}

uint32_t os_queue_items_get(os_queue_h queue)
{
    UBaseType_t result;
    result = uxQueueMessagesWaitingFromISR(((os_queue_t *)queue)->queue);

    return (uint32_t)result;
}

void os_queue_delete(os_queue_h queue)
{
    vQueueDelete(((os_queue_t *)queue)->queue);
    os_mem_free(queue);
}
