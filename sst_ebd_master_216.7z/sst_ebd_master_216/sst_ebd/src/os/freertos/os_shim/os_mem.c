
#include "types.h"
#include "string.h"
#include "modules.h"
#include "assert.h"

/* Free RTOS includes */
#include "FreeRTOS.h"
#include "portable.h"

/* os shim includes */
#include "os_mem.h"

uint32_t os_get_heap_size(void)
{
    return configTOTAL_HEAP_SIZE;
}

uint32_t os_mem_get_heap_free(void)
{
    return (xPortGetFreeHeapSize());
}

uint32_t os_mem_get_heap_lowest_free(void)
{
    return (xPortGetMinimumEverFreeHeapSize());
}

void *os_mem_malloc(module_id_t module_id, size_t size)
{
    return pvPortMalloc(size);
}

void os_mem_free(void *ptr)
{
    vPortFree(ptr);
}