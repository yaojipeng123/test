#include "types.h"
#include "errno.h"

/* os shim includes */
#include "os_hook.h"

#define OS_HOOK_CALLBACK_MAX_COUNT 5
static os_hook_idle_callback idle_cb[OS_HOOK_CALLBACK_MAX_COUNT];

void vApplicationIdleHook(void)
{
    for (uint32_t i = 0; i < OS_HOOK_CALLBACK_MAX_COUNT; i++) {
        if (idle_cb[i]) {
            idle_cb[i]();
        }
    }
}

uint8_t os_hook_idle_register_callback(os_hook_idle_callback cb)
{
    uint32_t i = 0;

    for (i = 0; i < OS_HOOK_CALLBACK_MAX_COUNT; i++) {
        if (idle_cb[i] == NULL) {
            idle_cb[i] = cb;
            break;
        }
    }

    if (i == OS_HOOK_CALLBACK_MAX_COUNT) {
        return ERR_FAIL;
    } else {
        return ERR_OK;
    }
}

uint8_t os_hook_idle_unregister_callback(os_hook_idle_callback cb)
{
    uint32_t i = 0;

    for (i = 0; i < OS_HOOK_CALLBACK_MAX_COUNT; i++) {
        if (idle_cb[i] == cb) {
            idle_cb[i] = NULL;
            break;
        }
    }

    if (i == OS_HOOK_CALLBACK_MAX_COUNT) {
        return ERR_FAIL;
    } else {
        return ERR_OK;
    }
}
