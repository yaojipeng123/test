#ifndef OS_SHIM_TASK_H
#define OS_SHIM_TASK_H

#ifdef __cplusplus
extern "C" {
#endif

/* define task handle */
typedef void *os_task_h;

typedef enum {
    TASK_STATE_RUN = 0, /* A task is querying the state of itself,
                    so must be running. */
    TASK_STATE_READY,   /* The task being queried is in a read or pending
                    ready list. */
    TASK_STATE_BLOCK,   /* The task being queried is in the Blocked state. */
    TASK_STATE_SUSPEND, /* The task being queried is in the Suspended state,
                    or is in the Blocked state with an infinite time out. */
    TASK_STATE_DELETE,  /* The task being queried has been deleted,
                    but its TCB has not yet been freed. */
    TASK_STATE_INVALID  /* Used as an 'invalid state' value. */
} task_state_e;

typedef struct _task_info_t {
    uint32_t id;
    uint32_t priority;
    task_state_e status;
    void *stack_base;
    uint32_t stack_size;
    uint32_t cpu_ts;
    const char *name;
} task_info_t;

typedef struct _task_priority_t{
    char    *name;
    uint8_t priority;
}task_priority_t;

typedef struct _task_snapshot_t {
    void        *tcb_ptr;             /*!< Address of task control block. */
    uint32_t    task_id;              /*!< Task id for snapshot */
    uint32_t    *stack_start;         /*!< Points to the location of the last item placed on the tasks stack. */
    uint32_t    *stack_end;           /*!< Points to the end of the stack.*/
} task_snapshot_t;

/**
 * @brief (*os_task_func_t)() - define task routing function pointer type
 * @param arg:                  arg parameter is registered when creating a task.
 */
typedef void (*os_task_func_t)(void *arg);

/**
 * Priority definition. 5 priorities have been defined.
 * Higer number has higer priority. OS specific code can map them
 * to OS defined priority accordingly.
 */
#define OS_TASK_PRIO_5 5
#define OS_TASK_PRIO_6 6
#define OS_TASK_PRIO_7 7
#define OS_TASK_PRIO_8 8
#define OS_TASK_PRIO_9 9

#define OS_TASK_PRIO_HIGHEST OS_TASK_PRIO_9
#define OS_TASK_PRIO_LOWEST  OS_TASK_PRIO_5

/**
 * @brief os_create_task_smp_ext() - create a task
 * @param fn:               function pointer of the task
 * @param arg:              parameter passed to the function call
 * @param prio:             task priority
 * @param stack_size:       required stack size for this task. if set to 0,
 *                          default stack size will be used. unit is 4 bytes.
 * @param name:             task name string
 * @param core_id:          core number
 *
 * @return                  NULL -- for failure case
 * @return                  otherwise -- task handle
 */
os_task_h os_create_task_smp_ext(os_task_func_t fn, void *arg, uint8_t prio,
                                 uint32_t stack_size, const char *name,
                                 uint8_t core_id);

/**
 * @brief os_create_task_ext() - create a task
 * @param fn:               function pointer of the task
 * @param arg:              parameter passed to the function call
 * @param prio:             task priority
 * @param stack_size:       required stack size for this task. if set to 0,
 *                          default stack size will be used. unit is 4 bytes.
 * @param name:             task name string
 *
 * @return                  NULL -- for failure case
 * @return                  otherwise -- task handle
 */
os_task_h os_create_task_ext(os_task_func_t fn, void *arg, uint8_t prio,
                             uint32_t stack_size, const char *name);

/**
 * @brief os_create_task() - create a task
 * @param fn:               function pointer of the task
 * @param arg:              parameter passed to the function call
 * @paramprio:              task priority
 *
 * @return                  NULL -- for failure case
 * @return                  otherwise -- task handle
 */
#define os_create_task(fn, arg, prio) \
    os_create_task_ext(fn, arg, prio, 0, __FUNCTION__)

/**
 * @brief os_delete_task() - delete a task
 * @param handle:           handle of the task to be deleted
 */
void os_delete_task(os_task_h handle);

/**
 * @brief os_set_task_prio() - set priority of a task
 * @param handle:           handle of the task to be set
 * @param prio:             task priority
 */
void os_set_task_prio(os_task_h handle, uint8_t prio);

/**
 * @brief os_set_task_event() - set task event
 * @param handle:           handle of the task to be set
 */
void os_set_task_event(os_task_h handle);

/**
 * @brief os_wait_task_event() - wait for task event. a task can call this
 * funtion to wait for others to call os_set_task_event or os_set_task_event_with_v
 * to wake it up.
 */
void os_wait_task_event(void);

/**
 * @brief os_set_task_event_with_v() - set task event with value transferred
 * to the task. if the task haven't gotten the value through
 * os_wait_task_event_with_v yet, then value of multiple calls will be OR-ed.
 * @param handle:           handle of the task to be set
 * @param v:                value to be transferred
 */
void os_set_task_event_with_v(os_task_h handle, uint32_t v);

/**
 * @brief os_set_task_event_with_v_from_isr() - set task event with value
 * transferred to the task from ISR context. if the task haven't gotten the
 * value through os_wait_task_event_with_v yet, then value of multiple calls
 * will be OR-ed. Note that this function can only be called from ISR context.
 * @param handle:           handle of the task to be set
 * @param v:                value to be transferred
 */
void os_set_task_event_with_v_from_isr(os_task_h handle, uint32_t v);

/**
 * @brief os_wait_task_event_with_v() - wait task event and get the value.
 * a task can call this function to wait for others to call os_set_task_event
 * or os_set_task_event_with_v to wake it up. in addition, the value set by
 * os_set_task_event_with_v will be returned.
 * @param time_to_wait:     time to wait before timeout
 *
 * @return                  the received value from os_set_task_event_with_v.
 */
uint32_t os_wait_task_event_with_v(uint32_t time_to_wait);

/**
 * @brief os_get_total_task_cnt() - Get the count of tasks.
 *
 * @return                  The count of all tasks.
 */
uint32_t os_get_total_task_cnt(void);

/**
 * @brief os_get_task_stack_least_avaiable() - Get the task stack least avaiable space.
 *
 * @return                  The size of stack least avaiable space.
 */
uint16_t os_get_task_stack_least_avaiable(os_task_h handle);

/**
 * @brief os_get_task_info() - Get task information.
 * @param p_task_buf:       The buf to store task info.
 * @param tasks_to_get:     Count of tasks we ready for get.
 *
 * @return                  Count of tasks we got actually.
 */
task_info_t *os_get_task_info(uint32_t *tasks_to_get, uint32_t *task_time);

/**
 * @brief os_get_cpu_utilization() - Get latest 5s' CPU utilization percentage.
 *
 * @return                  Get CPU utilization percentage * 100.
 */
uint32_t os_get_cpu_utilization(void);

/**
 * @brief os_get_mem_utilization() - Get memory utilization percentage.
 *
 * @return                  Get memory utilization percentage * 100.
 */
uint32_t os_get_mem_utilization(void);

/**
 * @brief os_atomic_set() - atomically check and set a memory location
 * @param tagert : Pointer to the memory location.
 * @param old_value : Check if *tagert == old_value.
 * If does, set value to the *tagert.
 * @param value : The new value to set.
 *
 * @return:                1  - Set successfully.
 * @return:                0  - Set failed.
 */
int os_atomic_check_set(int *tagert, int old_value, int value);

/**
 * @brief os_atomic_add() - atomically add a value onto a memory location
 * @param tagert : Pointer to the memory location.
 * @param value : The value to be added.
 *
 * @return:                1  - Set successfully.
 * @return:                0  - Set failed.
 */
int os_atomic_add(int *tagert, int value);

/**
 * @brief os_atomic_get() - atomically get the value of a memory location
 * @param tagert : Pointer to the memory location.
 * @param value : The Pointer to get the value.
 *
 * @return:                1  - Set successfully.
 * @return:                0  - Set failed.
 */
int os_atomic_get(int *tagert, int *value);

/**
 * @brief os_get_current_task_handle() - Get current task handle.
 *
 * @return             task handle.
 */
os_task_h os_get_current_task_handle(void);

/**
 * @brief os_get_task_id() - get task's task number.
 * @param handle:     task's handle
 *
 * @return            task id
 */
uint32_t os_get_task_id(os_task_h handle);

/**
 * @brief os_set_task_yield() - current task yield and high priority task get scheduled.
 *
 */
void os_set_task_yield(void);

/**
 * @brief os_get_task_state() - get current task state
 * */
task_state_e os_get_task_state(os_task_h handle);

/**
 * @brief os_start_kernel() - Start the FreeRtos
 */
void os_start_kernel(void);

/**
 * @brief os_start_scheduler() - Start the scheduler
 */
void os_start_scheduler(void);

/**
 * @brief os_disable_irq() - disable global interrupt
 */
void os_disable_irq(void);

/**
 * @brief os_enable_irq() - enable global interrupt
 */
void os_enable_irq(void);

/**
 * @brief os_disable_irq_from_isr() - disable global interrupt
 * @return:  The mask that should pass into os_enable_irq_from_isr
 */
void os_disable_irq_from_isr(void);

/**
 * @brief os_enable_irq_from_isr() - enable global interrupt
 * @param mask : Mask got from os_disable_irq_from_isr
 */
void os_enable_irq_from_isr(int mask);

/**
 * @brief os_get_scheduler_state - return OS scheduler's state
 *
 * @return:                1  - not start
 * @return:                0  - started
 */
int os_get_scheduler_state(void);

/**
 * @brief os_task_switch_context -  OS's task context switch
 */
void os_task_switch_context(void);

/**
 * @brief os_task_init - init task list and defined task's priority.
 *
 * @param list:     task list
 * @param len:      task element number
 */
void os_task_init(const task_priority_t *list, uint32_t len);

/**
* @brief os_task_snapshot_all -  Get all task's stack snap shot
* @param pxTaskSnapshotArray : Pointer to array of TaskSnapshot_t structures to store tasks snapshot data.
* @param uxArraySize : Size of tasks snapshots array.
* @param pxTcbSz : Pointer to store size of TCB.
* @return Number of elements stored in array.
 */
uint32_t os_task_snapshot_all( task_snapshot_t *const pxTaskSnapshotArray, const uint32_t uxArraySize,uint32_t * pxTcbSz );

#ifdef __cplusplus
}
#endif

#endif /* OS_SHIM_TASK_H */
