#ifndef OS_SHIM_EVENT_H
#define OS_SHIM_EVENT_H

#include "modules.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef void *os_event_h;
#define MAX_TIME 0xffffffffUL

/**
 * @brief os_create_event() - create a event.
 * @param module_id:             the module id that creates the event.
 * @param init_state_set:        initial state of the new created event.
 *                               true means the event is set by default.
 *
 * @return                       0 -- for failure case
 * @return                       otherwise -- event id
 */
os_event_h os_create_event(module_id_t module_id);

/**
 * @brief os_wait_event() - wait to take a event. This method should NOT
 * be called in ISR.
 *
 * @param event_id:              id of the event being waiting to be taken.
 * @param timeout:               time to wait in millisecond for the event
 *                               to be available. when timeout is set to
 *                               MAX_TIME, this method return only if
 *                               the event become avaliable.
 *
 * @return                       TRUE -- Take the event successfully
 * @return                       FALSE -- Failed to take the event within ms milliseconds
 */
bool_t os_wait_event(os_event_h event_id, uint32_t timeout, uint32_t *recv);

#define EVENT_FLAG_AND               0x01            /**< logic and */
#define EVENT_FLAG_OR                0x02            /**< logic or */
#define EVENT_FLAG_CLEAR             0x04

bool_t os_wait_event_with_v(os_event_h event_id, uint32_t set, uint8_t option,
                    uint32_t timeout, uint32_t *recv);
/**
 * @brief os_set_event() - give a event. This method should NOT be called in ISR.
 * @param event_id:              id of the event to be given.
 *
 * @return                       TRUE - Give the event successfully
 * @return                       FALSE - Failed to take the event
 */
bool_t os_set_event(os_event_h event_id, uint32_t set);

bool_t os_set_event_isr(os_event_h event_id, uint32_t set);

/**
 * @brief os_delete_event() - delete a event.
 *
 * @param event_id:              id of the event to be deleted.
 */
void os_delete_event(os_event_h event_id);

#ifdef __cplusplus
}
#endif

#endif /* OS_SHIM_EVENT_H */
