#ifndef OS_SHIM_TIMER_H
#define OS_SHIM_TIMER_H

#include "types.h"
#include "modules.h"

#ifdef __cplusplus
extern "C" {
#endif


/** @addtogroup OS_APIs
  * @{
  */

/** @addtogroup OS_TIMER_APIs
  * @{
  */

typedef uint32_t timer_id_t;

/**
 * @brief void(*os_timer_func_t)() - define timer callback function pointer type.
 * @param timer_id:             timer_id of the timer related with this callback method.
 * @param arg:                  arg for the callback passed in os_timer_create.
 */
typedef void(*os_timer_func_t)(timer_id_t timer_id, void * arg);

/**
 * @brief os_create_timer() - create a timer
 * @param module_id:            id of module that the timer belongs to.
 * @param auto_reload:          parameter passed to the function call.
 * @param cb:                   callback method of the timer.
 * @param arg:                  argument for the callback method.
 *
 * @return                      0 -- for failure case
 * @return                      otherwise -- timer id
 */
timer_id_t os_create_timer(module_id_t module_id,
                           bool_t auto_reload,
                           os_timer_func_t cb,
                           void* arg);

/**
 * @brief os_start_timer() - start a timer. This method should not be called in ISR.
 * @param id:                   id of the timer to be started.
 * @param period:               time period of the timer in milliseconds.
 */
void os_start_timer(timer_id_t id, uint32_t period);

/**
 * @brief os_stop_timer() - stop a timer. This method should not be called in ISR.
 * @param id:                   id of the timer to be stopped.
 */
void os_stop_timer(timer_id_t id);

/**
 * @brief os_reset_timer() - reset a timer. This method should not be called in ISR.
 * @param id:                   id of the timer to be checked.
 */
void os_reset_timer(timer_id_t id);

/**
 * @brief os_delete_timer() - delete a timer.
 * @param id:                   id of the timer to be deleted.
 */
void os_delete_timer(timer_id_t id);

/**
 * @brief os_is_timer_active() - check if timer is active. Active means if
 * started AND callback will be called later
 * @param id:                   id of the timer to be reset
 *
 * @return                      0 -- if the timer is not active
 * @return                      1 -- if the timer is active
 */
uint32_t os_is_timer_active(timer_id_t id);

/**
 * @brief os_start_timer() - start a timer. This method should not be called in ISR.
 * @param id:                   id of the timer to be started.
 * @param period:               time period of the timer in milliseconds.
 */
void os_start_timer_from_isr(timer_id_t id, uint32_t period);

/**
 * @brief os_stop_timer() - stop a timer. This method should not be called in ISR.
 * @param id:                   id of the timer to be stopped.
 */
void os_stop_timer_from_isr(timer_id_t id);
/**
  * @}
  */

#ifdef __cplusplus
}
#endif

#endif /* OS_SHIM_TIMER_H */
