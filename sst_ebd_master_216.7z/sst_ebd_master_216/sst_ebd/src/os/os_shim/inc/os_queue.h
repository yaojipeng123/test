#ifndef OS_SHIM_QUEUE_H
#define OS_SHIM_QUEUE_H

/* os shim includes */

/* common includes */
#include "types.h"
#include "modules.h"

#ifdef __cplusplus
extern "C" {
#endif

/** \defgroup OS_APIs PLC OS APIs
  * @brief WQ30x1 PLC OS APIs
  */

/** @addtogroup OS_APIs
  * @{
  */

/** \defgroup OS_QUEUE_APIs PLC OS QUEUE APIs
  * @brief PLC OS QUEUE
  *
  * OS QUEUE helper function for applications to set for their own task.
  *
  */

/** @addtogroup OS_QUEUE_APIs
  * @{
  */

/* queue handle definition */
typedef void *os_queue_h;

/**
 * @brief os_queue_create() - create a queue.
 * @param module_id:      the module that creates the queue.
 * @param queue_lenth:      the module that the depth of queue.
 * @param item_size:      the module that each item size.
 * @return                NULL -- for failure case
 * @return                otherwise -- queue handle
 */
os_queue_h os_queue_create(module_id_t module_id, uint32_t queue_lenth,
                           uint32_t item_size);

/**
 * @brief os_queue_send() - send a queue.
 * @param queue:          queue handle.
 * @param queue_tx_msg:          queue msg to be send.
 * @return                true --  send queue successfully.
 *                        false -- failed.
 */
bool_t os_queue_send(os_queue_h queue, void *queue_tx_msg);

/**
 * @brief os_queue_send_from_isr() - send a queue.This function can be called in ISR context.
 * @param queue:          queue handle.
 * @param queue_tx_msg:          queue msg to be send.
 * @return                true --  send queue successfully.
 *                        false -- failed.
 */
bool_t os_queue_send_from_isr(os_queue_h queue, void *queue_tx_msg);

/**
 * @brief os_queue_receive() - receive a queue.This function is
 * blocking when called.
 * @param queue:          queue handle.
 * @param queue_rx_msg:          queue msg to be received.
 * @return                true --  reiceive queue successfully.
 *                        false -- failed.
 */
bool_t os_queue_receive(os_queue_h queue, void *queue_rx_msg);


/**
 * @brief os_queue_peek() - peek a queue.This function is
 * non-blocking when called.
 * @param queue:          queue handle.
 * @param queue_rx_msg:          queue msg to be received.
 * @return                true --  reiceive queue successfully.
 *                        false -- failed.
 */
bool_t os_queue_peek(os_queue_h queue, void *queue_rx_msg);

/**
 * @brief os_queue_receive_timeout() - receive a queue with timeout.This function is
 * blocking when called.
 * @param queue:          queue handle.
 * @param queue_rx_msg:          queue msg to be received.
 * @return                true --  reiceive queue successfully.
 *                        false -- failed.
 */
bool_t os_queue_receive_timeout(os_queue_h queue, void *queue_rx_msg, uint32_t timeout);

/**
 * @brief os_queue_receive_from_isr() - receive a queue.This function is
 * blocking when called.This function can be called in ISR context.
 * @param queue:          queue handle.
 * @param queue_rx_msg:          queue msg to be received.
 * @return                true --  receive queue successfully.
 *                        false -- failed.
 */
bool_t os_queue_receive_from_isr(os_queue_h queue, void *queue_rx_msg);

/**
 * @brief os_queue_items_get() - get a queue item numbers available.
 * @param queue:          queue handle.
 * @return                queue available items numbers.
 */
uint32_t os_queue_items_get(os_queue_h queue);

/**
 * @brief os_queue_delete() - delete a queue.
 * @param queue:          queue handle.
 */
void os_queue_delete(os_queue_h queue);

#ifdef __cplusplus
}
#endif

#endif /* OS_SHIM_QUEUE_H */
