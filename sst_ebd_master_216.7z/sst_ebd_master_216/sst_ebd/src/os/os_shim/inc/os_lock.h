#ifndef OS_SHIM_LOCK_H
#define OS_SHIM_LOCK_H

#include "modules.h"

#ifdef __cplusplus
extern "C" {
#endif

/** \defgroup OS_APIs OS APIs
  * @brief OS APIs
  */


/** @addtogroup OS_APIs
  * @{
  */

/** \defgroup OS_MUTEX_APIs PLC OS LOCK APIs
  * @brief PLC OS MUTEX
  *
  * OS MUTEX API for customer application.
  */

/** @addtogroup OS_MUTEX_APIs
  * @{
  */


/* mutex handle definition */
typedef void *os_mutex_h;

/* sempahore handle definition */
typedef void *os_sem_h;

/**
 * @brief os_create_mutex() - create a mutex.
 * @param module_id:      the module that creates the event.
 *
 * @return                NULL -- for failure case
 * @return                otherwise -- mutex handle
 */
os_mutex_h os_create_mutex(module_id_t module_id);

/**
 * @brief os_acquire_mutex() - acquire a mutex. This function can be called
 * recursively from one task. For each call, a corresponding release call is
 * required to release the mutex. This function can NOT be called in ISR context.
 * @param mutex:          mutex to be acquired
 */
void os_acquire_mutex(os_mutex_h mutex);

/**
 * @brief os_try_acquire_mutex() - try to acquire a mutex. This function is
 * not blocking when called. This function can NOT be called in ISR context.
 * @param mutex:          mutex to be acquired
 * @return                true --  acquire mutex successfully.
 *                        false -- failed.
 */
bool_t os_try_acquire_mutex(os_mutex_h mutex);

/**
 * @brief os_release_mutex() - release a mutex This function can NOT be called
 * in ISR context.
 * @param mutex:          mutex to be released
 */
void os_release_mutex(os_mutex_h mutex);

/**
 * @brief os_delete_mutex() - delete a mutex
 * @param mutex:          mutex to be deleted
 */
void os_delete_mutex(os_mutex_h mutex);

/**
 * @brief os_create_semaphore() - create a count semaphore.
 * @param module_id:      the module that creates the semaphore.
 * @param max_count:      max count for this semaphore.
 * @param init_count:     init count for this semaphore.
 *
 * @return                NULL -- for failure case
 * @return                otherwise -- semaphore handle
 */
os_sem_h os_create_semaphore(module_id_t module_id, uint32_t max_count,
    uint32_t init_count);

/**
 * @brief os_pend_semaphore() - pend to take a semaphore.
 * This function can NOT be called in ISR context.
 * @param semaphore:          semaphore to be take.
 * @param timeout:        timeout time(ms).
 * @return                true -- take semaphore successfully.
 *                        false -- timeout.
 */
bool_t os_pend_semaphore(os_sem_h semaphore, uint32_t timeout);

/**
 * @brief os_post_semaphore() - post a semaphore.
 * This function can NOT be called in ISR context.
 * @param semaphore:          semaphore to be posted.
 * @return                true -- post semaphore successfully.
 *                        false -- failed.
 */
bool_t os_post_semaphore(os_sem_h semaphore);

/**
 * @brief os_post_semaphore_from_isr() - post a semaphore.
 * This function can only be called in ISR context.
 * @param semaphore:      semaphore to be posted.
 * @return                true -- post semaphore successfully.
 *                        false -- failed.
 */
bool_t os_post_semaphore_from_isr(os_sem_h semaphore);

/**
 * @brief os_delete_semaphore() - delete a semaphore.
 * @param semaphore:      semaphore to be deleted
 */
void os_delete_semaphore(os_sem_h semaphore);

/**
 * @brief 
 * 
 */
void os_critical_enter(void);

/**
 * @brief 
 * 
 */
void os_critical_exit(void);

#ifdef __cplusplus
}
#endif

#endif /* OS_SHIM_LOCK_H */
