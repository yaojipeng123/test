#ifndef OS_SHIM_UTILS_H
#define OS_SHIM_UTILS_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief os_boot_time32() - get the time since boot up in ms. uint32_t time
 * value will overflow in 49.71 days.
 *
 * @return                  duration in milliseconds since the system boot up
 */
uint32_t os_boot_time32(void);

/**
 * @brief os_boot_time64() - get the time since boot up in ms
 *
 * @return                  duration in milliseconds since the system boot up
 */
uint64_t os_boot_time64(void);

/**
 * @brief os_rand() - get a pseudo random number
 *
 * @return                  a pseudo random number
 */
uint32_t os_rand(void);

/**
 * @brief os_delay - wait for timeout (Time Delay)
 * @param millisec:         millisec time delay value
 */
uint32_t os_delay(uint32_t millisec);

#ifdef __cplusplus
}
#endif

#endif /* OS_SHIM_UTILS_H */
