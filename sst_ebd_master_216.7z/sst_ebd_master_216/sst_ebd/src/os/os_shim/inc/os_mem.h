#ifndef OS_SHIM_MEM_H
#define OS_SHIM_MEM_H

#include "modules.h"

#ifdef __cplusplus
extern "C" {
#endif

void os_heap_init(uint32_t heap_start, uint32_t heap_length);

uint32_t os_get_heap_size(void);

void os_set_stack(uint32_t stack_top);

/**
 * @breif os_mem_malloc() - allocate memory. Dynamicallly allocate
 * the number of bytes of memory. The allocated memory must be reset to 0.
 * @param module_id:     the module mallocing memory. For the debugging purpose.
 * @param size:          number of bytes of memory to be allocated
 *
 * @return               null -- for failure case
 * @return               otherwise -- pointer of allocated memory
 */
void *os_mem_malloc(module_id_t module_id, size_t size);

/**
 * @breif os_mem_free() - free memory
 * @param ptr:           pointer to the memory to be free'd.
 */
void os_mem_free(void *ptr);

/**
* @breif os_mem_aligned_malloc() - allocate tagged memory. Dynamicallly allocate
* the number of bytes of memory. The allocated memory must be reset to 0.
* @param module_id:     the module mallocing memory. For the debugging purpose.
* @param size:          number of bytes of memory to be allocated
* @param alignment:     alignment number.
* @return               null -- for failure case
* @return               otherwise -- pointer of allocated memory
*/
void *os_mem_aligned_malloc(module_id_t module_id, size_t bytes,
                            size_t alignment);

/**
 * @breif os_mem_free() - free memory
 * @param ptr:           alignement pointer to the memory to be free'd.
 */
void os_mem_aligned_free(void *p);

/**
* @breif os_mem_malloc_need_init() - whether buffer data set to zero
*
* @param value:         0: not set to zero, 1: set to zero
*
* @return               null -- for failure case
*/
void os_mem_malloc_need_init(bool_t value);

/**
 * @brief os_mem_get_heap_free() - Get heap's free memory size.
 *
 * @return              free memory size.
 */
uint32_t os_mem_get_heap_free(void);

/**
 * @brief os_mem_get_heap_lowest_free() - Get heap's lowest free memory size.
 *
 * @return              lowest free memory size.
 */
uint32_t os_mem_get_heap_lowest_free(void);

/**
 * @brief os_mem_display_heap_malloc_info() - dump heap's malloc size with module id.
 *
 * @return
 */
void os_mem_display_heap_malloc_info(void);

#ifdef __cplusplus
}
#endif

#endif /* OS_SHIM_MEM_H */
