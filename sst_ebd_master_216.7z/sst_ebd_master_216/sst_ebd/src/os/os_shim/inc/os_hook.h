#ifndef OS_SHIM_HOOK_H
#define OS_SHIM_HOOK_H

/**
 * @addtogroup OS
 * @{
 * @addtogroup OS_SHIM
 * @{
 * @addtogroup OS_HOOK
 * @{
 * This section introduces OS hook reference api.
 */

#ifdef __cplusplus
extern "C" {
#endif

/** @defgroup os_hook_typedef Typedef
  * @{
 */
typedef void (*os_hook_idle_callback)(void);

/**
  * @}
  */

/**
 * @brief This function is OS's idle task hook.
 *
 */
void vApplicationIdleHook(void);

/**
 * @brief This function is idle hook to register callback function.
 *
 * @param cb is the idle hook callback.
 * @return uint8_t RET_OK for success else error.
 */
uint8_t os_hook_idle_register_callback(os_hook_idle_callback cb);

/**
 * @brief This function is idle hook to unregister callback function.
 *
 * @param cb is the idle hook callback.
 * @return uint8_t RET_OK for success else error.
 */
uint8_t os_hook_idle_unregister_callback(os_hook_idle_callback cb);

#ifdef __cplusplus
}
#endif
/**
* @}
* @}
*/
#endif /* OS_SHIM_HOOK_H */
